package com.nettech.securechecker.controller;

import com.nettech.securechecker.app.NettechApplication;
import com.nettech.securechecker.model.DashboardActivity;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.repository.ReportRepository;
import com.nettech.securechecker.service.DashboardService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

import java.util.List;

/**
 * Controller for the Dashboard view.
 * <p>
 * Displays the NETTECH Security Center overview with dynamic stat cards,
 * unified chronological recent activity, and quick-action navigation.
 * <p>
 * <b>SECURITY INVARIANT:</b> Strictly displays metadata. Never stores,
 * caches, or renders plaintext passwords, encryption keys, or sensitive payloads.
 */
public class DashboardController {

    private final NettechApplication app;
    private final DashboardService dashboardService;

    // View components
    private VBox view;
    private Label passwordStatValue;
    private Label filesStatValue;
    private Label reportsStatValue;
    private Label activityEmptyLabel;
    private VBox activityItemsBox;

    public DashboardController(NettechApplication app) {
        this(app, new DashboardService());
    }

    public DashboardController(NettechApplication app, DashboardService dashboardService) {
        this.app = app;
        this.dashboardService = dashboardService != null ? dashboardService : new DashboardService();
    }

    public DashboardController(NettechApplication app,
                               PasswordHistoryRepository passwordRepo,
                               IntegrityReferenceRepository referenceRepo,
                               IntegrityHistoryRepository historyRepo,
                               ReportRepository reportRepo) {
        this(app, new DashboardService(passwordRepo, referenceRepo, historyRepo, reportRepo));
    }

    /**
     * Builds and returns the Dashboard view, ensuring data is freshly loaded.
     */
    public Region getView() {
        if (view == null) {
            view = buildView();
        }
        refresh();
        return view;
    }

    /**
     * Refreshes dashboard metrics and recent activity list from the database.
     */
    public void refresh() {
        String pwdText = dashboardService.getPasswordSecurityStatText();
        String fileText = dashboardService.getFilesCheckedStatText();
        String repText = dashboardService.getReportsStatText();
        List<DashboardActivity> recentActivities = dashboardService.getRecentActivities(8);

        if (passwordStatValue != null) {
            passwordStatValue.setText(pwdText);
        }
        if (filesStatValue != null) {
            filesStatValue.setText(fileText);
        }
        if (reportsStatValue != null) {
            reportsStatValue.setText(repText);
        }

        if (activityItemsBox != null && activityEmptyLabel != null) {
            activityItemsBox.getChildren().clear();

            if (recentActivities.isEmpty()) {
                activityEmptyLabel.setVisible(true);
                activityEmptyLabel.setManaged(true);
                activityItemsBox.setVisible(false);
                activityItemsBox.setManaged(false);
            } else {
                activityEmptyLabel.setVisible(false);
                activityEmptyLabel.setManaged(false);
                activityItemsBox.setVisible(true);
                activityItemsBox.setManaged(true);

                for (DashboardActivity activity : recentActivities) {
                    activityItemsBox.getChildren().add(createActivityRow(activity));
                }
            }
        }
    }

    private VBox buildView() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(0));

        // ── Header ──
        Label title = new Label("NETTECH SECURITY CENTER");
        title.getStyleClass().add("page-title");

        Label subtitle = new Label("Secure passwords. Verify files. Understand security.");
        subtitle.getStyleClass().add("page-subtitle");

        // ── Stat Cards Row ──
        HBox statsRow = new HBox(16);
        statsRow.setAlignment(Pos.TOP_LEFT);

        VBox cardPassword = createStatCard("\uD83D\uDD12", "Password Security", "No activity yet");
        passwordStatValue = (Label) cardPassword.getChildren().get(2);

        VBox cardFiles = createStatCard("\uD83D\uDCC1", "Files Checked", "No activity yet");
        filesStatValue = (Label) cardFiles.getChildren().get(2);

        VBox cardReports = createStatCard("\uD83D\uDCCA", "Reports", "No reports yet");
        reportsStatValue = (Label) cardReports.getChildren().get(2);

        HBox.setHgrow(cardPassword, Priority.ALWAYS);
        HBox.setHgrow(cardFiles, Priority.ALWAYS);
        HBox.setHgrow(cardReports, Priority.ALWAYS);

        statsRow.getChildren().addAll(cardPassword, cardFiles, cardReports);

        // ── Recent Activity Card ──
        VBox activityCard = new VBox(12);
        activityCard.getStyleClass().add("activity-card");

        HBox activityHeader = new HBox(8);
        activityHeader.setAlignment(Pos.CENTER_LEFT);

        Label activityTitle = new Label("Recent Activity");
        activityTitle.getStyleClass().add("activity-title");
        activityTitle.setStyle("-fx-padding: 0;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRefresh = new Button("⟳  Refresh");
        btnRefresh.getStyleClass().add("action-button");
        btnRefresh.setOnAction(e -> refresh());

        activityHeader.getChildren().addAll(activityTitle, spacer, btnRefresh);

        activityEmptyLabel = new Label("No security activity recorded yet.");
        activityEmptyLabel.getStyleClass().add("activity-empty");

        activityItemsBox = new VBox(8);

        activityCard.getChildren().addAll(activityHeader, activityEmptyLabel, activityItemsBox);

        // ── Quick Actions ──
        Label actionsTitle = new Label("Quick Actions");
        actionsTitle.getStyleClass().add("quick-actions-title");

        HBox actionsRow = new HBox(12);
        actionsRow.setAlignment(Pos.CENTER_LEFT);

        Button btnGenPassword   = createActionButton("\uD83D\uDD11  Generate Password");
        Button btnCheckPassword  = createActionButton("\uD83D\uDD0D  Check Password");
        Button btnGenHash       = createActionButton("\u2699  Generate File Hash");
        Button btnVerify        = createActionButton("\u2714  Verify File");

        btnGenPassword.setOnAction(e -> {
            if (app != null) app.navigateTo("Password Security");
        });
        btnCheckPassword.setOnAction(e -> {
            if (app != null) app.navigateTo("Password Security");
        });
        btnGenHash.setOnAction(e -> {
            if (app != null) app.navigateTo("File Integrity");
        });
        btnVerify.setOnAction(e -> {
            if (app != null) app.navigateTo("File Integrity");
        });

        actionsRow.getChildren().addAll(btnGenPassword, btnCheckPassword, btnGenHash, btnVerify);

        root.getChildren().addAll(title, subtitle, statsRow, activityCard, actionsTitle, actionsRow);
        return root;
    }

    /**
     * Creates a single styled row representing a recent activity.
     */
    private Node createActivityRow(DashboardActivity activity) {
        HBox row = new HBox(12);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setStyle("-fx-background-color: -nt-bg-primary; -fx-padding: 10 14; -fx-background-radius: 8; -fx-border-color: -nt-border; -fx-border-radius: 8;");

        // Category / Status Badge
        Label badge = new Label(activity.getStatusBadge());
        badge.getStyleClass().add("status-badge");
        if (activity.getStatusClass() != null && !activity.getStatusClass().isBlank()) {
            badge.getStyleClass().add(activity.getStatusClass());
        }

        // Title and description
        VBox textCol = new VBox(2);
        Label titleLabel = new Label(activity.getTitle());
        titleLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: -nt-text-primary;");

        Label descLabel = new Label(activity.getDescription());
        descLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-secondary;");

        textCol.getChildren().addAll(titleLabel, descLabel);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Timestamp
        Label timeLabel = new Label(activity.getTimestamp());
        timeLabel.setStyle("-fx-font-size: 11.5px; -fx-text-fill: -nt-text-muted; -fx-font-family: Consolas, monospace;");

        row.getChildren().addAll(badge, textCol, spacer, timeLabel);
        return row;
    }

    /**
     * Creates a stat card with an icon, label, and value.
     */
    private VBox createStatCard(String icon, String label, String value) {
        VBox card = new VBox(4);
        card.getStyleClass().add("stat-card");

        Label iconLabel = new Label(icon);
        iconLabel.getStyleClass().add("stat-icon");

        Label nameLabel = new Label(label.toUpperCase());
        nameLabel.getStyleClass().add("stat-label");

        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("stat-value");

        card.getChildren().addAll(iconLabel, nameLabel, valueLabel);
        return card;
    }

    /**
     * Creates a styled action button.
     */
    private Button createActionButton(String text) {
        Button btn = new Button(text);
        btn.getStyleClass().add("action-button");
        return btn;
    }

    // =========================================================================
    // GETTERS FOR TESTING & INSPECTION
    // =========================================================================

    public DashboardService getDashboardService() {
        return dashboardService;
    }

    public String getPasswordStatText() {
        return passwordStatValue != null ? passwordStatValue.getText() : dashboardService.getPasswordSecurityStatText();
    }

    public String getFilesCheckedStatText() {
        return filesStatValue != null ? filesStatValue.getText() : dashboardService.getFilesCheckedStatText();
    }

    public String getReportsStatText() {
        return reportsStatValue != null ? reportsStatValue.getText() : dashboardService.getReportsStatText();
    }

    public Label getPasswordStatValueLabel() {
        return passwordStatValue;
    }

    public Label getFilesStatValueLabel() {
        return filesStatValue;
    }

    public Label getReportsStatValueLabel() {
        return reportsStatValue;
    }

    public Label getActivityEmptyLabel() {
        return activityEmptyLabel;
    }

    public VBox getActivityItemsBox() {
        return activityItemsBox;
    }

    public List<DashboardActivity> getRecentActivities() {
        return dashboardService.getRecentActivities(8);
    }
}
