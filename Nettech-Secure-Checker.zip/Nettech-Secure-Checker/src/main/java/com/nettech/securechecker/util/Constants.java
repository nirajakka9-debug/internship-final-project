package com.nettech.securechecker.util;

/**
 * Application-wide constants.
 */
public final class Constants {

    private Constants() {
        // Prevent instantiation
    }

    // ── Application ────────────────────────────────────────────
    public static final String APP_TITLE      = "NETTECH Secure Password & File Integrity Checker";
    public static final String APP_SHORT_NAME = "NETTECH";
    public static final String APP_VERSION    = "1.0.0";

    // ── Window ─────────────────────────────────────────────────
    public static final int WINDOW_WIDTH  = 1100;
    public static final int WINDOW_HEIGHT = 720;

    // ── Database ───────────────────────────────────────────────
    public static final String DB_DIRECTORY = "data";
    public static final String DB_FILENAME  = "nettech.db";
    public static final String DB_URL       = "jdbc:sqlite:" + DB_DIRECTORY + "/" + DB_FILENAME;
    public static final String SCHEMA_PATH  = "/database/schema.sql";

    // ── Reports ────────────────────────────────────────────────
    public static final String REPORTS_DIRECTORY = "reports";

    // ── Hashing ────────────────────────────────────────────────
    public static final String ALGORITHM_MD5    = "MD5";
    public static final String ALGORITHM_SHA256 = "SHA-256";
    public static final int HASH_CHUNK_SIZE     = 1024 * 1024; // 1 MB chunk size for streaming reads

    // ── Password Generation Character Sets ─────────────────────
    public static final int DEFAULT_PASSWORD_LENGTH = 16;
    public static final int MIN_PASSWORD_LENGTH     = 8;
    public static final int MAX_PASSWORD_LENGTH     = 128;

    public static final String CHARSET_LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    public static final String CHARSET_UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String CHARSET_DIGITS    = "0123456789";
    public static final String CHARSET_SPECIAL   = "!@#$%^&*()-_=+[]{};:,.?/~";

    // ── Password Strength Thresholds & Labels ──────────────────
    public static final int SCORE_VERY_WEAK_MAX = 24;
    public static final int SCORE_WEAK_MAX      = 44;
    public static final int SCORE_MODERATE_MAX  = 64;
    public static final int SCORE_STRONG_MAX    = 84;
    public static final int SCORE_VERY_STRONG_MAX = 100;

    public static final String STRENGTH_VERY_WEAK   = "Very Weak";
    public static final String STRENGTH_WEAK        = "Weak";
    public static final String STRENGTH_MODERATE    = "Moderate";
    public static final String STRENGTH_STRONG      = "Strong";
    public static final String STRENGTH_VERY_STRONG = "Very Strong";

    // ── File Integrity Statuses ────────────────────────────────
    public static final String INTEGRITY_VERIFIED         = "VERIFIED";
    public static final String INTEGRITY_MODIFIED         = "MODIFIED";
    public static final String INTEGRITY_UNABLE_TO_VERIFY = "UNABLE_TO_VERIFY";

    // ── Settings & Preferences ─────────────────────────────────
    public static final String SETTINGS_FILENAME  = "settings.properties";
    public static final String THEME_DARK         = "DARK";
    public static final String THEME_LIGHT        = "LIGHT";
}
