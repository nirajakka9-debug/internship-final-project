package com.nettech.securechecker.controller;

import com.nettech.securechecker.model.SecurityReport;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.repository.ReportRepository;
import com.nettech.securechecker.service.ReportService;
import com.nettech.securechecker.util.Constants;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;

import java.awt.Desktop;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Controller for the Security Reports & PDF Export UI module.
 * <p>
 * Manages:
 * <ul>
 *   <li>Live security posture metrics aggregation (Password & File Integrity KPIs)</li>
 *   <li>Interactive PDF export for Password, Integrity, and Combined reports</li>
 *   <li>Native FileChooser dialogs with path verification and overwrite safeguards</li>
 *   <li>Audit history log of previously exported reports</li>
 * </ul>
 * <p>
 * <b>SECURITY INVARIANT:</b> Report generation runs offline and memory-safe on background threads.
 * Plaintext passwords, hashes, and secrets are strictly excluded from all report outputs.
 */
public class ReportsController {

    private final ReportService reportService;
    private final com.nettech.securechecker.service.SettingsService settingsService;

    // ── Metric Labels ──
    private Label metricPasswordsVal;
    private Label metricPasswordsSub;
    private Label metricBaselinesVal;
    private Label metricBaselinesSub;
    private Label metricChecksVal;
    private Label metricChecksSub;
    private Label metricReportsVal;
    private Label metricReportsSub;

    // ── Generator Action Components ──
    private Button btnExportPassword;
    private Button btnExportIntegrity;
    private Button btnExportCombined;
    private ProgressBar exportProgressBar;
    private Label exportFeedbackLabel;

    // ── History Table Components ──
    private TableView<SecurityReport> reportsTable;
    private ObservableList<SecurityReport> reportsTableData;
    private Label reportsCountLabel;

    public ReportsController() {
        this(new ReportService(), new com.nettech.securechecker.service.SettingsService());
    }

    public ReportsController(com.nettech.securechecker.service.SettingsService settingsService) {
        this(new ReportService(), settingsService);
    }

    public ReportsController(ReportService reportService) {
        this(reportService, new com.nettech.securechecker.service.SettingsService());
    }

    public ReportsController(ReportService reportService, com.nettech.securechecker.service.SettingsService settingsService) {
        this.reportService = reportService;
        this.settingsService = settingsService != null ? settingsService : new com.nettech.securechecker.service.SettingsService();
        this.reportsTableData = FXCollections.observableArrayList();
    }

    /**
     * Builds and returns the complete Reports UI view.
     */
    public Region getView() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(0));

        // ── Header ──
        Label title = new Label("Security Reports & PDF Export");
        title.getStyleClass().add("page-title");

        Label subtitle = new Label("Generate and export executive cybersecurity audit documents in PDF format from local database telemetry.");
        subtitle.getStyleClass().add("page-subtitle");

        // ── 1. Top KPI Summary Row ──
        HBox kpiGrid = buildKpiCardsRow();

        // ── 2. Report Generation Action Cards ──
        VBox actionsContainer = buildReportGeneratorsSection();

        // ── 3. Export History Table ──
        VBox historyContainer = buildReportHistorySection();

        root.getChildren().addAll(title, subtitle, kpiGrid, actionsContainer, historyContainer);

        // Load metrics and table data on background thread
        refreshAllData();

        return root;
    }

    // =========================================================================
    // 1. KPI METRICS CARDS ROW
    // =========================================================================

    private HBox buildKpiCardsRow() {
        HBox row = new HBox(16);
        row.setAlignment(Pos.CENTER);

        // 1. Passwords Card
        VBox card1 = createMetricCard("🔑  PASSWORDS CATALOGED");
        metricPasswordsVal = (Label) card1.getChildren().get(1);
        metricPasswordsSub = (Label) card1.getChildren().get(2);
        HBox.setHgrow(card1, Priority.ALWAYS);

        // 2. Baselines Card
        VBox card2 = createMetricCard("📁  FILE BASELINES");
        metricBaselinesVal = (Label) card2.getChildren().get(1);
        metricBaselinesSub = (Label) card2.getChildren().get(2);
        HBox.setHgrow(card2, Priority.ALWAYS);

        // 3. Checks Card
        VBox card3 = createMetricCard("🛡️  INTEGRITY CHECKS");
        metricChecksVal = (Label) card3.getChildren().get(1);
        metricChecksSub = (Label) card3.getChildren().get(2);
        HBox.setHgrow(card3, Priority.ALWAYS);

        // 4. Reports Card
        VBox card4 = createMetricCard("📋  EXPORTED REPORTS");
        metricReportsVal = (Label) card4.getChildren().get(1);
        metricReportsSub = (Label) card4.getChildren().get(2);
        HBox.setHgrow(card4, Priority.ALWAYS);

        row.getChildren().addAll(card1, card2, card3, card4);
        return row;
    }

    private VBox createMetricCard(String title) {
        VBox card = new VBox(4);
        card.getStyleClass().add("card");
        card.setPadding(new Insets(14, 16, 14, 16));

        Label lblTitle = new Label(title);
        lblTitle.getStyleClass().add("card-title");
        lblTitle.setStyle("-fx-font-size: 11px; -fx-text-fill: -nt-text-muted; -fx-font-weight: bold;");

        Label lblVal = new Label("—");
        lblVal.getStyleClass().add("card-value");
        lblVal.setStyle("-fx-font-size: 20px; -fx-text-fill: -nt-accent; -fx-font-weight: bold;");

        Label lblSub = new Label("Loading...");
        lblSub.setStyle("-fx-font-size: 11px; -fx-text-fill: -nt-text-secondary;");

        card.getChildren().addAll(lblTitle, lblVal, lblSub);
        return card;
    }

    // =========================================================================
    // 2. REPORT GENERATION PROFILES
    // =========================================================================

    private VBox buildReportGeneratorsSection() {
        VBox container = new VBox(12);

        Label sectionTitle = new Label("Generate Security Audit Reports");
        sectionTitle.getStyleClass().add("section-heading");
        sectionTitle.setStyle("-fx-padding: 0;");

        HBox cardsRow = new HBox(16);

        // Card A: Password Security Report
        VBox cardPassword = buildReportTypeCard(
                "🔑  Password Security Report",
                "Workstation Credential Hygiene",
                "Includes password generation metadata, entropy scoring breakdown, strength distribution percentages, and credential hardening policies.",
                "Export Password PDF",
                () -> handleExportPasswordReport()
        );
        btnExportPassword = (Button) cardPassword.getChildren().get(cardPassword.getChildren().size() - 1);
        HBox.setHgrow(cardPassword, Priority.ALWAYS);

        // Card B: File Integrity Report
        VBox cardIntegrity = buildReportTypeCard(
                "🛡️  File Integrity Report",
                "Cryptographic Baselines & Tamper Audit",
                "Includes cataloged file baseline references, SHA-256 verification results, tampering detection logs, and checksum disparity analysis.",
                "Export Integrity PDF",
                () -> handleExportIntegrityReport()
        );
        btnExportIntegrity = (Button) cardIntegrity.getChildren().get(cardIntegrity.getChildren().size() - 1);
        HBox.setHgrow(cardIntegrity, Priority.ALWAYS);

        // Card C: Combined Full Report
        VBox cardCombined = buildReportTypeCard(
                "📊  Comprehensive Security Report",
                "Full Executive Workstation Audit",
                "Complete overview uniting password metadata telemetry and file integrity baselines into a multi-page executive security briefing.",
                "Export Combined PDF",
                () -> handleExportCombinedReport()
        );
        btnExportCombined = (Button) cardCombined.getChildren().get(cardCombined.getChildren().size() - 1);
        HBox.setHgrow(cardCombined, Priority.ALWAYS);

        cardsRow.getChildren().addAll(cardPassword, cardIntegrity, cardCombined);

        // Progress bar & Feedback row
        exportProgressBar = new ProgressBar(0);
        exportProgressBar.setMaxWidth(Double.MAX_VALUE);
        exportProgressBar.setVisible(false);
        exportProgressBar.setManaged(false);

        exportFeedbackLabel = new Label();
        exportFeedbackLabel.setWrapText(true);
        exportFeedbackLabel.setStyle("-fx-font-size: 12.5px;");

        container.getChildren().addAll(sectionTitle, cardsRow, exportProgressBar, exportFeedbackLabel);
        return container;
    }

    private VBox buildReportTypeCard(String title, String subtitle, String desc, String btnText, Runnable action) {
        VBox card = new VBox(10);
        card.getStyleClass().add("card");
        card.setPadding(new Insets(16));

        Label lblTitle = new Label(title);
        lblTitle.getStyleClass().add("card-title");
        lblTitle.setStyle("-fx-font-size: 14.5px; -fx-text-fill: -nt-accent; -fx-font-weight: bold;");

        Label lblSub = new Label(subtitle);
        lblSub.setStyle("-fx-font-size: 11.5px; -fx-text-fill: -nt-text-secondary; -fx-font-weight: bold;");

        Label lblDesc = new Label(desc);
        lblDesc.getStyleClass().add("card-value");
        lblDesc.setWrapText(true);
        lblDesc.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-primary;");
        VBox.setVgrow(lblDesc, Priority.ALWAYS);

        Button btn = new Button("📥  " + btnText);
        btn.getStyleClass().add("action-button-primary");
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setOnAction(e -> action.run());

        card.getChildren().addAll(lblTitle, lblSub, lblDesc, btn);
        return card;
    }

    // =========================================================================
    // 3. REPORT EXPORT HANDLERS
    // =========================================================================

    private void handleExportPasswordReport() {
        String defaultName = "NETTECH_Password_Security_Report_" + dateStamp() + ".pdf";
        File destination = promptSaveDestination("Save Password Security Report", defaultName);
        if (destination == null) return;

        runExportTask("Password Security Report", destination, () -> reportService.exportPasswordReport(destination));
    }

    private void handleExportIntegrityReport() {
        String defaultName = "NETTECH_File_Integrity_Report_" + dateStamp() + ".pdf";
        File destination = promptSaveDestination("Save File Integrity Report", defaultName);
        if (destination == null) return;

        runExportTask("File Integrity Report", destination, () -> reportService.exportIntegrityReport(destination));
    }

    private void handleExportCombinedReport() {
        String defaultName = "NETTECH_Comprehensive_Security_Report_" + dateStamp() + ".pdf";
        File destination = promptSaveDestination("Save Comprehensive Security Report", defaultName);
        if (destination == null) return;

        runExportTask("Comprehensive Security Report", destination, () -> reportService.exportCombinedReport(destination));
    }

    @FunctionalInterface
    private interface ExportSupplier {
        SecurityReport export() throws Exception;
    }

    private void runExportTask(String reportName, File destination, ExportSupplier supplier) {
        setExportBusy(true);
        exportFeedbackLabel.setText("Compiling " + reportName + " and rendering PDF...");
        exportFeedbackLabel.getStyleClass().setAll("feedback-message");

        Task<SecurityReport> task = new Task<>() {
            @Override
            protected SecurityReport call() throws Exception {
                return supplier.export();
            }
        };

        task.setOnSucceeded(e -> {
            SecurityReport result = task.getValue();
            setExportBusy(false);
            exportFeedbackLabel.setText(String.format("✓ %s successfully exported to: %s", reportName, result.getOutputPath()));
            exportFeedbackLabel.getStyleClass().setAll("feedback-success");

            // Refresh table and KPIs
            refreshAllData();
        });

        task.setOnFailed(e -> {
            Throwable ex = task.getException();
            setExportBusy(false);
            exportFeedbackLabel.setText("Failed to export report: " + (ex != null ? ex.getMessage() : "Unknown I/O error"));
            exportFeedbackLabel.getStyleClass().setAll("feedback-error");
        });

        Thread exportThread = new Thread(task);
        exportThread.setDaemon(true);
        exportThread.start();
    }

    private File promptSaveDestination(String title, String defaultFileName) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(title);
        fileChooser.setInitialFileName(defaultFileName);
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF Documents (*.pdf)", "*.pdf")
        );

        // Use configured report directory from settings (or default)
        String reportsDirPath = settingsService != null ? settingsService.getReportsDirectory() : Constants.REPORTS_DIRECTORY;
        File reportsDir = new File(reportsDirPath);
        if (!reportsDir.exists()) {
            reportsDir.mkdirs();
        }
        if (reportsDir.exists() && reportsDir.isDirectory()) {
            fileChooser.setInitialDirectory(reportsDir);
        }

        File file = fileChooser.showSaveDialog(null);
        if (file == null) {
            return null;
        }

        // Ensure .pdf extension
        if (!file.getName().toLowerCase().endsWith(".pdf")) {
            file = new File(file.getAbsolutePath() + ".pdf");
        }

        if (file.exists()) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Overwrite");
            confirm.setHeaderText("File already exists");
            confirm.setContentText("The file '" + file.getName() + "' already exists. Overwrite it?");
            Optional<ButtonType> opt = confirm.showAndWait();
            if (opt.isEmpty() || opt.get() != ButtonType.OK) {
                return null;
            }
        }

        return file;
    }

    private void setExportBusy(boolean busy) {
        btnExportPassword.setDisable(busy);
        btnExportIntegrity.setDisable(busy);
        btnExportCombined.setDisable(busy);
        exportProgressBar.setVisible(busy);
        exportProgressBar.setManaged(busy);
    }

    // =========================================================================
    // 4. REPORT HISTORY TABLE SECTION
    // =========================================================================

    @SuppressWarnings("unchecked")
    private VBox buildReportHistorySection() {
        VBox container = new VBox(12);

        HBox headerRow = new HBox(12);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("Exported Reports History");
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-padding: 0;");

        reportsCountLabel = new Label("Total Reports: 0");
        reportsCountLabel.setStyle("-fx-text-fill: -nt-text-muted; -fx-font-size: 13px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRefresh = new Button("⟳  Refresh");
        btnRefresh.getStyleClass().add("action-button");
        btnRefresh.setOnAction(e -> refreshAllData());

        Button btnOpenFile = new Button("📂  Open PDF File");
        btnOpenFile.getStyleClass().add("action-button");
        btnOpenFile.setOnAction(e -> handleOpenFile());

        Button btnDelete = new Button("🗑  Delete Record");
        btnDelete.getStyleClass().add("action-button");
        btnDelete.setOnAction(e -> handleDeleteReport());

        headerRow.getChildren().addAll(title, reportsCountLabel, spacer, btnRefresh, btnOpenFile, btnDelete);

        reportsTable = new TableView<>(reportsTableData);
        reportsTable.setPrefHeight(300);
        reportsTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<SecurityReport, Integer> colId = new TableColumn<>("#");
        colId.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getId()));
        colId.setMaxWidth(60);
        colId.setMinWidth(40);

        TableColumn<SecurityReport, String> colType = new TableColumn<>("Report Profile");
        colType.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getReportType()));
        colType.setMinWidth(160);
        colType.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Label badge = new Label(formatReportTypeLabel(item));
                    badge.getStyleClass().add("status-badge");
                    if (item.contains("PASSWORD")) {
                        badge.setStyle("-fx-background-color: #1e3a8a; -fx-text-fill: #93c5fd; -fx-padding: 3 8; -fx-background-radius: 10; -fx-font-size: 11px;");
                    } else if (item.contains("INTEGRITY")) {
                        badge.setStyle("-fx-background-color: #064e3b; -fx-text-fill: #6ee7b7; -fx-padding: 3 8; -fx-background-radius: 10; -fx-font-size: 11px;");
                    } else {
                        badge.setStyle("-fx-background-color: #4c1d95; -fx-text-fill: #c4b5fd; -fx-padding: 3 8; -fx-background-radius: 10; -fx-font-size: 11px;");
                    }
                    setGraphic(badge);
                    setText(null);
                }
            }
        });

        TableColumn<SecurityReport, String> colName = new TableColumn<>("File Name");
        colName.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getFileName()));
        colName.setMinWidth(200);

        TableColumn<SecurityReport, String> colDate = new TableColumn<>("Export Timestamp");
        colDate.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getGeneratedAt()));
        colDate.setMinWidth(150);

        TableColumn<SecurityReport, String> colPath = new TableColumn<>("Destination Path");
        colPath.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getOutputPath()));
        colPath.setMinWidth(250);
        colPath.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String path, boolean empty) {
                super.updateItem(path, empty);
                if (empty || path == null) {
                    setText(null);
                    setTooltip(null);
                } else {
                    setText(path);
                    setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 11px; -fx-text-fill: -nt-text-muted;");
                    setTooltip(new Tooltip(path));
                }
            }
        });

        reportsTable.getColumns().addAll(colId, colType, colName, colDate, colPath);
        reportsTable.setPlaceholder(new Label("No security audit reports exported yet. Use the export cards above to generate PDF reports."));

        container.getChildren().addAll(headerRow, reportsTable);
        return container;
    }

    private void handleOpenFile() {
        SecurityReport selected = reportsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No Report Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select a report from the table to open.");
            alert.showAndWait();
            return;
        }

        File file = new File(selected.getOutputPath());
        if (!file.exists()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("File Not Found");
            alert.setHeaderText("The report PDF no longer exists on disk.");
            alert.setContentText("Target path: " + selected.getOutputPath());
            alert.showAndWait();
            return;
        }

        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(file);
            } else {
                exportFeedbackLabel.setText("File located at: " + file.getAbsolutePath());
            }
        } catch (Exception ex) {
            exportFeedbackLabel.setText("Failed to open file: " + ex.getMessage());
        }
    }

    private void handleDeleteReport() {
        SecurityReport selected = reportsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No Report Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select a report from the table to delete.");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Report Record");
        confirm.setHeaderText("Delete report audit record #" + selected.getId() + "?");
        confirm.setContentText("This removes the metadata log from the database. The physical PDF on disk will not be deleted.");

        Optional<ButtonType> opt = confirm.showAndWait();
        if (opt.isPresent() && opt.get() == ButtonType.OK) {
            reportService.deleteReport(selected.getId());
            refreshAllData();
        }
    }

    // =========================================================================
    // 5. ASYNCHRONOUS REFRESH & DATA AGGREGATION
    // =========================================================================

    private void refreshAllData() {
        Thread thread = new Thread(() -> {
            try {
                ReportService.PasswordReportSummary pwdSummary = reportService.getPasswordSummary();
                ReportService.IntegrityReportSummary intSummary = reportService.getIntegritySummary();
                List<SecurityReport> reportList = reportService.getAllReports();
                int reportCount = reportService.getReportCount();

                Platform.runLater(() -> {
                    // Update KPI cards
                    if (metricPasswordsVal != null) {
                        metricPasswordsVal.setText(String.valueOf(pwdSummary.total));
                        metricPasswordsSub.setText("Avg score: " + String.format("%.1f", pwdSummary.avgScore) + "/100");
                    }
                    if (metricBaselinesVal != null) {
                        metricBaselinesVal.setText(String.valueOf(intSummary.totalReferences));
                        metricBaselinesSub.setText("Active baselines");
                    }
                    if (metricChecksVal != null) {
                        metricChecksVal.setText(String.valueOf(intSummary.totalChecks));
                        metricChecksSub.setText(intSummary.verified + " Verified • " + intSummary.modified + " Modified");
                    }
                    if (metricReportsVal != null) {
                        metricReportsVal.setText(String.valueOf(reportCount));
                        metricReportsSub.setText("PDF audit exports");
                    }

                    // Update reports history table
                    reportsTableData.setAll(reportList);
                    if (reportsCountLabel != null) {
                        reportsCountLabel.setText("Total Reports: " + reportCount);
                    }
                });
            } catch (Exception ex) {
                System.err.println("[NETTECH] Failed to refresh reports data: " + ex.getMessage());
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    private String formatReportTypeLabel(String type) {
        if (type == null) return "Report";
        return switch (type) {
            case ReportService.TYPE_PASSWORD_REPORT -> "Password Security";
            case ReportService.TYPE_INTEGRITY_REPORT -> "File Integrity";
            case ReportService.TYPE_COMBINED_REPORT -> "Combined Security";
            default -> type;
        };
    }

    private String dateStamp() {
        return LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
}
