package com.nettech.securechecker.controller;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for the Security Tips educational and awareness module.
 * <p>
 * Provides curated, offline cybersecurity guidelines organized by domain.
 * Supports real-time search filtering and category chip selection.
 * <p>
 * <b>SECURITY INVARIANT:</b> All content is bundled locally. Zero external network calls are made.
 */
public class TipsController {

    public record SecurityTip(
            String id,
            String category,
            String title,
            String summary,
            String guidance,
            String example,
            String icon
    ) {}

    private final List<SecurityTip> allTips = new ArrayList<>();
    private String selectedCategory = "ALL";
    private String searchKeyword = "";

    private TextField searchField;
    private VBox tipsContainer;
    private Label resultsCountLabel;
    private HBox chipsBar;

    public TipsController() {
        loadCuratedTips();
    }

    /**
     * Builds and returns the complete Security Tips view.
     */
    public Region getView() {
        VBox root = new VBox(18);
        root.setPadding(new Insets(0));

        // ── Header ──
        Label titleLabel = new Label("Security Tips & Best Practices");
        titleLabel.getStyleClass().add("page-title");

        Label descLabel = new Label(
                "Operational guidelines, cryptographic verification principles, and defensive hygiene recommendations.");
        descLabel.getStyleClass().add("page-subtitle");

        // ── Search & Filter Bar ──
        VBox filterSection = buildFilterSection();

        // ── Results Container ──
        tipsContainer = new VBox(12);

        // Populate initial tips
        updateFilteredTips();

        root.getChildren().addAll(titleLabel, descLabel, filterSection, tipsContainer);
        return root;
    }

    private VBox buildFilterSection() {
        VBox box = new VBox(12);

        // Search Field Row
        HBox searchRow = new HBox(12);
        searchRow.setAlignment(Pos.CENTER_LEFT);

        searchField = new TextField();
        searchField.setPromptText("🔍  Search security tips, keywords, algorithms, or concepts...");
        searchField.getStyleClass().add("text-field");
        HBox.setHgrow(searchField, Priority.ALWAYS);
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            searchKeyword = newVal != null ? newVal.trim().toLowerCase() : "";
            updateFilteredTips();
        });

        Button btnClearSearch = new Button("✕ Clear");
        btnClearSearch.getStyleClass().add("action-button");
        btnClearSearch.setOnAction(e -> {
            searchField.clear();
            searchKeyword = "";
            updateFilteredTips();
        });

        searchRow.getChildren().addAll(searchField, btnClearSearch);

        // Category Filter Chips
        chipsBar = new HBox(8);
        chipsBar.setAlignment(Pos.CENTER_LEFT);

        String[] categories = new String[]{
                "ALL",
                "Password Security",
                "File Integrity & Checksums",
                "Phishing & Downloads",
                "Software Updates",
                "Device & Account Security",
                "Privacy & Data Handling"
        };

        for (String cat : categories) {
            Button chip = new Button(cat.equals("ALL") ? "All Topics" : cat);
            chip.getStyleClass().add("chip-button");
            if (cat.equals(selectedCategory)) {
                chip.getStyleClass().add("chip-button-active");
            }
            chip.setOnAction(e -> {
                selectedCategory = cat;
                updateChipsStyle();
                updateFilteredTips();
            });
            chipsBar.getChildren().add(chip);
        }

        // Counter label
        resultsCountLabel = new Label();
        resultsCountLabel.setStyle("-fx-text-fill: -nt-text-muted; -fx-font-size: 12.5px;");

        box.getChildren().addAll(searchRow, chipsBar, resultsCountLabel);
        return box;
    }

    private void updateChipsStyle() {
        int idx = 0;
        String[] categories = new String[]{
                "ALL",
                "Password Security",
                "File Integrity & Checksums",
                "Phishing & Downloads",
                "Software Updates",
                "Device & Account Security",
                "Privacy & Data Handling"
        };
        for (javafx.scene.Node node : chipsBar.getChildren()) {
            if (node instanceof Button btn) {
                btn.getStyleClass().remove("chip-button-active");
                if (categories[idx].equals(selectedCategory)) {
                    btn.getStyleClass().add("chip-button-active");
                }
                idx++;
            }
        }
    }

    private void updateFilteredTips() {
        List<SecurityTip> filtered = allTips.stream()
                .filter(tip -> {
                    boolean catMatch = "ALL".equalsIgnoreCase(selectedCategory)
                            || tip.category().equalsIgnoreCase(selectedCategory);
                    if (!catMatch) return false;

                    if (searchKeyword.isEmpty()) return true;

                    return tip.title().toLowerCase().contains(searchKeyword)
                            || tip.summary().toLowerCase().contains(searchKeyword)
                            || tip.guidance().toLowerCase().contains(searchKeyword)
                            || (tip.example() != null && tip.example().toLowerCase().contains(searchKeyword))
                            || tip.category().toLowerCase().contains(searchKeyword);
                })
                .collect(Collectors.toList());

        resultsCountLabel.setText("Showing " + filtered.size() + " of " + allTips.size() + " security guidelines");

        tipsContainer.getChildren().clear();

        if (filtered.isEmpty()) {
            VBox emptyBox = new VBox(12);
            emptyBox.setAlignment(Pos.CENTER);
            emptyBox.setPadding(new Insets(30));
            emptyBox.getStyleClass().add("card");

            Label emptyIcon = new Label("🔍");
            emptyIcon.setStyle("-fx-font-size: 28px;");

            Label emptyMsg = new Label("No security tips found matching your search criteria.");
            emptyMsg.setStyle("-fx-font-size: 13.5px; -fx-text-fill: -nt-text-secondary;");

            Button btnReset = new Button("Reset Filter");
            btnReset.getStyleClass().add("action-button-primary");
            btnReset.setOnAction(e -> {
                searchField.clear();
                selectedCategory = "ALL";
                updateChipsStyle();
                updateFilteredTips();
            });

            emptyBox.getChildren().addAll(emptyIcon, emptyMsg, btnReset);
            tipsContainer.getChildren().add(emptyBox);
            return;
        }

        for (SecurityTip tip : filtered) {
            tipsContainer.getChildren().add(renderTipCard(tip));
        }
    }

    private VBox renderTipCard(SecurityTip tip) {
        VBox card = new VBox(8);
        card.getStyleClass().add("tip-card");

        // Top Row: Category Badge & Icon
        HBox topRow = new HBox(8);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Label iconLbl = new Label(tip.icon());
        iconLbl.setStyle("-fx-font-size: 14px;");

        Label catBadge = new Label(tip.category().toUpperCase());
        catBadge.getStyleClass().add("tip-category-badge");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        topRow.getChildren().addAll(iconLbl, catBadge, spacer);

        // Title
        Label titleLbl = new Label(tip.title());
        titleLbl.setStyle("-fx-font-size: 14.5px; -fx-font-weight: bold; -fx-text-fill: -nt-text-primary;");
        titleLbl.setWrapText(true);

        // Summary
        Label summaryLbl = new Label(tip.summary());
        summaryLbl.setStyle("-fx-font-size: 12.5px; -fx-text-fill: -nt-text-secondary;");
        summaryLbl.setWrapText(true);

        // Guidance / Explanation
        Label guidanceLbl = new Label(tip.guidance());
        guidanceLbl.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-primary; -fx-line-spacing: 2;");
        guidanceLbl.setWrapText(true);

        card.getChildren().addAll(topRow, titleLbl, summaryLbl, guidanceLbl);

        // Practical Example box if present
        if (tip.example() != null && !tip.example().isBlank()) {
            VBox exampleBox = new VBox(4);
            exampleBox.getStyleClass().add("tip-example-box");

            Label exHeader = new Label("💡 PRACTICAL EXAMPLE / APPLICATION");
            exHeader.setStyle("-fx-font-size: 10.5px; -fx-font-weight: bold; -fx-text-fill: -nt-accent;");

            Label exContent = new Label(tip.example());
            exContent.setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 11.5px; -fx-text-fill: -nt-text-secondary;");
            exContent.setWrapText(true);

            exampleBox.getChildren().addAll(exHeader, exContent);
            card.getChildren().add(exampleBox);
        }

        return card;
    }

    private void loadCuratedTips() {
        // ── 1. Password Security ──
        allTips.add(new SecurityTip(
                "pwd-1",
                "Password Security",
                "Never Store or Transmit Plaintext Passwords",
                "Plaintext credentials in documents, text files, emails, or spreadsheets are the primary target of info-stealer malware.",
                "Always generate distinct, high-entropy credentials using dedicated local tools and store them only in encrypted vaults or memory. Never write credentials on sticky notes, in shared wiki pages, or in unencrypted text files on your workstation.",
                "Anti-pattern: saving 'passwords.xlsx' on Desktop.\nRecommended: Use an offline KeePass vault or system keychain protected by a strong master passphrase.",
                "🔐"
        ));

        allTips.add(new SecurityTip(
                "pwd-2",
                "Password Security",
                "Length Provides Exponentially Greater Entropy than Complexity",
                "Modern offline GPU cracking rigs (e.g. hashcat clusters) crack 8-character complex passwords in minutes.",
                "A password of 16 to 24 characters created using a Cryptographically Secure Pseudo-Random Number Generator (CSPRNG) provides astronomical search spaces that withstand brute-force attacks for decades, even against specialized offline hardware.",
                "Formula: 16 characters using [a-z, A-Z, 0-9, special] provides ~95 bits of entropy (over 79 quintillion possible combinations).",
                "⚡"
        ));

        allTips.add(new SecurityTip(
                "pwd-3",
                "Password Security",
                "Eliminate Sequential and Predictable Patterns",
                "Attackers use rule-based wordlist mutations that automatically prepend or append years, capitalized roots, and keyboard sequences.",
                "Avoid predictable substitutions such as replacing 'E' with '3' or 'A' with '@'. Patterns like 'Password2024!' or 'Spring2025#' are parsed by dictionary engines within the first thousand guesses.",
                "Vulnerable: 'Summer2024!1'\nSecure: '7k#9Qz$mP2!xL8@w' (generated via SecureRandom)",
                "🛡️"
        ));

        // ── 2. File Integrity & Checksums ──
        allTips.add(new SecurityTip(
                "int-1",
                "File Integrity & Checksums",
                "SHA-256 Checksums Confirm Content Identity, Not Malware Absence",
                "A matching cryptographic checksum guarantees only that the file content is bit-for-bit identical to the comparison reference.",
                "Crucial Security Context: A matching SHA-256 hash does NOT prove a file is harmless or malware-free. If a malicious binary was cataloged as the baseline reference, comparing against it will result in 'VERIFIED' even though the file is malicious. Always establish baseline hashes from verified, authoritative vendor sources.",
                "Workflow: Download vendor binary -> obtain vendor's published SHA-256 from their signed HTTPS release notes -> calculate local hash with NETTECH -> verify exact match before executing.",
                "⚠️"
        ));

        allTips.add(new SecurityTip(
                "int-2",
                "File Integrity & Checksums",
                "Why MD5 Must Never Be Relied Upon for Security Decisions",
                "MD5 is cryptographically broken and subject to practical chosen-prefix collision attacks.",
                "Threat actors can construct two completely different files—such as a benign utility and an arbitrary remote access trojan—that produce the exact identical 32-character MD5 checksum. MD5 is provided in this toolkit solely for legacy verification and non-security checksum deduplication. All security verification decisions must be governed strictly by SHA-256.",
                "Historical Precedent: The Flame cyber espionage campaign used an MD5 chosen-prefix collision to forge Microsoft digital code-signing certificates.",
                "🛑"
        ));

        allTips.add(new SecurityTip(
                "int-3",
                "File Integrity & Checksums",
                "Catalog Critical Baselines Prior to Deployment",
                "Detect unauthorized binary replacement, tampering, and supply-chain corruption by maintaining a local baseline inventory.",
                "Register SHA-256 hashes of critical application executables, configuration files, and system utilities immediately upon installation. Periodically re-verify them to catch stealth persistence mechanisms and backdoor implants.",
                "Application: Use NETTECH's 'Save as Baseline Reference' feature to catalog executable baselines in 'data/nettech.db'.",
                "📁"
        ));

        // ── 3. Phishing & Suspicious Downloads ──
        allTips.add(new SecurityTip(
                "phish-1",
                "Phishing & Downloads",
                "Beware of Double Extensions and Executable Camouflage",
                "Attackers exploit operating system file-extension hiding to disguise executable payloads as innocent documents.",
                "Always enable 'File name extensions' in Windows Explorer. Be vigilant for files such as 'Invoice_March2026.pdf.exe' or files using Right-to-Left Override (RLO) unicode characters that visually reverse extension strings.",
                "Visual trap: An icon appearing as an Adobe PDF document with actual extension '.scr' or '.vbs'.",
                "🎣"
        ));

        allTips.add(new SecurityTip(
                "phish-2",
                "Phishing & Downloads",
                "Verify Hashes Before Running Downloaded Software",
                "Supply chain attacks frequently compromise distribution mirrors and CDNs to deliver modified installers.",
                "Whenever downloading open-source software, ISO images, or tools, check the vendor's published checksums over secure channels. Computing the SHA-256 in NETTECH before double-clicking ensures that mirror tampering or transfer corruption is detected immediately.",
                "Example: Linux distributions and Apache software release SHA256SUMS and PGP signature files alongside installation ISOs.",
                "🔍"
        ));

        // ── 4. Software Updates ──
        allTips.add(new SecurityTip(
                "patch-1",
                "Software Updates",
                "Rapid Patching Mitigates Known Vulnerabilities (CVEs)",
                "Over 80% of successful breaches exploit publicly disclosed vulnerabilities for which patches have already been released.",
                "Automated vulnerability scanners routinely sweep networks for unpatched software versions. Enabling automatic updates for the operating system, web browsers, and runtime environments (like Java) dramatically shrinks the workstation attack surface.",
                "Rule: Apply critical security patches within 48 to 72 hours of vendor release.",
                "🔄"
        ));

        // ── 5. Device & Account Security ──
        allTips.add(new SecurityTip(
                "dev-1",
                "Device & Account Security",
                "Enforce Hardware-Based Multi-Factor Authentication (MFA)",
                "SMS-based 2FA is susceptible to SIM-swapping and adversary-in-the-middle phishing proxies.",
                "Wherever supported, prioritize FIDO2/WebAuthn hardware security keys (e.g. YubiKey) or time-based authenticator apps (TOTP) over SMS or email verification codes. Hardware security keys are cryptographically bound to the domain and prevent credential phishing.",
                "Protection: Even if an attacker steals your password, they cannot authenticate without physical possession of the hardware token.",
                "🔑"
        ));

        allTips.add(new SecurityTip(
                "dev-2",
                "Device & Account Security",
                "Operate Workstations Under the Principle of Least Privilege",
                "Logging in as a local administrator allows any malware or compromised script to execute with full system kernel access.",
                "Perform daily computing tasks (web browsing, document editing, and communications) from a standard, non-privileged user account. Elevate privileges via User Account Control (UAC) only when executing trusted administrative installations.",
                "Benefit: Ransomware running under standard user privileges cannot overwrite system-protected core directories or modify boot sectors.",
                "🛡️"
        ));

        // ── 6. Privacy & Data Handling ──
        allTips.add(new SecurityTip(
                "priv-1",
                "Privacy & Data Handling",
                "Avoid Cloud-Based Password Generators & Hash Checkers",
                "Online web utilities frequently log submitted credentials, IP addresses, and file hashes to analytics providers or search engines.",
                "Using cloud sites to generate passwords or check hashes introduces third-party exposure risk. NETTECH executes 100% locally and offline: no plaintext passwords are ever persisted to disk, and no hashes or file contents leave your machine.",
                "Guarantee: Local calculation eliminates network eavesdropping and data aggregation by commercial telemetry platforms.",
                "🔒"
        ));

        allTips.add(new SecurityTip(
                "priv-2",
                "Privacy & Data Handling",
                "Secure File Deletion and Full-Disk Encryption",
                "Standard operating system file deletion merely unlinks filesystem metadata, leaving file bytes intact on storage blocks.",
                "Enable full-disk encryption (e.g. BitLocker on Windows) to protect your workstation against physical disk theft. For sensitive files, utilize cryptographic shredding rather than standard deletion.",
                "Insight: Without full-disk encryption, an adversary with physical access to your drive can read database and cache files directly.",
                "💾"
        ));
    }

    public List<SecurityTip> getAllTips() {
        return allTips;
    }
}
