package com.nettech.securechecker.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Security-related utility methods.
 * <p>
 * Full implementations (password generation, hashing) will be added
 * in later phases. This class provides foundational helpers.
 */
public final class SecurityUtils {

    private static final DateTimeFormatter TIMESTAMP_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private SecurityUtils() {
        // Prevent instantiation
    }

    /**
     * Returns the current timestamp as a formatted string.
     *
     * @return formatted timestamp string
     */
    public static String currentTimestamp() {
        return LocalDateTime.now().format(TIMESTAMP_FORMAT);
    }

    /**
     * Validates that a password length is within acceptable bounds.
     *
     * @param length the password length to validate
     * @return true if the length is within [MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH]
     */
    public static boolean isValidPasswordLength(int length) {
        return length >= Constants.MIN_PASSWORD_LENGTH
                && length <= Constants.MAX_PASSWORD_LENGTH;
    }

    /**
     * Masks a string for safe display (e.g., in logs or reports).
     * Returns asterisks of the same length.
     *
     * @param sensitive the string to mask
     * @return masked string
     */
    public static String mask(String sensitive) {
        if (sensitive == null || sensitive.isEmpty()) {
            return "";
        }
        return "*".repeat(sensitive.length());
    }

    /**
     * Validates that a hash string looks like a valid hex hash of the
     * expected length.
     *
     * @param hash           the hash string to validate
     * @param expectedLength the expected character length (32 for MD5, 64 for SHA-256)
     * @return true if the hash matches the expected pattern
     */
    public static boolean isValidHexHash(String hash, int expectedLength) {
        if (hash == null || hash.length() != expectedLength) {
            return false;
        }
        return hash.matches("[a-fA-F0-9]+");
    }
}
