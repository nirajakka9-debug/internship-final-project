package com.nettech.securechecker.model;

/**
 * Represents a generated security report.
 */
public class SecurityReport {

    private int id;
    private String reportType;   // e.g., "PASSWORD_SUMMARY", "INTEGRITY_SUMMARY", "FULL"
    private String fileName;
    private String generatedAt;
    private String outputPath;

    /** Default constructor. */
    public SecurityReport() {
    }

    /**
     * Full constructor (without id, for new records).
     */
    public SecurityReport(String reportType, String fileName,
                          String generatedAt, String outputPath) {
        this.reportType  = reportType;
        this.fileName    = fileName;
        this.generatedAt = generatedAt;
        this.outputPath  = outputPath;
    }

    // ── Getters & Setters ──────────────────────────────────────

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(String generatedAt) {
        this.generatedAt = generatedAt;
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }

    @Override
    public String toString() {
        return "SecurityReport{" +
                "id=" + id +
                ", reportType='" + reportType + '\'' +
                ", fileName='" + fileName + '\'' +
                ", generatedAt='" + generatedAt + '\'' +
                ", outputPath='" + outputPath + '\'' +
                '}';
    }
}
