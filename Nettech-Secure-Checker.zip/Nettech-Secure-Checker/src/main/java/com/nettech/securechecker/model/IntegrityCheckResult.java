package com.nettech.securechecker.model;

/**
 * Model representing the comprehensive evaluation of an integrity verification check.
 */
public class IntegrityCheckResult {

    private final Integer referenceId;
    private final String fileName;
    private final String expectedMd5;
    private final String actualMd5;
    private final String expectedSha256;
    private final String actualSha256;
    private final String result; // VERIFIED, MODIFIED, UNABLE_TO_VERIFY
    private final String checkedAt;
    private final String explanation;

    public IntegrityCheckResult(Integer referenceId, String fileName,
                                String expectedMd5, String actualMd5,
                                String expectedSha256, String actualSha256,
                                String result, String checkedAt,
                                String explanation) {
        this.referenceId = referenceId;
        this.fileName = fileName;
        this.expectedMd5 = expectedMd5;
        this.actualMd5 = actualMd5;
        this.expectedSha256 = expectedSha256;
        this.actualSha256 = actualSha256;
        this.result = result;
        this.checkedAt = checkedAt;
        this.explanation = explanation;
    }

    public Integer getReferenceId() {
        return referenceId;
    }

    public String getFileName() {
        return fileName;
    }

    public String getExpectedMd5() {
        return expectedMd5;
    }

    public String getActualMd5() {
        return actualMd5;
    }

    public String getExpectedSha256() {
        return expectedSha256;
    }

    public String getActualSha256() {
        return actualSha256;
    }

    public String getResult() {
        return result;
    }

    public String getCheckedAt() {
        return checkedAt;
    }

    public String getExplanation() {
        return explanation;
    }

    public boolean isVerified() {
        return "VERIFIED".equalsIgnoreCase(result);
    }

    public boolean isModified() {
        return "MODIFIED".equalsIgnoreCase(result);
    }

    @Override
    public String toString() {
        return "IntegrityCheckResult{" +
                "referenceId=" + referenceId +
                ", fileName='" + fileName + '\'' +
                ", result='" + result + '\'' +
                ", checkedAt='" + checkedAt + '\'' +
                ", explanation='" + explanation + '\'' +
                '}';
    }
}
