package com.nettech.securechecker.service;

import com.nettech.securechecker.model.PasswordStrengthResult;
import com.nettech.securechecker.util.Constants;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Service dedicated to evaluating password complexity, detecting vulnerabilities,
 * and computing deterministic strength scores.
 * <p>
 * <b>SECURITY INVARIANT:</b> All analysis is performed entirely offline and locally.
 * Plaintext passwords are analyzed transiently in-memory and are never stored in the result model.
 */
public class PasswordStrengthService {

    // Common weak words / phrases (checked case-insensitively)
    private static final String[] COMMON_PATTERNS = {
            "password", "admin", "administrator", "qwerty", "123456", "12345678", "123456789",
            "abcdef", "letmein", "welcome", "login", "master", "iloveyou", "secret",
            "pass123", "root", "default", "access", "testing", "changeme", "football", "dragon"
    };

    // Keyboard sequence patterns
    private static final String[] KEYBOARD_SEQUENCES = {
            "qwerty", "asdfgh", "zxcvbn", "qwertz", "azerty", "poiuyt", "lkjhgf", "mnbvcx"
    };

    // Precompiled regex patterns for performance and memory efficiency
    private static final Pattern LOWER_PATTERN = Pattern.compile("[a-z]");
    private static final Pattern UPPER_PATTERN = Pattern.compile("[A-Z]");
    private static final Pattern DIGIT_PATTERN = Pattern.compile("[0-9]");
    private static final Pattern REPEATED_CHAR_PATTERN = Pattern.compile("(.)\\1{2,}");

    /**
     * Performs a comprehensive, deterministic security assessment on the provided password.
     *
     * @param password the password to evaluate (can be null or empty)
     * @return a {@link PasswordStrengthResult} containing metrics, score, and recommendations
     */
    public PasswordStrengthResult analyzeStrength(String password) {
        if (password == null || password.isEmpty()) {
            List<String> recs = new ArrayList<>();
            recs.add("Provide a non-empty password of at least 12–16 characters.");
            return new PasswordStrengthResult(
                    0,
                    Constants.STRENGTH_VERY_WEAK,
                    0,
                    false, false, false, false,
                    false, false, false,
                    recs
            );
        }

        int length = password.length();
        boolean hasLower   = LOWER_PATTERN.matcher(password).find();
        boolean hasUpper   = UPPER_PATTERN.matcher(password).find();
        boolean hasDigits  = DIGIT_PATTERN.matcher(password).find();
        boolean hasSpecial = hasSpecialCharacter(password);

        boolean repeatedChars = hasRepeatedCharacters(password);
        boolean sequentialPatterns = hasSequentialPatterns(password);
        boolean commonPatterns = hasCommonPatterns(password);

        int score = calculateScore(length, hasLower, hasUpper, hasDigits, hasSpecial,
                repeatedChars, sequentialPatterns, commonPatterns);

        String label = resolveStrengthLabel(score);
        List<String> recommendations = generateRecommendations(
                length, hasLower, hasUpper, hasDigits, hasSpecial,
                repeatedChars, sequentialPatterns, commonPatterns
        );

        return new PasswordStrengthResult(
                score,
                label,
                length,
                hasLower,
                hasUpper,
                hasDigits,
                hasSpecial,
                repeatedChars,
                sequentialPatterns,
                commonPatterns,
                recommendations
        );
    }

    /**
     * Calculates a deterministic score from 0 to 100 based on measurable complexity factors.
     */
    public int calculateScore(int length, boolean hasLower, boolean hasUpper,
                              boolean hasDigits, boolean hasSpecial,
                              boolean repeatedChars, boolean sequentialPatterns,
                              boolean commonPatterns) {
        if (length == 0) {
            return 0;
        }

        int score = 0;

        // 1. Length contribution (up to 55 points)
        if (length < 8) {
            score += length * 3; // 3 to 21
        } else if (length <= 11) {
            score += 25 + (length - 8) * 4; // 25 to 37
        } else if (length <= 15) {
            score += 40 + (length - 12) * 4; // 40 to 52
        } else if (length <= 20) {
            score += 55 + (length - 16) * 3; // 55 to 67
        } else {
            score += 70 + Math.min(10, (length - 20)); // 70 to 80
        }

        // 2. Character diversity bonuses (up to 30 points)
        int varietyCount = 0;
        if (hasLower) {
            score += 6;
            varietyCount++;
        }
        if (hasUpper) {
            score += 6;
            varietyCount++;
        }
        if (hasDigits) {
            score += 6;
            varietyCount++;
        }
        if (hasSpecial) {
            score += 8;
            varietyCount++;
        }
        if (varietyCount >= 4) {
            score += 4; // Full combo bonus
        }

        // 3. Penalties for weak habits & structure
        if (varietyCount <= 1) {
            score -= 15; // Single category penalty (e.g. all digits or all lowercase)
        }
        if (repeatedChars) {
            score -= 15;
        }
        if (sequentialPatterns) {
            score -= 15;
        }
        if (commonPatterns) {
            score -= 30;
        }

        // Bound to [0, 100]
        return Math.max(0, Math.min(100, score));
    }

    /**
     * Resolves the string label based on the centralized score thresholds.
     */
    public String resolveStrengthLabel(int score) {
        if (score <= Constants.SCORE_VERY_WEAK_MAX) {
            return Constants.STRENGTH_VERY_WEAK;
        } else if (score <= Constants.SCORE_WEAK_MAX) {
            return Constants.STRENGTH_WEAK;
        } else if (score <= Constants.SCORE_MODERATE_MAX) {
            return Constants.STRENGTH_MODERATE;
        } else if (score <= Constants.SCORE_STRONG_MAX) {
            return Constants.STRENGTH_STRONG;
        } else {
            return Constants.STRENGTH_VERY_STRONG;
        }
    }

    /**
     * Detects 3 or more consecutive identical characters (e.g., "aaa", "1111", "!!!!").
     */
    public boolean hasRepeatedCharacters(String password) {
        if (password == null || password.length() < 3) {
            return false;
        }
        return REPEATED_CHAR_PATTERN.matcher(password).find();
    }

    /**
     * Detects 3+ consecutive sequential alphabetical, numeric, or keyboard sequences.
     * Examples: "1234", "4321", "abcd", "dcba", "qwer", "asdf".
     */
    public boolean hasSequentialPatterns(String password) {
        if (password == null || password.length() < 3) {
            return false;
        }

        String lower = password.toLowerCase();

        // Check alphabetical and numeric runs (e.g. abc, cba, 123, 321)
        for (int i = 0; i <= lower.length() - 3; i++) {
            char c1 = lower.charAt(i);
            char c2 = lower.charAt(i + 1);
            char c3 = lower.charAt(i + 2);

            boolean areDigits = Character.isDigit(c1) && Character.isDigit(c2) && Character.isDigit(c3);
            boolean areLetters = Character.isLowerCase(c1) && Character.isLowerCase(c2) && Character.isLowerCase(c3);

            if (areDigits || areLetters) {
                // Forward alphabetical / numeric sequence
                if (c2 == c1 + 1 && c3 == c2 + 1) {
                    return true;
                }
                // Reverse alphabetical / numeric sequence
                if (c2 == c1 - 1 && c3 == c2 - 1) {
                    return true;
                }
            }
        }

        // Check keyboard row sequences
        for (String seq : KEYBOARD_SEQUENCES) {
            for (int i = 0; i <= seq.length() - 3; i++) {
                String sub = seq.substring(i, i + 3);
                String rev = new StringBuilder(sub).reverse().toString();
                if (lower.contains(sub) || lower.contains(rev)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Detects known common passwords or predictable dictionary words.
     */
    public boolean hasCommonPatterns(String password) {
        if (password == null || password.isEmpty()) {
            return false;
        }
        String lower = password.toLowerCase();
        for (String pattern : COMMON_PATTERNS) {
            if (lower.contains(pattern)) {
                return true;
            }
        }
        return false;
    }


    private boolean hasSpecialCharacter(String input) {
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Constants.CHARSET_SPECIAL.indexOf(c) != -1 || (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c))) {
                return true;
            }
        }
        return false;
    }

    private List<String> generateRecommendations(int length, boolean hasLower, boolean hasUpper,
                                                 boolean hasDigits, boolean hasSpecial,
                                                 boolean repeatedChars, boolean sequentialPatterns,
                                                 boolean commonPatterns) {
        List<String> recommendations = new ArrayList<>();

        if (length < 12) {
            recommendations.add("Increase password length to at least 12–16 characters.");
        }
        if (!hasUpper) {
            recommendations.add("Add uppercase letters (A–Z).");
        }
        if (!hasLower) {
            recommendations.add("Add lowercase letters (a–z).");
        }
        if (!hasDigits) {
            recommendations.add("Add numeric digits (0–9).");
        }
        if (!hasSpecial) {
            recommendations.add("Add special characters (e.g., !@#$%^&*).");
        }
        if (repeatedChars) {
            recommendations.add("Avoid consecutive repeating characters (e.g., 'aaa' or '111').");
        }
        if (sequentialPatterns) {
            recommendations.add("Avoid sequential character series (e.g., '1234', 'abcd', 'qwerty').");
        }
        if (commonPatterns) {
            recommendations.add("Avoid common dictionary words, names, or predictable substitutions.");
        }
        if (recommendations.isEmpty()) {
            recommendations.add("Password meets high complexity and entropy standards.");
        }

        return recommendations;
    }
}
