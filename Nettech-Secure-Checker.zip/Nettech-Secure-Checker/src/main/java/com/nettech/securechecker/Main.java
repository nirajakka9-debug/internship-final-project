package com.nettech.securechecker;

import com.nettech.securechecker.app.NettechApplication;

/**
 * Application entry point.
 * <p>
 * This class exists as the main entry point so that the application
 * can be launched without extending {@link javafx.application.Application}
 * directly in the main class — which avoids module-system issues when
 * running from a classpath JAR.
 */
public class Main {

    public static void main(String[] args) {
        NettechApplication.launch(NettechApplication.class, args);
    }
}
