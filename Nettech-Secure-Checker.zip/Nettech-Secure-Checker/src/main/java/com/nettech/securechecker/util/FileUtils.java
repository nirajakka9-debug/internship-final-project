package com.nettech.securechecker.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * File-system utility methods.
 */
public final class FileUtils {

    private FileUtils() {
        // Prevent instantiation
    }

    /**
     * Ensures that a directory exists, creating it if necessary.
     *
     * @param directoryPath the path to the directory
     * @return true if the directory exists or was created successfully
     */
    public static boolean ensureDirectoryExists(String directoryPath) {
        if (directoryPath == null || directoryPath.isBlank()) {
            return false;
        }
        File dir = new File(directoryPath);
        if (dir.exists()) {
            return dir.isDirectory();
        }
        return dir.mkdirs();
    }

    /**
     * Returns the file size in bytes, or -1 if the file does not exist.
     *
     * @param filePath the path to the file
     * @return file size in bytes, or -1
     */
    public static long getFileSize(String filePath) {
        if (filePath == null || filePath.isBlank()) {
            return -1;
        }
        File file = new File(filePath);
        return file.exists() ? file.length() : -1;
    }

    /**
     * Returns the file name from a full path.
     *
     * @param filePath the full path
     * @return the file name component
     */
    public static String getFileName(String filePath) {
        if (filePath == null || filePath.isBlank()) {
            return "";
        }
        Path path = Path.of(filePath);
        Path fileName = path.getFileName();
        return fileName != null ? fileName.toString() : "";
    }

    /**
     * Checks whether a file exists and is readable.
     *
     * @param filePath the path to check
     * @return true if the file exists and is readable
     */
    public static boolean isReadableFile(String filePath) {
        if (filePath == null || filePath.isBlank()) {
            return false;
        }
        File file = new File(filePath);
        return file.exists() && file.isFile() && file.canRead();
    }
}
