package com.nettech.securechecker.model;

/**
 * Represents the result of a single file-integrity check, comparing
 * the expected hashes (from an {@link IntegrityReference}) against
 * the actual hashes computed at check time.
 */
public class IntegrityCheck {

    private int id;
    private Integer referenceId;
    private String fileName;
    private String checkedAt;
    private String expectedMd5;
    private String actualMd5;
    private String expectedSha256;
    private String actualSha256;
    private String result;  // e.g., "PASS", "FAIL", "ERROR"

    /** Default constructor. */
    public IntegrityCheck() {
    }

    /**
     * Full constructor (without id, for new records).
     */
    public IntegrityCheck(Integer referenceId, String fileName, String checkedAt,
                          String expectedMd5, String actualMd5,
                          String expectedSha256, String actualSha256,
                          String result) {
        this.referenceId   = referenceId;
        this.fileName      = fileName;
        this.checkedAt     = checkedAt;
        this.expectedMd5   = expectedMd5;
        this.actualMd5     = actualMd5;
        this.expectedSha256 = expectedSha256;
        this.actualSha256  = actualSha256;
        this.result        = result;
    }

    // ── Getters & Setters ──────────────────────────────────────

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(Integer referenceId) {
        this.referenceId = referenceId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getCheckedAt() {
        return checkedAt;
    }

    public void setCheckedAt(String checkedAt) {
        this.checkedAt = checkedAt;
    }

    public String getExpectedMd5() {
        return expectedMd5;
    }

    public void setExpectedMd5(String expectedMd5) {
        this.expectedMd5 = expectedMd5;
    }

    public String getActualMd5() {
        return actualMd5;
    }

    public void setActualMd5(String actualMd5) {
        this.actualMd5 = actualMd5;
    }

    public String getExpectedSha256() {
        return expectedSha256;
    }

    public void setExpectedSha256(String expectedSha256) {
        this.expectedSha256 = expectedSha256;
    }

    public String getActualSha256() {
        return actualSha256;
    }

    public void setActualSha256(String actualSha256) {
        this.actualSha256 = actualSha256;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "IntegrityCheck{" +
                "id=" + id +
                ", referenceId=" + referenceId +
                ", fileName='" + fileName + '\'' +
                ", checkedAt='" + checkedAt + '\'' +
                ", result='" + result + '\'' +
                '}';
    }
}
