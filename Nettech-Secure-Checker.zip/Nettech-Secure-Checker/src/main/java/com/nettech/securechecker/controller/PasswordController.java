package com.nettech.securechecker.controller;

import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.model.PasswordStrengthResult;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.service.PasswordService;
import com.nettech.securechecker.service.PasswordStrengthService;
import com.nettech.securechecker.util.Constants;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;

import java.util.List;
import java.util.Optional;

/**
 * Controller for the Password Security UI module.
 * <p>
 * Manages UI view components for:
 * <ul>
 *   <li>CSPRNG Password Generation with custom length & character category filters</li>
 *   <li>Real-time Password Complexity & Entropy Strength Analysis</li>
 *   <li>Zero-knowledge Password History metadata inspection & management</li>
 * </ul>
 * <p>
 * <b>SECURITY INVARIANT:</b> Cryptographic operations and scoring are strictly delegated
 * to {@link PasswordService} and {@link PasswordStrengthService}. Plaintext passwords
 * are never logged, printed, or persisted in the database.
 */
public class PasswordController {

    private final PasswordService passwordService;
    private final PasswordStrengthService strengthService;
    private final PasswordHistoryRepository historyRepository;

    // ── UI Components: Generator ───────────────────────────────
    private Slider lengthSlider;
    private Label lengthValueLabel;
    private CheckBox cbUpper;
    private CheckBox cbLower;
    private CheckBox cbDigits;
    private CheckBox cbSpecial;
    private TextField generatedPasswordField;
    private PasswordField generatedPasswordHiddenField;
    private Button btnToggleShowGenerated;
    private boolean isGeneratedPasswordVisible = true;
    private Button btnCopyPassword;
    private Label genFeedbackLabel;
    private ProgressBar genProgressBar;
    private Label genScoreLabel;
    private Label genStrengthBadge;
    private String currentGeneratedPassword = "";

    // ── UI Components: Strength Checker ────────────────────────
    private TextField inputPasswordField;
    private PasswordField inputPasswordHiddenField;
    private Button btnToggleShowInput;
    private boolean isInputPasswordVisible = true;
    private ProgressBar checkerProgressBar;
    private Label checkerScoreLabel;
    private Label checkerStrengthBadge;
    private HBox categoryIndicatorsBox;
    private VBox warningsContainer;
    private VBox recommendationsContainer;
    private Label checkerFeedbackLabel;

    // ── UI Components: History ─────────────────────────────────
    private TableView<PasswordHistory> historyTable;
    private ObservableList<PasswordHistory> historyData;
    private Label historyCountLabel;

    public PasswordController() {
        this.strengthService = new PasswordStrengthService();
        this.historyRepository = new PasswordHistoryRepository(DatabaseManager.getInstance());
        this.passwordService = new PasswordService(this.strengthService, this.historyRepository);
        this.historyData = FXCollections.observableArrayList();
    }

    public PasswordController(PasswordService passwordService,
                              PasswordStrengthService strengthService,
                              PasswordHistoryRepository historyRepository) {
        this.passwordService = passwordService;
        this.strengthService = strengthService;
        this.historyRepository = historyRepository;
        this.historyData = FXCollections.observableArrayList();
    }

    /**
     * Builds and returns the complete Password Security interface layout.
     */
    public Region getView() {
        VBox root = new VBox(24);
        root.setPadding(new Insets(0));

        // ── Header ──
        Label title = new Label("Password Security");
        title.getStyleClass().add("page-title");

        Label subtitle = new Label("Generate cryptographically secure credentials, analyze complexity, and inspect generation history.");
        subtitle.getStyleClass().add("page-subtitle");

        // ── Top Section: Generator (Left) and Strength Checker (Right) ──
        HBox cardsGrid = new HBox(20);
        cardsGrid.setAlignment(Pos.TOP_LEFT);

        VBox generatorCard = buildGeneratorCard();
        VBox strengthCard = buildStrengthCheckerCard();

        HBox.setHgrow(generatorCard, Priority.ALWAYS);
        HBox.setHgrow(strengthCard, Priority.ALWAYS);
        cardsGrid.getChildren().addAll(generatorCard, strengthCard);

        // ── Bottom Section: History ──
        VBox historySection = buildHistorySection();

        root.getChildren().addAll(title, subtitle, cardsGrid, historySection);

        // Load initial history in background
        loadHistoryData();

        return root;
    }

    // =========================================================================
    // A. PASSWORD GENERATOR CARD
    // =========================================================================

    private VBox buildGeneratorCard() {
        VBox card = new VBox(16);
        card.getStyleClass().add("card");

        // Title & Info
        Label cardTitle = new Label("🔑  Secure Password Generator");
        cardTitle.getStyleClass().add("card-title");
        cardTitle.setStyle("-fx-font-size: 15px; -fx-text-fill: -nt-accent;");

        Label cardDesc = new Label("Generate high-entropy random passwords using java.security.SecureRandom.");
        cardDesc.getStyleClass().add("card-value");
        cardDesc.setWrapText(true);

        // ── Length Selector ──
        VBox lengthBox = new VBox(6);
        HBox lengthHeader = new HBox(8);
        lengthHeader.setAlignment(Pos.CENTER_LEFT);

        Label lengthTitle = new Label("Password Length:");
        lengthTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12.5px;");

        lengthValueLabel = new Label(String.valueOf(Constants.DEFAULT_PASSWORD_LENGTH));
        lengthValueLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-accent; -fx-font-size: 13px;");

        lengthHeader.getChildren().addAll(lengthTitle, lengthValueLabel);

        lengthSlider = new Slider(Constants.MIN_PASSWORD_LENGTH, Constants.MAX_PASSWORD_LENGTH, Constants.DEFAULT_PASSWORD_LENGTH);
        lengthSlider.setShowTickMarks(false);
        lengthSlider.setShowTickLabels(false);
        lengthSlider.setMajorTickUnit(16);
        lengthSlider.setBlockIncrement(1);
        lengthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            int val = newVal.intValue();
            lengthValueLabel.setText(String.valueOf(val));
        });

        lengthBox.getChildren().addAll(lengthHeader, lengthSlider);

        // ── Character Categories ──
        Label categoriesTitle = new Label("Character Categories:");
        categoriesTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12.5px;");

        GridPane categoriesGrid = new GridPane();
        categoriesGrid.setHgap(16);
        categoriesGrid.setVgap(8);

        cbUpper   = new CheckBox("Uppercase (A–Z)");
        cbLower   = new CheckBox("Lowercase (a–z)");
        cbDigits  = new CheckBox("Numbers (0–9)");
        cbSpecial = new CheckBox("Symbols (!@#$%...)");

        cbUpper.setSelected(true);
        cbLower.setSelected(true);
        cbDigits.setSelected(true);
        cbSpecial.setSelected(true);

        categoriesGrid.add(cbUpper, 0, 0);
        categoriesGrid.add(cbLower, 1, 0);
        categoriesGrid.add(cbDigits, 0, 1);
        categoriesGrid.add(cbSpecial, 1, 1);

        // ── Generate Button ──
        Button btnGenerate = new Button("⚡  Generate Password");
        btnGenerate.getStyleClass().add("action-button-primary");
        btnGenerate.setMaxWidth(Double.MAX_VALUE);
        btnGenerate.setOnAction(e -> handleGeneratePassword());

        // ── Output Field & Controls ──
        VBox outputBox = new VBox(8);

        HBox passwordFieldBox = new HBox(8);
        passwordFieldBox.setAlignment(Pos.CENTER_LEFT);

        generatedPasswordField = new TextField();
        generatedPasswordField.setEditable(false);
        generatedPasswordField.setPromptText("Generated password will appear here...");
        generatedPasswordField.getStyleClass().addAll("text-field", "text-field-readonly");
        HBox.setHgrow(generatedPasswordField, Priority.ALWAYS);

        generatedPasswordHiddenField = new PasswordField();
        generatedPasswordHiddenField.setEditable(false);
        generatedPasswordHiddenField.getStyleClass().addAll("password-field", "text-field-readonly");
        generatedPasswordHiddenField.setVisible(false);
        generatedPasswordHiddenField.setManaged(false);
        HBox.setHgrow(generatedPasswordHiddenField, Priority.ALWAYS);

        btnToggleShowGenerated = new Button("👁");
        btnToggleShowGenerated.getStyleClass().add("action-button");
        btnToggleShowGenerated.setTooltip(new Tooltip("Show/Hide password"));
        btnToggleShowGenerated.setOnAction(e -> toggleShowGeneratedPassword());

        btnCopyPassword = new Button("📋  Copy");
        btnCopyPassword.getStyleClass().add("action-button");
        btnCopyPassword.setTooltip(new Tooltip("Copy to clipboard"));
        btnCopyPassword.setDisable(true);
        btnCopyPassword.setOnAction(e -> handleCopyGeneratedPassword());

        passwordFieldBox.getChildren().addAll(generatedPasswordField, generatedPasswordHiddenField, btnToggleShowGenerated, btnCopyPassword);

        // Strength Feedback
        HBox genMetricsRow = new HBox(12);
        genMetricsRow.setAlignment(Pos.CENTER_LEFT);

        genProgressBar = new ProgressBar(0);
        genProgressBar.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(genProgressBar, Priority.ALWAYS);

        genScoreLabel = new Label("Score: —");
        genScoreLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-secondary;");

        genStrengthBadge = new Label("None");
        genStrengthBadge.getStyleClass().addAll("status-badge", "status-warning");

        genMetricsRow.getChildren().addAll(genProgressBar, genScoreLabel, genStrengthBadge);

        genFeedbackLabel = new Label();
        genFeedbackLabel.setWrapText(true);

        outputBox.getChildren().addAll(passwordFieldBox, genMetricsRow, genFeedbackLabel);

        card.getChildren().addAll(
                cardTitle, cardDesc,
                lengthBox, categoriesTitle, categoriesGrid,
                btnGenerate, outputBox
        );
        return card;
    }

    private void handleGeneratePassword() {
        int length = (int) lengthSlider.getValue();
        boolean upper = cbUpper.isSelected();
        boolean lower = cbLower.isSelected();
        boolean digits = cbDigits.isSelected();
        boolean special = cbSpecial.isSelected();

        if (!upper && !lower && !digits && !special) {
            genFeedbackLabel.setText("⚠ Please select at least one character category.");
            genFeedbackLabel.getStyleClass().setAll("feedback-error");
            return;
        }

        try {
            currentGeneratedPassword = passwordService.generatePassword(length, upper, lower, digits, special);

            generatedPasswordField.setText(currentGeneratedPassword);
            generatedPasswordHiddenField.setText(currentGeneratedPassword);
            btnCopyPassword.setDisable(false);

            // Assess strength
            PasswordStrengthResult strength = strengthService.analyzeStrength(currentGeneratedPassword);
            updateStrengthVisuals(strength, genProgressBar, genScoreLabel, genStrengthBadge);

            // Record metadata to history (Safe: only length, strength, score)
            passwordService.recordToHistory(length, strength.getStrengthLabel(), strength.getScore());

            genFeedbackLabel.setText("✓ Password generated securely and recorded to history metadata.");
            genFeedbackLabel.getStyleClass().setAll("feedback-success");

            // Refresh history table
            loadHistoryData();

        } catch (Exception ex) {
            genFeedbackLabel.setText("Error generating password: " + ex.getMessage());
            genFeedbackLabel.getStyleClass().setAll("feedback-error");
        }
    }

    private void toggleShowGeneratedPassword() {
        isGeneratedPasswordVisible = !isGeneratedPasswordVisible;
        if (isGeneratedPasswordVisible) {
            generatedPasswordField.setVisible(true);
            generatedPasswordField.setManaged(true);
            generatedPasswordHiddenField.setVisible(false);
            generatedPasswordHiddenField.setManaged(false);
            btnToggleShowGenerated.setText("👁");
        } else {
            generatedPasswordField.setVisible(false);
            generatedPasswordField.setManaged(false);
            generatedPasswordHiddenField.setVisible(true);
            generatedPasswordHiddenField.setManaged(true);
            btnToggleShowGenerated.setText("🙈");
        }
    }

    private void handleCopyGeneratedPassword() {
        if (currentGeneratedPassword == null || currentGeneratedPassword.isEmpty()) {
            return;
        }
        ClipboardContent content = new ClipboardContent();
        content.putString(currentGeneratedPassword);
        Clipboard.getSystemClipboard().setContent(content);

        genFeedbackLabel.setText("✓ Password copied to clipboard!");
        genFeedbackLabel.getStyleClass().setAll("feedback-success");
    }

    // =========================================================================
    // B. PASSWORD STRENGTH CHECKER CARD
    // =========================================================================

    private VBox buildStrengthCheckerCard() {
        VBox card = new VBox(16);
        card.getStyleClass().add("card");

        // Title & Info
        Label cardTitle = new Label("🔍  Password Strength Analyzer");
        cardTitle.getStyleClass().add("card-title");
        cardTitle.setStyle("-fx-font-size: 15px; -fx-text-fill: -nt-accent;");

        Label cardDesc = new Label("Inspect entropy, character diversity, repeating patterns, and sequence vulnerabilities.");
        cardDesc.getStyleClass().add("card-value");
        cardDesc.setWrapText(true);

        // Input Box
        VBox inputBox = new VBox(6);
        Label inputLabel = new Label("Enter Password to Analyze:");
        inputLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12.5px;");

        HBox inputFieldBox = new HBox(8);
        inputFieldBox.setAlignment(Pos.CENTER_LEFT);

        inputPasswordField = new TextField();
        inputPasswordField.setPromptText("Type or paste a password...");
        inputPasswordField.getStyleClass().add("text-field");
        HBox.setHgrow(inputPasswordField, Priority.ALWAYS);

        inputPasswordHiddenField = new PasswordField();
        inputPasswordHiddenField.setPromptText("Type or paste a password...");
        inputPasswordHiddenField.getStyleClass().add("password-field");
        inputPasswordHiddenField.setVisible(false);
        inputPasswordHiddenField.setManaged(false);
        HBox.setHgrow(inputPasswordHiddenField, Priority.ALWAYS);

        btnToggleShowInput = new Button("👁");
        btnToggleShowInput.getStyleClass().add("action-button");
        btnToggleShowInput.setTooltip(new Tooltip("Show/Hide password"));
        btnToggleShowInput.setOnAction(e -> toggleShowInputPassword());

        Button btnAnalyze = new Button("Analyze");
        btnAnalyze.getStyleClass().add("action-button-primary");
        btnAnalyze.setOnAction(e -> handleAnalyzePassword());

        // Sync text and auto-analyze on change
        inputPasswordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!inputPasswordHiddenField.getText().equals(newVal)) {
                inputPasswordHiddenField.setText(newVal);
            }
            handleAnalyzePassword();
        });
        inputPasswordHiddenField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!inputPasswordField.getText().equals(newVal)) {
                inputPasswordField.setText(newVal);
            }
            handleAnalyzePassword();
        });

        inputFieldBox.getChildren().addAll(inputPasswordField, inputPasswordHiddenField, btnToggleShowInput, btnAnalyze);
        inputBox.getChildren().addAll(inputLabel, inputFieldBox);

        // ── Analysis Results Panel ──
        VBox resultsBox = new VBox(10);
        resultsBox.setStyle("-fx-background-color: #111622; -fx-padding: 14; -fx-background-radius: 8; -fx-border-color: -nt-border; -fx-border-radius: 8;");

        // Score row
        HBox scoreRow = new HBox(12);
        scoreRow.setAlignment(Pos.CENTER_LEFT);

        checkerProgressBar = new ProgressBar(0);
        checkerProgressBar.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(checkerProgressBar, Priority.ALWAYS);

        checkerScoreLabel = new Label("Score: 0 / 100");
        checkerScoreLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary;");

        checkerStrengthBadge = new Label("Empty");
        checkerStrengthBadge.getStyleClass().addAll("status-badge", "status-danger");

        scoreRow.getChildren().addAll(checkerProgressBar, checkerScoreLabel, checkerStrengthBadge);

        // Category Indicators
        categoryIndicatorsBox = new HBox(8);
        categoryIndicatorsBox.setAlignment(Pos.CENTER_LEFT);
        updateCategoryPills(false, false, false, false);

        // Warnings container
        warningsContainer = new VBox(4);

        // Recommendations container
        recommendationsContainer = new VBox(4);

        checkerFeedbackLabel = new Label();
        checkerFeedbackLabel.setStyle("-fx-font-size: 11.5px; -fx-text-fill: -nt-text-muted;");

        resultsBox.getChildren().addAll(scoreRow, categoryIndicatorsBox, warningsContainer, recommendationsContainer, checkerFeedbackLabel);

        card.getChildren().addAll(cardTitle, cardDesc, inputBox, resultsBox);
        return card;
    }

    private void toggleShowInputPassword() {
        isInputPasswordVisible = !isInputPasswordVisible;
        if (isInputPasswordVisible) {
            inputPasswordField.setVisible(true);
            inputPasswordField.setManaged(true);
            inputPasswordHiddenField.setVisible(false);
            inputPasswordHiddenField.setManaged(false);
            btnToggleShowInput.setText("👁");
        } else {
            inputPasswordField.setVisible(false);
            inputPasswordField.setManaged(false);
            inputPasswordHiddenField.setVisible(true);
            inputPasswordHiddenField.setManaged(true);
            btnToggleShowInput.setText("🙈");
        }
    }

    private void handleAnalyzePassword() {
        String pwd = inputPasswordField.getText();
        if (pwd == null || pwd.isEmpty()) {
            checkerProgressBar.setProgress(0);
            checkerProgressBar.getStyleClass().setAll("progress-bar", "progress-very-weak");
            checkerScoreLabel.setText("Score: 0 / 100");
            checkerStrengthBadge.setText("Empty");
            checkerStrengthBadge.getStyleClass().setAll("status-badge", "status-danger");
            updateCategoryPills(false, false, false, false);
            warningsContainer.getChildren().clear();
            recommendationsContainer.getChildren().clear();
            checkerFeedbackLabel.setText("Enter a password to inspect security strength and recommendations.");
            return;
        }

        PasswordStrengthResult result = strengthService.analyzeStrength(pwd);
        updateStrengthVisuals(result, checkerProgressBar, checkerScoreLabel, checkerStrengthBadge);
        updateCategoryPills(result.hasLowercase(), result.hasUppercase(), result.hasDigits(), result.hasSpecialCharacters());

        // Warnings
        warningsContainer.getChildren().clear();
        if (result.isRepeatedCharacterDetected()) {
            Label warnRepeat = new Label("⚠  Warning: Repeating characters detected (e.g. 'aaa' or '111').");
            warnRepeat.getStyleClass().add("warning-pill");
            warningsContainer.getChildren().add(warnRepeat);
        }
        if (result.isSequentialPatternDetected()) {
            Label warnSeq = new Label("⚠  Warning: Sequential or keyboard pattern detected (e.g. '1234', 'abcd', 'qwerty').");
            warnSeq.getStyleClass().add("warning-pill");
            warningsContainer.getChildren().add(warnSeq);
        }
        if (result.isCommonPatternDetected()) {
            Label warnCommon = new Label("⚠  Critical Warning: Common dictionary word or predictable pattern found.");
            warnCommon.getStyleClass().add("warning-pill");
            warnCommon.setStyle("-fx-background-color: rgba(248, 81, 73, 0.2); -fx-text-fill: #f85149; -fx-border-color: rgba(248, 81, 73, 0.4);");
            warningsContainer.getChildren().add(warnCommon);
        }

        // Recommendations
        recommendationsContainer.getChildren().clear();
        Label recTitle = new Label("Recommendations:");
        recTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-secondary; -fx-font-size: 12px;");
        recommendationsContainer.getChildren().add(recTitle);

        for (String rec : result.getRecommendations()) {
            Label recItem = new Label("• " + rec);
            recItem.setStyle("-fx-text-fill: -nt-text-primary; -fx-font-size: 12px;");
            recItem.setWrapText(true);
            recommendationsContainer.getChildren().add(recItem);
        }

        checkerFeedbackLabel.setText("Local offline analysis complete. Zero password data is retained.");
    }

    private void updateCategoryPills(boolean lower, boolean upper, boolean digits, boolean special) {
        categoryIndicatorsBox.getChildren().clear();
        categoryIndicatorsBox.getChildren().addAll(
                createIndicatorPill("Lowercase", lower),
                createIndicatorPill("Uppercase", upper),
                createIndicatorPill("Numbers", digits),
                createIndicatorPill("Symbols", special)
        );
    }

    private Label createIndicatorPill(String title, boolean passed) {
        Label pill = new Label((passed ? "✓ " : "✗ ") + title);
        pill.getStyleClass().add("indicator-pill");
        if (passed) {
            pill.getStyleClass().add("indicator-pass");
        } else {
            pill.getStyleClass().add("indicator-fail");
        }
        return pill;
    }

    private void updateStrengthVisuals(PasswordStrengthResult result, ProgressBar pb, Label scoreLbl, Label badgeLbl) {
        int score = result.getScore();
        double progress = score / 100.0;
        pb.setProgress(progress);

        scoreLbl.setText("Score: " + score + " / 100");

        String label = result.getStrengthLabel();
        badgeLbl.setText(label);

        pb.getStyleClass().removeIf(s -> s.startsWith("progress-"));
        badgeLbl.getStyleClass().removeIf(s -> s.startsWith("status-"));
        badgeLbl.getStyleClass().add("status-badge");

        if (score <= Constants.SCORE_VERY_WEAK_MAX) {
            pb.getStyleClass().add("progress-very-weak");
            badgeLbl.getStyleClass().add("status-danger");
        } else if (score <= Constants.SCORE_WEAK_MAX) {
            pb.getStyleClass().add("progress-weak");
            badgeLbl.getStyleClass().add("status-warning");
        } else if (score <= Constants.SCORE_MODERATE_MAX) {
            pb.getStyleClass().add("progress-moderate");
            badgeLbl.getStyleClass().add("status-warning");
        } else if (score <= Constants.SCORE_STRONG_MAX) {
            pb.getStyleClass().add("progress-strong");
            badgeLbl.getStyleClass().add("status-secure");
        } else {
            pb.getStyleClass().add("progress-very-strong");
            badgeLbl.getStyleClass().add("status-secure");
        }
    }

    // =========================================================================
    // C. PASSWORD GENERATION HISTORY SECTION
    // =========================================================================

    @SuppressWarnings("unchecked")
    private VBox buildHistorySection() {
        VBox section = new VBox(12);

        // Header & Controls
        HBox headerRow = new HBox(12);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label sectionTitle = new Label("Password Generation History");
        sectionTitle.getStyleClass().add("section-heading");
        sectionTitle.setStyle("-fx-padding: 0;");

        historyCountLabel = new Label("Total: 0");
        historyCountLabel.setStyle("-fx-text-fill: -nt-text-muted; -fx-font-size: 13px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRefresh = new Button("⟳  Refresh");
        btnRefresh.getStyleClass().add("action-button");
        btnRefresh.setOnAction(e -> loadHistoryData());

        Button btnClear = new Button("🗑  Clear History");
        btnClear.getStyleClass().add("action-button");
        btnClear.setOnAction(e -> handleClearHistory());

        headerRow.getChildren().addAll(sectionTitle, historyCountLabel, spacer, btnRefresh, btnClear);

        // Zero-Knowledge Banner
        Label infoBanner = new Label("🛡️ Zero-Knowledge Guarantee: Plaintext passwords, hashes, and salts are never recorded in history.");
        infoBanner.getStyleClass().add("info-banner");
        infoBanner.setMaxWidth(Double.MAX_VALUE);

        // Table
        historyTable = new TableView<>(historyData);
        historyTable.setPrefHeight(220);
        historyTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<PasswordHistory, Integer> colId = new TableColumn<>("#");
        colId.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getId()));
        colId.setMaxWidth(60);
        colId.setMinWidth(40);

        TableColumn<PasswordHistory, String> colDate = new TableColumn<>("Generated Date / Time");
        colDate.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getGeneratedAt()));
        colDate.setMinWidth(180);

        TableColumn<PasswordHistory, Integer> colLength = new TableColumn<>("Length");
        colLength.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getLength()));
        colLength.setMinWidth(80);

        TableColumn<PasswordHistory, String> colStrength = new TableColumn<>("Strength");
        colStrength.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getStrength()));
        colStrength.setMinWidth(120);
        colStrength.setCellFactory(col -> new TableCell<PasswordHistory, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Label badge = new Label(item);
                    badge.getStyleClass().add("status-badge");
                    if (item.contains("Strong")) {
                        badge.getStyleClass().add("status-secure");
                    } else if (item.contains("Moderate") || item.contains("Weak")) {
                        badge.getStyleClass().add("status-warning");
                    } else {
                        badge.getStyleClass().add("status-danger");
                    }
                    setGraphic(badge);
                    setText(null);
                }
            }
        });

        TableColumn<PasswordHistory, Integer> colScore = new TableColumn<>("Score");
        colScore.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getScore()));
        colScore.setMinWidth(80);
        colScore.setCellFactory(col -> new TableCell<PasswordHistory, Integer>() {
            @Override
            protected void updateItem(Integer score, boolean empty) {
                super.updateItem(score, empty);
                if (empty || score == null) {
                    setText("—");
                } else {
                    setText(score + " / 100");
                }
            }
        });

        historyTable.getColumns().addAll(colId, colDate, colLength, colStrength, colScore);
        historyTable.setPlaceholder(new Label("No password generation activity recorded yet."));

        section.getChildren().addAll(headerRow, infoBanner, historyTable);
        return section;
    }

    private void loadHistoryData() {
        Thread thread = new Thread(() -> {
            try {
                List<PasswordHistory> records = historyRepository.findAll();
                int totalCount = historyRepository.count();
                Platform.runLater(() -> {
                    historyData.setAll(records);
                    if (historyCountLabel != null) {
                        historyCountLabel.setText("Total: " + totalCount);
                    }
                });
            } catch (Exception ex) {
                System.err.println("[NETTECH] Failed to load password history: " + ex.getMessage());
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    private void handleClearHistory() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Clear Password History");
        alert.setHeaderText("Delete all password generation metadata?");
        alert.setContentText("This will remove all stored generation metadata records. This action cannot be undone.");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            historyRepository.deleteAll();
            loadHistoryData();
        }
    }
}
