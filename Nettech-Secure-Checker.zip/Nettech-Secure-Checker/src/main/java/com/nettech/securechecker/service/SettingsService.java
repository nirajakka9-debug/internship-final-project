package com.nettech.securechecker.service;

import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.util.Constants;
import com.nettech.securechecker.util.FileUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Service for managing user settings and safe workstation data operations.
 * <p>
 * Persists non-sensitive preferences (theme, report directories) locally in a properties file.
 * <b>SECURITY INVARIANT:</b> Plaintext passwords, keys, and tokens are never stored in settings.
 */
public class SettingsService {

    private static final String KEY_THEME = "app.theme";
    private static final String KEY_REPORTS_DIR = "reports.directory";

    private final File settingsFile;
    private final PasswordHistoryRepository passwordRepo;
    private final IntegrityHistoryRepository historyRepo;
    private final Properties properties = new Properties();

    public SettingsService() {
        this(new File(Constants.DB_DIRECTORY, Constants.SETTINGS_FILENAME),
             new PasswordHistoryRepository(DatabaseManager.getInstance()),
             new IntegrityHistoryRepository(DatabaseManager.getInstance()));
    }

    public SettingsService(File settingsFile,
                           PasswordHistoryRepository passwordRepo,
                           IntegrityHistoryRepository historyRepo) {
        this.settingsFile = settingsFile;
        this.passwordRepo = passwordRepo;
        this.historyRepo  = historyRepo;
        load();
    }

    /**
     * Loads settings from the properties file.
     */
    public synchronized void load() {
        if (settingsFile != null && settingsFile.exists()) {
            try (InputStream in = new FileInputStream(settingsFile)) {
                properties.load(in);
            } catch (IOException e) {
                System.err.println("[NETTECH] Failed to load settings: " + e.getMessage());
            }
        }
    }

    /**
     * Saves current settings to disk.
     */
    public synchronized boolean save() {
        if (settingsFile == null) return false;
        try {
            if (settingsFile.getParentFile() != null && !settingsFile.getParentFile().exists()) {
                settingsFile.getParentFile().mkdirs();
            }
            try (OutputStream out = new FileOutputStream(settingsFile)) {
                properties.store(out, "NETTECH Secure Checker Preferences");
                return true;
            }
        } catch (IOException e) {
            System.err.println("[NETTECH] Failed to save settings: " + e.getMessage());
            return false;
        }
    }

    // ── Theme Preference ────────────────────────────────────────

    /**
     * Returns the configured theme ("DARK" or "LIGHT"). Defaults to "DARK".
     */
    public synchronized String getTheme() {
        String theme = properties.getProperty(KEY_THEME, Constants.THEME_DARK);
        if (Constants.THEME_LIGHT.equalsIgnoreCase(theme)) {
            return Constants.THEME_LIGHT;
        }
        return Constants.THEME_DARK;
    }

    /**
     * Sets and persists the theme preference.
     *
     * @param theme "DARK" or "LIGHT"
     */
    public synchronized void setTheme(String theme) {
        if (Constants.THEME_LIGHT.equalsIgnoreCase(theme)) {
            properties.setProperty(KEY_THEME, Constants.THEME_LIGHT);
        } else {
            properties.setProperty(KEY_THEME, Constants.THEME_DARK);
        }
        save();
    }

    public boolean isDarkTheme() {
        return Constants.THEME_DARK.equals(getTheme());
    }

    // ── Reports Directory Preference ────────────────────────────

    /**
     * Returns the validated report output directory.
     * Falls back to the default "reports" directory if custom path is invalid or missing.
     */
    public synchronized String getReportsDirectory() {
        String dir = properties.getProperty(KEY_REPORTS_DIR, Constants.REPORTS_DIRECTORY);
        if (dir == null || dir.isBlank()) {
            return Constants.REPORTS_DIRECTORY;
        }
        File f = new File(dir.trim());
        if (f.exists() && !f.isDirectory()) {
            return Constants.REPORTS_DIRECTORY;
        }
        return dir.trim();
    }

    /**
     * Sets and validates the report output directory.
     *
     * @param directoryPath the chosen directory path
     * @return true if directory is valid or created, false if invalid
     */
    public synchronized boolean setReportsDirectory(String directoryPath) {
        if (directoryPath == null || directoryPath.isBlank()) {
            properties.setProperty(KEY_REPORTS_DIR, Constants.REPORTS_DIRECTORY);
            save();
            return true;
        }

        try {
            Path path = Paths.get(directoryPath.trim());
            File file = path.toFile();
            if (file.exists()) {
                if (!file.isDirectory() || !file.canWrite()) {
                    return false;
                }
            } else {
                if (!file.mkdirs()) {
                    return false;
                }
            }
            properties.setProperty(KEY_REPORTS_DIR, file.getAbsolutePath());
            save();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ── Safe Data Management ────────────────────────────────────

    /**
     * Clears password metadata history.
     * <b>SECURITY INVARIANT:</b> Does NOT delete integrity references, check history, or PDF files.
     *
     * @return true if cleared
     */
    public boolean clearPasswordHistory() {
        return passwordRepo.deleteAll();
    }

    /**
     * Clears file integrity verification history.
     * <b>SECURITY INVARIANT:</b> Does NOT delete saved file baseline references, password metadata, or PDF files.
     *
     * @return true if cleared
     */
    public boolean clearIntegrityHistory() {
        return historyRepo.deleteAll();
    }

    // ── Local File Locations ────────────────────────────────────

    public String getDatabaseLocation() {
        return new File(Constants.DB_DIRECTORY, Constants.DB_FILENAME).getAbsolutePath();
    }

    public String getReportsLocation() {
        return new File(getReportsDirectory()).getAbsolutePath();
    }

    public String getSettingsLocation() {
        return settingsFile != null ? settingsFile.getAbsolutePath() : "In-memory";
    }
}
