package com.nettech.securechecker.config;

import com.nettech.securechecker.util.Constants;

/**
 * Database configuration holder.
 * <p>
 * Centralises database connection parameters so that they can be
 * overridden for testing without touching the rest of the codebase.
 */
public final class DatabaseConfig {

    private DatabaseConfig() {
        // Prevent instantiation
    }

    /**
     * Returns the JDBC URL for the application database.
     */
    public static String getJdbcUrl() {
        return Constants.DB_URL;
    }

    /**
     * Returns the classpath path to the SQL schema file.
     */
    public static String getSchemaPath() {
        return Constants.SCHEMA_PATH;
    }

    /**
     * Returns the directory where the database file is stored.
     */
    public static String getDatabaseDirectory() {
        return Constants.DB_DIRECTORY;
    }
}
