package com.nettech.securechecker.model;

/**
 * Model representing the calculated cryptographic hashes of a file.
 */
public class FileHashResult {

    private final String fileName;
    private final String filePath;
    private final long fileSize;
    private final String md5;
    private final String sha256;
    private final String calculatedAt;

    public FileHashResult(String fileName, String filePath, long fileSize,
                          String md5, String sha256, String calculatedAt) {
        this.fileName = fileName;
        this.filePath = filePath;
        this.fileSize = fileSize;
        this.md5 = md5;
        this.sha256 = sha256;
        this.calculatedAt = calculatedAt;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public long getFileSize() {
        return fileSize;
    }

    public String getMd5() {
        return md5;
    }

    public String getSha256() {
        return sha256;
    }

    public String getCalculatedAt() {
        return calculatedAt;
    }

    @Override
    public String toString() {
        return "FileHashResult{" +
                "fileName='" + fileName + '\'' +
                ", filePath='" + filePath + '\'' +
                ", fileSize=" + fileSize +
                ", md5='" + md5 + '\'' +
                ", sha256='" + sha256 + '\'' +
                ", calculatedAt='" + calculatedAt + '\'' +
                '}';
    }
}
