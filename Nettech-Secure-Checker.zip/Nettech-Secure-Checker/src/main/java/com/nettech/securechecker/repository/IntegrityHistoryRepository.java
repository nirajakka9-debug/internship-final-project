package com.nettech.securechecker.repository;

import com.nettech.securechecker.model.IntegrityCheck;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Repository for {@link IntegrityCheck} history records.
 * <p>
 * Manages integrity verification audit logs using secure parameterized SQL queries.
 */
public class IntegrityHistoryRepository {

    private final DatabaseManager databaseManager;

    public IntegrityHistoryRepository() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    public IntegrityHistoryRepository(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    /**
     * Inserts a new integrity check record.
     *
     * @param check the check record to insert
     * @return the generated ID, or -1 on failure
     */
    public int insert(IntegrityCheck check) {
        if (check == null) {
            return -1;
        }

        String sql = "INSERT INTO integrity_history (reference_id, file_name, checked_at, " +
                     "expected_md5, actual_md5, expected_sha256, actual_sha256, result) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            if (check.getReferenceId() != null) {
                stmt.setInt(1, check.getReferenceId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }
            stmt.setString(2, check.getFileName());
            stmt.setString(3, check.getCheckedAt());
            stmt.setString(4, check.getExpectedMd5());
            stmt.setString(5, check.getActualMd5());
            stmt.setString(6, check.getExpectedSha256());
            stmt.setString(7, check.getActualSha256());
            stmt.setString(8, check.getResult());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        check.setId(generatedId);
                        return generatedId;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to insert integrity check record: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Retrieves all integrity check records, ordered by most recent first.
     *
     * @return list of integrity check records
     */
    public List<IntegrityCheck> findAll() {
        List<IntegrityCheck> list = new ArrayList<>();
        String sql = "SELECT id, reference_id, file_name, checked_at, expected_md5, actual_md5, " +
                     "expected_sha256, actual_sha256, result FROM integrity_history ORDER BY id DESC";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch integrity history: " + e.getMessage());
        }
        return list;
    }

    /**
     * Retrieves integrity checks for a specific reference ID.
     *
     * @param referenceId the reference ID to filter by
     * @return list of matching check records
     */
    public List<IntegrityCheck> findByReferenceId(int referenceId) {
        List<IntegrityCheck> list = new ArrayList<>();
        String sql = "SELECT id, reference_id, file_name, checked_at, expected_md5, actual_md5, " +
                     "expected_sha256, actual_sha256, result FROM integrity_history WHERE reference_id = ? ORDER BY id DESC";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, referenceId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch integrity history by reference ID: " + e.getMessage());
        }
        return list;
    }

    /**
     * Finds an integrity check by its ID.
     *
     * @param id the check ID
     * @return an Optional containing the record, or empty
     */
    public Optional<IntegrityCheck> findById(int id) {
        String sql = "SELECT id, reference_id, file_name, checked_at, expected_md5, actual_md5, " +
                     "expected_sha256, actual_sha256, result FROM integrity_history WHERE id = ?";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch integrity check by ID: " + e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Returns the total count of integrity check records.
     *
     * @return the count
     */
    public int count() {
        String sql = "SELECT COUNT(*) FROM integrity_history";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to count integrity checks: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Retrieves the most recent integrity checks up to a specified limit.
     *
     * @param limit maximum number of records to return
     * @return list of recent check records
     */
    public List<IntegrityCheck> findRecent(int limit) {
        List<IntegrityCheck> list = new ArrayList<>();
        String sql = "SELECT id, reference_id, file_name, checked_at, expected_md5, actual_md5, " +
                     "expected_sha256, actual_sha256, result FROM integrity_history ORDER BY id DESC LIMIT ?";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Math.max(1, limit));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch recent integrity history: " + e.getMessage());
        }
        return list;
    }

    private IntegrityCheck mapRow(ResultSet rs) throws SQLException {
        IntegrityCheck check = new IntegrityCheck();
        check.setId(rs.getInt("id"));
        int refId = rs.getInt("reference_id");
        check.setReferenceId(rs.wasNull() ? null : refId);
        check.setFileName(rs.getString("file_name"));
        check.setCheckedAt(rs.getString("checked_at"));
        check.setExpectedMd5(rs.getString("expected_md5"));
        check.setActualMd5(rs.getString("actual_md5"));
        check.setExpectedSha256(rs.getString("expected_sha256"));
        check.setActualSha256(rs.getString("actual_sha256"));
        check.setResult(rs.getString("result"));
        return check;
    }

    /**
     * Clears all integrity check history records.
     *
     * @return true if successful
     */
    public boolean deleteAll() {
        String sql = "DELETE FROM integrity_history";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to clear integrity history: " + e.getMessage());
        }
        return false;
    }
}
