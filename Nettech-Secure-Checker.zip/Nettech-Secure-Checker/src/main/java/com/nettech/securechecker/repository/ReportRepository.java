package com.nettech.securechecker.repository;

import com.nettech.securechecker.model.SecurityReport;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Repository for {@link SecurityReport} persistence operations.
 * <p>
 * Records metadata for successfully exported audit reports.
 * <b>SECURITY INVARIANT:</b> Only report metadata (type, file name, timestamp, destination path)
 * is recorded. Sensitive data or credentials are never stored.
 */
public class ReportRepository {

    private final DatabaseManager databaseManager;

    public ReportRepository() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    public ReportRepository(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    /**
     * Inserts a new report record after successful PDF export.
     *
     * @param report the report entity to insert
     * @return generated ID or -1 on failure
     */
    public int insert(SecurityReport report) {
        if (report == null) {
            return -1;
        }

        String sql = "INSERT INTO reports (report_type, file_name, generated_at, output_path) VALUES (?, ?, ?, ?)";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, report.getReportType());
            stmt.setString(2, report.getFileName());
            stmt.setString(3, report.getGeneratedAt());
            stmt.setString(4, report.getOutputPath());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        report.setId(generatedId);
                        return generatedId;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to insert report metadata: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Retrieves all report records, ordered by most recent first.
     *
     * @return list of reports
     */
    public List<SecurityReport> findAll() {
        List<SecurityReport> list = new ArrayList<>();
        String sql = "SELECT id, report_type, file_name, generated_at, output_path FROM reports ORDER BY id DESC";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch reports: " + e.getMessage());
        }
        return list;
    }

    /**
     * Finds a report by its ID.
     *
     * @param id the report ID
     * @return Optional containing the report or empty
     */
    public Optional<SecurityReport> findById(int id) {
        String sql = "SELECT id, report_type, file_name, generated_at, output_path FROM reports WHERE id = ?";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch report by ID: " + e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Returns total count of generated reports.
     *
     * @return count of reports
     */
    public int count() {
        String sql = "SELECT COUNT(*) FROM reports";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to count reports: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Deletes a report record by its ID.
     *
     * @param id the report ID
     * @return true if deleted
     */
    public boolean deleteById(int id) {
        String sql = "DELETE FROM reports WHERE id = ?";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to delete report: " + e.getMessage());
        }
        return false;
    }

    /**
     * Clears all report records from the database.
     *
     * @return true if cleared
     */
    public boolean deleteAll() {
        String sql = "DELETE FROM reports";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to clear reports: " + e.getMessage());
        }
        return false;
    }

    private SecurityReport mapRow(ResultSet rs) throws SQLException {
        SecurityReport report = new SecurityReport();
        report.setId(rs.getInt("id"));
        report.setReportType(rs.getString("report_type"));
        report.setFileName(rs.getString("file_name"));
        report.setGeneratedAt(rs.getString("generated_at"));
        report.setOutputPath(rs.getString("output_path"));
        return report;
    }
}
