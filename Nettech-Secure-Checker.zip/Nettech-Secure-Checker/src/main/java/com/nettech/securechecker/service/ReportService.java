package com.nettech.securechecker.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import com.nettech.securechecker.model.*;
import com.nettech.securechecker.repository.*;
import com.nettech.securechecker.util.Constants;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Service layer for aggregating security audit metrics and exporting PDF reports.
 * <p>
 * Supports three report profiles:
 * <ol>
 *   <li><b>Password Security Report</b>: Credential metadata statistics, strength distribution, and hardening policies.</li>
 *   <li><b>File Integrity Report</b>: Cataloged file baselines, verification audit trail, and tampering alerts.</li>
 *   <li><b>Combined Security Report</b>: Full executive summary uniting password metadata and file integrity baselines.</li>
 * </ol>
 * <p>
 * <b>SECURITY INVARIANT:</b> All reports are generated strictly offline from local SQLite data.
 * Plaintext passwords, secrets, and raw file contents are NEVER stored, processed, or printed into reports.
 */
public class ReportService {

    public static final String TYPE_PASSWORD_REPORT  = "PASSWORD_SECURITY";
    public static final String TYPE_INTEGRITY_REPORT = "FILE_INTEGRITY";
    public static final String TYPE_COMBINED_REPORT  = "COMBINED_SECURITY";

    private final PasswordHistoryRepository passwordRepo;
    private final IntegrityReferenceRepository referenceRepo;
    private final IntegrityHistoryRepository historyRepo;
    private final ReportRepository reportRepo;

    // Palette for PDF styling
    private static final Color COLOR_PRIMARY    = new Color(15, 23, 42);    // Slate 900
    private static final Color COLOR_HEADER_BG  = new Color(30, 41, 59);    // Slate 800
    private static final Color COLOR_ACCENT     = new Color(14, 116, 144);  // Cyan 700
    private static final Color COLOR_ACCENT_TXT = new Color(2, 132, 199);   // Sky 600
    private static final Color COLOR_TEXT_MAIN  = new Color(30, 41, 59);    // Slate 800
    private static final Color COLOR_TEXT_MUTED = new Color(100, 116, 139); // Slate 500
    private static final Color COLOR_ROW_ALT    = new Color(248, 250, 252); // Slate 50
    private static final Color COLOR_BORDER     = new Color(226, 232, 240); // Slate 200
    private static final Color COLOR_SECURE     = new Color(22, 101, 52);   // Green 800
    private static final Color COLOR_DANGER     = new Color(153, 27, 27);   // Red 800
    private static final Color COLOR_WARNING    = new Color(161, 98, 7);    // Yellow 700
    private static final Color COLOR_BOX_BG     = new Color(241, 245, 249); // Slate 100

    public ReportService() {
        DatabaseManager dbManager = DatabaseManager.getInstance();
        this.passwordRepo  = new PasswordHistoryRepository(dbManager);
        this.referenceRepo = new IntegrityReferenceRepository(dbManager);
        this.historyRepo   = new IntegrityHistoryRepository(dbManager);
        this.reportRepo    = new ReportRepository(dbManager);
    }

    public ReportService(PasswordHistoryRepository passwordRepo,
                         IntegrityReferenceRepository referenceRepo,
                         IntegrityHistoryRepository historyRepo,
                         ReportRepository reportRepo) {
        this.passwordRepo  = passwordRepo;
        this.referenceRepo = referenceRepo;
        this.historyRepo   = historyRepo;
        this.reportRepo    = reportRepo;
    }

    // =========================================================================
    // 1. PUBLIC EXPORT API
    // =========================================================================

    /**
     * Exports a Password Security Report to the specified destination PDF file.
     *
     * @param destination target file on disk
     * @return persisted {@link SecurityReport} metadata record
     * @throws DocumentException if PDF layout fails
     * @throws IOException if disk write fails
     */
    public SecurityReport exportPasswordReport(File destination) throws DocumentException, IOException {
        String timestamp = currentTimestamp();
        ensureParentDirectory(destination);

        Document document = new Document(PageSize.A4, 36, 36, 54, 45);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(destination));
        writer.setPageEvent(new PdfHeaderFooter("Password Security Audit Report", timestamp));

        document.open();
        buildDocumentHeader(document, "Password Security Audit Report",
                "Workstation Credential Hygiene, Entropy Metrics & Generation Log", timestamp);

        addPasswordMetricsSection(document);
        addPasswordHistoryTable(document);
        addPasswordRecommendationsSection(document);

        document.close();

        // Record in database only upon successful write
        SecurityReport record = new SecurityReport(
                TYPE_PASSWORD_REPORT,
                destination.getName(),
                timestamp,
                destination.getAbsolutePath()
        );
        reportRepo.insert(record);
        return record;
    }

    /**
     * Exports a File Integrity Report to the specified destination PDF file.
     *
     * @param destination target file on disk
     * @return persisted {@link SecurityReport} metadata record
     * @throws DocumentException if PDF layout fails
     * @throws IOException if disk write fails
     */
    public SecurityReport exportIntegrityReport(File destination) throws DocumentException, IOException {
        String timestamp = currentTimestamp();
        ensureParentDirectory(destination);

        Document document = new Document(PageSize.A4, 36, 36, 54, 45);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(destination));
        writer.setPageEvent(new PdfHeaderFooter("File Integrity Verification Report", timestamp));

        document.open();
        buildDocumentHeader(document, "File Integrity Verification Report",
                "Cryptographic Baselines, Tamper Audit Logs & Checksum Analysis", timestamp);

        addIntegrityMetricsSection(document);
        addIntegrityReferencesTable(document);
        addIntegrityHistoryTable(document);
        addIntegrityGuidanceSection(document);

        document.close();

        SecurityReport record = new SecurityReport(
                TYPE_INTEGRITY_REPORT,
                destination.getName(),
                timestamp,
                destination.getAbsolutePath()
        );
        reportRepo.insert(record);
        return record;
    }

    /**
     * Exports a Full Combined Security Report to the specified destination PDF file.
     *
     * @param destination target file on disk
     * @return persisted {@link SecurityReport} metadata record
     * @throws DocumentException if PDF layout fails
     * @throws IOException if disk write fails
     */
    public SecurityReport exportCombinedReport(File destination) throws DocumentException, IOException {
        String timestamp = currentTimestamp();
        ensureParentDirectory(destination);

        Document document = new Document(PageSize.A4, 36, 36, 54, 45);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(destination));
        writer.setPageEvent(new PdfHeaderFooter("Comprehensive Cybersecurity Audit Report", timestamp));

        document.open();
        buildDocumentHeader(document, "Comprehensive Cybersecurity Audit Report",
                "Full Executive Overview: Credential Metadata & File Integrity Posture", timestamp);

        addExecutiveSummarySection(document);
        addPasswordMetricsSection(document);
        addPasswordHistoryTable(document);
        document.newPage();
        addIntegrityMetricsSection(document);
        addIntegrityReferencesTable(document);
        addIntegrityHistoryTable(document);
        addSecurityHardeningPolicySection(document);

        document.close();

        SecurityReport record = new SecurityReport(
                TYPE_COMBINED_REPORT,
                destination.getName(),
                timestamp,
                destination.getAbsolutePath()
        );
        reportRepo.insert(record);
        return record;
    }

    /**
     * Retrieves all previously recorded reports.
     */
    public List<SecurityReport> getAllReports() {
        return reportRepo.findAll();
    }

    /**
     * Returns total report count.
     */
    public int getReportCount() {
        return reportRepo.count();
    }

    /**
     * Deletes a report record by ID.
     */
    public boolean deleteReport(int id) {
        return reportRepo.deleteById(id);
    }

    // =========================================================================
    // 2. DATA AGGREGATION HELPERS (FOR UI & PDF)
    // =========================================================================

    public PasswordReportSummary getPasswordSummary() {
        List<PasswordHistory> history = passwordRepo.findAll();
        int total = history.size();
        int veryWeak = 0, weak = 0, moderate = 0, strong = 0, veryStrong = 0;
        int totalScore = 0, totalLength = 0;
        int scoredCount = 0;

        for (PasswordHistory ph : history) {
            totalLength += ph.getLength();
            if (ph.getScore() != null) {
                totalScore += ph.getScore();
                scoredCount++;
            }
            String s = ph.getStrength() != null ? ph.getStrength() : "";
            if (s.equalsIgnoreCase(Constants.STRENGTH_VERY_WEAK)) veryWeak++;
            else if (s.equalsIgnoreCase(Constants.STRENGTH_WEAK)) weak++;
            else if (s.equalsIgnoreCase(Constants.STRENGTH_MODERATE)) moderate++;
            else if (s.equalsIgnoreCase(Constants.STRENGTH_STRONG)) strong++;
            else if (s.equalsIgnoreCase(Constants.STRENGTH_VERY_STRONG)) veryStrong++;
        }

        double avgScore = scoredCount > 0 ? (double) totalScore / scoredCount : 0.0;
        double avgLength = total > 0 ? (double) totalLength / total : 0.0;

        return new PasswordReportSummary(total, veryWeak, weak, moderate, strong, veryStrong, avgScore, avgLength);
    }

    public IntegrityReportSummary getIntegritySummary() {
        int totalRefs = referenceRepo.count();
        List<IntegrityCheck> history = historyRepo.findAll();
        int totalChecks = history.size();
        int verified = 0, modified = 0, unable = 0;

        for (IntegrityCheck ic : history) {
            String res = ic.getResult() != null ? ic.getResult() : "";
            if (res.equalsIgnoreCase(Constants.INTEGRITY_VERIFIED)) verified++;
            else if (res.equalsIgnoreCase(Constants.INTEGRITY_MODIFIED)) modified++;
            else unable++;
        }

        return new IntegrityReportSummary(totalRefs, totalChecks, verified, modified, unable);
    }

    // =========================================================================
    // 3. PDF SECTION BUILDERS
    // =========================================================================

    private void buildDocumentHeader(Document doc, String title, String subtitle, String timestamp)
            throws DocumentException {
        // App Title Banner Table
        PdfPTable headerTable = new PdfPTable(1);
        headerTable.setWidthPercentage(100);
        headerTable.setSpacingAfter(14);

        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(COLOR_PRIMARY);
        cell.setPadding(12);
        cell.setBorder(Rectangle.NO_BORDER);

        Font brandFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, new Color(147, 197, 253));
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, Color.WHITE);
        Font subFont = FontFactory.getFont(FontFactory.HELVETICA, 10, new Color(203, 213, 225));
        Font metaFont = FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 8.5f, new Color(148, 163, 184));

        Paragraph pBrand = new Paragraph("NETTECH SECURE PASSWORD & FILE INTEGRITY CHECKER", brandFont);
        Paragraph pTitle = new Paragraph(title, titleFont);
        pTitle.setSpacingBefore(2);
        Paragraph pSub = new Paragraph(subtitle, subFont);
        pSub.setSpacingBefore(3);
        Paragraph pMeta = new Paragraph("Generated: " + timestamp + "  •  Workstation: Local/Offline Audit  •  Classification: Internal Confidential", metaFont);
        pMeta.setSpacingBefore(5);

        cell.addElement(pBrand);
        cell.addElement(pTitle);
        cell.addElement(pSub);
        cell.addElement(pMeta);
        headerTable.addCell(cell);

        doc.add(headerTable);
    }

    private void addExecutiveSummarySection(Document doc) throws DocumentException {
        doc.add(createSectionHeading("1. Executive Posture Overview"));

        PasswordReportSummary pwdSum = getPasswordSummary();
        IntegrityReportSummary intSum = getIntegritySummary();

        PdfPTable grid = new PdfPTable(4);
        grid.setWidthPercentage(100);
        grid.setSpacingAfter(14);
        grid.setWidths(new float[]{25, 25, 25, 25});

        addMetricCard(grid, "Passwords Cataloged", String.valueOf(pwdSum.total), "Avg Score: " + formatDecimal(pwdSum.avgScore) + "/100");
        addMetricCard(grid, "Strong / Very Strong", String.valueOf(pwdSum.strong + pwdSum.veryStrong), "High entropy credentials");
        addMetricCard(grid, "Baseline References", String.valueOf(intSum.totalReferences), "Monitored file baselines");
        addMetricCard(grid, "Integrity Checks", String.valueOf(intSum.totalChecks), intSum.verified + " Verified / " + intSum.modified + " Modified");

        doc.add(grid);
    }

    private void addPasswordMetricsSection(Document doc) throws DocumentException {
        doc.add(createSectionHeading("Password Security Posture & Metrics"));

        PasswordReportSummary sum = getPasswordSummary();

        PdfPTable summaryTable = new PdfPTable(3);
        summaryTable.setWidthPercentage(100);
        summaryTable.setSpacingAfter(10);
        summaryTable.setWidths(new float[]{33, 33, 34});

        addMetricCard(summaryTable, "Total Recorded Generations", String.valueOf(sum.total), "Zero-knowledge metadata");
        addMetricCard(summaryTable, "Average Entropy Score", formatDecimal(sum.avgScore) + " / 100", getScoreCategoryLabel(sum.avgScore));
        addMetricCard(summaryTable, "Average Character Length", formatDecimal(sum.avgLength) + " chars", "Recommended >= 16");

        doc.add(summaryTable);

        // Strength Distribution Table
        PdfPTable distTable = new PdfPTable(5);
        distTable.setWidthPercentage(100);
        distTable.setSpacingAfter(12);
        distTable.setWidths(new float[]{20, 20, 20, 20, 20});

        distTable.addCell(createTableHeaderCell("Very Weak (<25)"));
        distTable.addCell(createTableHeaderCell("Weak (25-44)"));
        distTable.addCell(createTableHeaderCell("Moderate (45-64)"));
        distTable.addCell(createTableHeaderCell("Strong (65-84)"));
        distTable.addCell(createTableHeaderCell("Very Strong (85-100)"));

        distTable.addCell(createTableCell(sum.veryWeak + " (" + calcPercent(sum.veryWeak, sum.total) + ")", sum.veryWeak > 0 ? COLOR_DANGER : COLOR_TEXT_MAIN));
        distTable.addCell(createTableCell(sum.weak + " (" + calcPercent(sum.weak, sum.total) + ")", sum.weak > 0 ? COLOR_WARNING : COLOR_TEXT_MAIN));
        distTable.addCell(createTableCell(sum.moderate + " (" + calcPercent(sum.moderate, sum.total) + ")", COLOR_TEXT_MAIN));
        distTable.addCell(createTableCell(sum.strong + " (" + calcPercent(sum.strong, sum.total) + ")", COLOR_SECURE));
        distTable.addCell(createTableCell(sum.veryStrong + " (" + calcPercent(sum.veryStrong, sum.total) + ")", COLOR_SECURE));

        doc.add(distTable);
    }

    private void addPasswordHistoryTable(Document doc) throws DocumentException {
        Paragraph heading = new Paragraph("Recent Password Generation Metadata (Zero-Knowledge Audit Log)",
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10.5f, COLOR_PRIMARY));
        heading.setSpacingAfter(6);
        doc.add(heading);

        List<PasswordHistory> list = passwordRepo.findAll();
        if (list.isEmpty()) {
            doc.add(createEmptyStateParagraph("No password generation activity recorded in database."));
            return;
        }

        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingAfter(14);
        table.setWidths(new float[]{10, 35, 15, 22, 18});

        table.addCell(createTableHeaderCell("#"));
        table.addCell(createTableHeaderCell("Generation Timestamp"));
        table.addCell(createTableHeaderCell("Length"));
        table.addCell(createTableHeaderCell("Strength"));
        table.addCell(createTableHeaderCell("Score"));

        int max = Math.min(list.size(), 15);
        for (int i = 0; i < max; i++) {
            PasswordHistory ph = list.get(i);
            Color rowBg = (i % 2 == 0) ? Color.WHITE : COLOR_ROW_ALT;
            table.addCell(createStyledCell(String.valueOf(ph.getId()), rowBg, Element.ALIGN_CENTER));
            table.addCell(createStyledCell(ph.getGeneratedAt(), rowBg, Element.ALIGN_LEFT));
            table.addCell(createStyledCell(ph.getLength() + " chars", rowBg, Element.ALIGN_CENTER));
            table.addCell(createStyledCell(ph.getStrength(), rowBg, Element.ALIGN_CENTER));
            table.addCell(createStyledCell(ph.getScore() != null ? ph.getScore() + "/100" : "—", rowBg, Element.ALIGN_CENTER));
        }

        doc.add(table);
        if (list.size() > 15) {
            Paragraph more = new Paragraph("Showing 15 most recent records of " + list.size() + " total records.",
                    FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 8, COLOR_TEXT_MUTED));
            more.setSpacingAfter(10);
            doc.add(more);
        }
    }

    private void addPasswordRecommendationsSection(Document doc) throws DocumentException {
        doc.add(createSectionHeading("Credential Hardening Guidelines"));

        PdfPTable box = new PdfPTable(1);
        box.setWidthPercentage(100);
        box.setSpacingAfter(10);

        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(COLOR_BOX_BG);
        cell.setBorderColor(COLOR_BORDER);
        cell.setPadding(10);

        Font bulletFont = FontFactory.getFont(FontFactory.HELVETICA, 8.5f, COLOR_TEXT_MAIN);

        Paragraph p = new Paragraph();
        p.setFont(bulletFont);
        p.add(new Chunk("• Enforce Minimum Length: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_PRIMARY)));
        p.add("Ensure passwords contain at least 16 characters to resist modern offline GPU brute-force attacks.\n");
        p.add(new Chunk("• Utilize Full Character Entropy: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_PRIMARY)));
        p.add("Combine uppercase letters, lowercase letters, numbers, and special symbols.\n");
        p.add(new Chunk("• Eliminate Repetition & Sequences: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_PRIMARY)));
        p.add("Avoid consecutive repeats (e.g. 'aaaa') and keyboard traversal patterns ('qwerty', '12345').\n");
        p.add(new Chunk("• Zero Credential Exposure: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_PRIMARY)));
        p.add("Plaintext passwords are never recorded in this system, ensuring zero risk of credential exposure through logs or reports.");

        cell.addElement(p);
        box.addCell(cell);
        doc.add(box);
    }

    private void addIntegrityMetricsSection(Document doc) throws DocumentException {
        doc.add(createSectionHeading("File Integrity Verification Posture"));

        IntegrityReportSummary sum = getIntegritySummary();

        PdfPTable summaryTable = new PdfPTable(4);
        summaryTable.setWidthPercentage(100);
        summaryTable.setSpacingAfter(10);
        summaryTable.setWidths(new float[]{25, 25, 25, 25});

        addMetricCard(summaryTable, "Cataloged Baselines", String.valueOf(sum.totalReferences), "Stored reference hashes");
        addMetricCard(summaryTable, "Verified (Clean)", String.valueOf(sum.verified), calcPercent(sum.verified, sum.totalChecks) + " of checks");
        addMetricCard(summaryTable, "Modified (Tampered)", String.valueOf(sum.modified), sum.modified > 0 ? "TAMPER ALERT" : "No deviations");
        addMetricCard(summaryTable, "Unable to Verify", String.valueOf(sum.unableToVerify), "Missing or inaccessible");

        doc.add(summaryTable);
    }

    private void addIntegrityReferencesTable(Document doc) throws DocumentException {
        Paragraph heading = new Paragraph("Registered File Baseline References (SHA-256 Authority)",
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10.5f, COLOR_PRIMARY));
        heading.setSpacingAfter(6);
        doc.add(heading);

        List<IntegrityReference> list = referenceRepo.findAll();
        if (list.isEmpty()) {
            doc.add(createEmptyStateParagraph("No file baseline references registered in database."));
            return;
        }

        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setSpacingAfter(14);
        table.setWidths(new float[]{8, 28, 14, 50});

        table.addCell(createTableHeaderCell("#"));
        table.addCell(createTableHeaderCell("File Name"));
        table.addCell(createTableHeaderCell("Size"));
        table.addCell(createTableHeaderCell("Expected SHA-256 Digest"));

        int max = Math.min(list.size(), 12);
        for (int i = 0; i < max; i++) {
            IntegrityReference ref = list.get(i);
            Color rowBg = (i % 2 == 0) ? Color.WHITE : COLOR_ROW_ALT;
            table.addCell(createStyledCell(String.valueOf(ref.getId()), rowBg, Element.ALIGN_CENTER));
            table.addCell(createStyledCell(ref.getFileName(), rowBg, Element.ALIGN_LEFT));
            table.addCell(createStyledCell(formatFileSize(ref.getFileSize()), rowBg, Element.ALIGN_CENTER));

            PdfPCell hashCell = new PdfPCell(new Phrase(ref.getSha256(),
                    FontFactory.getFont(FontFactory.COURIER, 7f, COLOR_TEXT_MAIN)));
            hashCell.setBackgroundColor(rowBg);
            hashCell.setPadding(4);
            hashCell.setBorderColor(COLOR_BORDER);
            table.addCell(hashCell);
        }

        doc.add(table);
        if (list.size() > 12) {
            Paragraph more = new Paragraph("Showing 12 most recent baselines of " + list.size() + " total baselines.",
                    FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 8, COLOR_TEXT_MUTED));
            more.setSpacingAfter(10);
            doc.add(more);
        }
    }

    private void addIntegrityHistoryTable(Document doc) throws DocumentException {
        Paragraph heading = new Paragraph("Recent File Integrity Verification Audit Trail",
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10.5f, COLOR_PRIMARY));
        heading.setSpacingAfter(6);
        doc.add(heading);

        List<IntegrityCheck> list = historyRepo.findAll();
        if (list.isEmpty()) {
            doc.add(createEmptyStateParagraph("No verification checks performed yet."));
            return;
        }

        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingAfter(14);
        table.setWidths(new float[]{8, 26, 26, 18, 22});

        table.addCell(createTableHeaderCell("#"));
        table.addCell(createTableHeaderCell("File Name"));
        table.addCell(createTableHeaderCell("Checked At"));
        table.addCell(createTableHeaderCell("Result Status"));
        table.addCell(createTableHeaderCell("Verification Standard"));

        int max = Math.min(list.size(), 12);
        for (int i = 0; i < max; i++) {
            IntegrityCheck ic = list.get(i);
            Color rowBg = (i % 2 == 0) ? Color.WHITE : COLOR_ROW_ALT;
            table.addCell(createStyledCell(String.valueOf(ic.getId()), rowBg, Element.ALIGN_CENTER));
            table.addCell(createStyledCell(ic.getFileName(), rowBg, Element.ALIGN_LEFT));
            table.addCell(createStyledCell(ic.getCheckedAt(), rowBg, Element.ALIGN_LEFT));

            Color statusColor = COLOR_TEXT_MAIN;
            if (Constants.INTEGRITY_VERIFIED.equalsIgnoreCase(ic.getResult())) statusColor = COLOR_SECURE;
            else if (Constants.INTEGRITY_MODIFIED.equalsIgnoreCase(ic.getResult())) statusColor = COLOR_DANGER;
            else statusColor = COLOR_WARNING;

            PdfPCell statusCell = new PdfPCell(new Phrase(ic.getResult(),
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8f, statusColor)));
            statusCell.setBackgroundColor(rowBg);
            statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            statusCell.setPadding(4);
            statusCell.setBorderColor(COLOR_BORDER);
            table.addCell(statusCell);

            table.addCell(createStyledCell("SHA-256 Checksum", rowBg, Element.ALIGN_CENTER));
        }

        doc.add(table);
    }

    private void addIntegrityGuidanceSection(Document doc) throws DocumentException {
        doc.add(createSectionHeading("Integrity Status Definitions & Security Scope"));

        PdfPTable box = new PdfPTable(1);
        box.setWidthPercentage(100);
        box.setSpacingAfter(10);

        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(COLOR_BOX_BG);
        cell.setBorderColor(COLOR_BORDER);
        cell.setPadding(10);

        Font textFont = FontFactory.getFont(FontFactory.HELVETICA, 8.5f, COLOR_TEXT_MAIN);

        Paragraph p = new Paragraph();
        p.setFont(textFont);
        p.add(new Chunk("• VERIFIED: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_SECURE)));
        p.add("The target file's calculated SHA-256 digest is byte-for-byte identical to the registered baseline reference.\n");
        p.add(new Chunk("• MODIFIED: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_DANGER)));
        p.add("The target file's SHA-256 digest differs from the baseline. This signifies tampering, corruption, or unauthorized modification.\n");
        p.add(new Chunk("• UNABLE TO VERIFY: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_WARNING)));
        p.add("The target file could not be read due to file absence, permission denial, or I/O failure.\n");
        p.add(new Chunk("• IMPORTANT SCOPE LIMITATION: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, COLOR_PRIMARY)));
        p.add("A matching cryptographic hash verifies content identity against a saved baseline. It does not certify that an unknown file is malware-free or benign.");

        cell.addElement(p);
        box.addCell(cell);
        doc.add(box);
    }

    private void addSecurityHardeningPolicySection(Document doc) throws DocumentException {
        doc.add(createSectionHeading("Enterprise Workstation Hardening Recommendations"));

        PdfPTable box = new PdfPTable(1);
        box.setWidthPercentage(100);
        box.setSpacingAfter(10);

        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(COLOR_BOX_BG);
        cell.setBorderColor(COLOR_BORDER);
        cell.setPadding(10);

        Font f = FontFactory.getFont(FontFactory.HELVETICA, 8.5f, COLOR_TEXT_MAIN);
        Paragraph p = new Paragraph();
        p.setFont(f);
        p.add("1. Periodically re-verify critical application binaries and configurations against known baseline digests.\n");
        p.add("2. Use distinct, high-entropy (>= 16 chars) credentials generated via CSPRNG for all privileged services.\n");
        p.add("3. Store baseline hash catalogs in secure, write-protected local storage.\n");
        p.add("4. Investigate any file flagged with 'MODIFIED' status before running or deploying it.");

        cell.addElement(p);
        box.addCell(cell);
        doc.add(box);
    }

    // =========================================================================
    // 4. LOW-LEVEL PDF STYLING & CELL UTILITIES
    // =========================================================================

    private Paragraph createSectionHeading(String title) {
        Paragraph heading = new Paragraph(title, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, COLOR_PRIMARY));
        heading.setSpacingBefore(8);
        heading.setSpacingAfter(6);
        return heading;
    }

    private Paragraph createEmptyStateParagraph(String message) {
        Paragraph p = new Paragraph("— " + message,
                FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 9, COLOR_TEXT_MUTED));
        p.setSpacingAfter(10);
        return p;
    }

    private void addMetricCard(PdfPTable table, String label, String value, String subtext) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(COLOR_BOX_BG);
        cell.setBorderColor(COLOR_BORDER);
        cell.setPadding(8);

        Paragraph pLabel = new Paragraph(label.toUpperCase(),
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 7.5f, COLOR_TEXT_MUTED));
        Paragraph pVal = new Paragraph(value,
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, COLOR_ACCENT_TXT));
        pVal.setSpacingBefore(2);
        Paragraph pSub = new Paragraph(subtext,
                FontFactory.getFont(FontFactory.HELVETICA, 7.5f, COLOR_TEXT_MUTED));
        pSub.setSpacingBefore(2);

        cell.addElement(pLabel);
        cell.addElement(pVal);
        cell.addElement(pSub);
        table.addCell(cell);
    }

    private PdfPCell createTableHeaderCell(String title) {
        PdfPCell cell = new PdfPCell(new Phrase(title,
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, Color.WHITE)));
        cell.setBackgroundColor(COLOR_HEADER_BG);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(6);
        cell.setBorderColor(COLOR_BORDER);
        return cell;
    }

    private PdfPCell createStyledCell(String text, Color bgColor, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text != null ? text : "—",
                FontFactory.getFont(FontFactory.HELVETICA, 8f, COLOR_TEXT_MAIN)));
        cell.setBackgroundColor(bgColor);
        cell.setHorizontalAlignment(alignment);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5);
        cell.setBorderColor(COLOR_BORDER);
        return cell;
    }

    private PdfPCell createTableCell(String text, Color textColor) {
        PdfPCell cell = new PdfPCell(new Phrase(text,
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, textColor)));
        cell.setBackgroundColor(Color.WHITE);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(6);
        cell.setBorderColor(COLOR_BORDER);
        return cell;
    }

    private String calcPercent(int count, int total) {
        if (total <= 0) return "0%";
        double pct = ((double) count / total) * 100.0;
        return new DecimalFormat("#0.#").format(pct) + "%";
    }

    private String formatDecimal(double val) {
        return new DecimalFormat("#0.#").format(val);
    }

    private String getScoreCategoryLabel(double score) {
        if (score >= 85) return "Very Strong Average";
        if (score >= 65) return "Strong Average";
        if (score >= 45) return "Moderate Average";
        if (score >= 25) return "Weak Average";
        return "Very Weak Average";
    }

    private String formatFileSize(long bytes) {
        if (bytes <= 0) return "0 B";
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(bytes) / Math.log10(1024));
        digitGroups = Math.min(digitGroups, units.length - 1);
        return new DecimalFormat("#,##0.#").format(bytes / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    private String currentTimestamp() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    private void ensureParentDirectory(File file) {
        if (file.getParentFile() != null && !file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
    }

    // =========================================================================
    // 5. PDF PAGE EVENT HELPER (HEADER & FOOTER)
    // =========================================================================

    private static class PdfHeaderFooter extends PdfPageEventHelper {
        private final String reportTitle;
        private final String generationTime;

        public PdfHeaderFooter(String reportTitle, String generationTime) {
            this.reportTitle = reportTitle;
            this.generationTime = generationTime;
        }

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            // Running top header (page 2+)
            if (writer.getPageNumber() > 1) {
                PdfPTable header = new PdfPTable(2);
                try {
                    header.setWidths(new float[]{60, 40});
                    header.setTotalWidth(document.right() - document.left());
                    PdfPCell h1 = new PdfPCell(new Phrase("NETTECH — " + reportTitle,
                            FontFactory.getFont(FontFactory.HELVETICA_BOLD, 7.5f, COLOR_TEXT_MUTED)));
                    h1.setBorder(Rectangle.BOTTOM);
                    h1.setBorderColor(COLOR_BORDER);
                    h1.setPaddingBottom(4);
                    PdfPCell h2 = new PdfPCell(new Phrase(generationTime,
                            FontFactory.getFont(FontFactory.HELVETICA, 7.5f, COLOR_TEXT_MUTED)));
                    h2.setHorizontalAlignment(Element.ALIGN_RIGHT);
                    h2.setBorder(Rectangle.BOTTOM);
                    h2.setBorderColor(COLOR_BORDER);
                    h2.setPaddingBottom(4);
                    header.addCell(h1);
                    header.addCell(h2);
                    header.writeSelectedRows(0, -1, document.left(), document.top() + 15, writer.getDirectContent());
                } catch (Exception ignored) {}
            }

            // Running footer on all pages
            PdfPTable footer = new PdfPTable(2);
            try {
                footer.setWidths(new float[]{70, 30});
                footer.setTotalWidth(document.right() - document.left());
                PdfPCell f1 = new PdfPCell(new Phrase("NETTECH Cybersecurity Desktop Toolkit  •  Confidential Local Audit",
                        FontFactory.getFont(FontFactory.HELVETICA, 7.5f, COLOR_TEXT_MUTED)));
                f1.setBorder(Rectangle.TOP);
                f1.setBorderColor(COLOR_BORDER);
                f1.setPaddingTop(4);

                PdfPCell f2 = new PdfPCell(new Phrase("Page " + writer.getPageNumber(),
                        FontFactory.getFont(FontFactory.HELVETICA_BOLD, 7.5f, COLOR_TEXT_MUTED)));
                f2.setHorizontalAlignment(Element.ALIGN_RIGHT);
                f2.setBorder(Rectangle.TOP);
                f2.setBorderColor(COLOR_BORDER);
                f2.setPaddingTop(4);

                footer.addCell(f1);
                footer.addCell(f2);
                footer.writeSelectedRows(0, -1, document.left(), document.bottom() - 10, writer.getDirectContent());
            } catch (Exception ignored) {}
        }
    }

    // =========================================================================
    // 6. SUMMARY VALUE OBJECTS
    // =========================================================================

    public static class PasswordReportSummary {
        public final int total;
        public final int veryWeak;
        public final int weak;
        public final int moderate;
        public final int strong;
        public final int veryStrong;
        public final double avgScore;
        public final double avgLength;

        public PasswordReportSummary(int total, int veryWeak, int weak, int moderate,
                                     int strong, int veryStrong, double avgScore, double avgLength) {
            this.total = total;
            this.veryWeak = veryWeak;
            this.weak = weak;
            this.moderate = moderate;
            this.strong = strong;
            this.veryStrong = veryStrong;
            this.avgScore = avgScore;
            this.avgLength = avgLength;
        }
    }

    public static class IntegrityReportSummary {
        public final int totalReferences;
        public final int totalChecks;
        public final int verified;
        public final int modified;
        public final int unableToVerify;

        public IntegrityReportSummary(int totalReferences, int totalChecks, int verified,
                                      int modified, int unableToVerify) {
            this.totalReferences = totalReferences;
            this.totalChecks = totalChecks;
            this.verified = verified;
            this.modified = modified;
            this.unableToVerify = unableToVerify;
        }
    }
}
