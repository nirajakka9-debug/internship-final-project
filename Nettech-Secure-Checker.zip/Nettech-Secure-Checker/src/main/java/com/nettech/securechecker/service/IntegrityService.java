package com.nettech.securechecker.service;

import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityCheckResult;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.util.Constants;
import com.nettech.securechecker.util.SecurityUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

/**
 * Service managing file integrity operations — baseline registration,
 * cryptographic verification, and audit trail history tracking.
 * <p>
 * <b>INTEGRITY RULES:</b>
 * <ul>
 *   <li>Primary verification decision is strictly governed by <b>SHA-256</b> comparison.</li>
 *   <li>Matching MD5 can NEVER override a SHA-256 mismatch.</li>
 *   <li>Missing baseline or inaccessible files yield {@link Constants#INTEGRITY_UNABLE_TO_VERIFY}.</li>
 * </ul>
 */
public class IntegrityService {

    private final HashService hashService;
    private final IntegrityReferenceRepository referenceRepository;
    private final IntegrityHistoryRepository historyRepository;

    public IntegrityService() {
        this(new HashService(), new IntegrityReferenceRepository(), new IntegrityHistoryRepository());
    }

    public IntegrityService(HashService hashService,
                            IntegrityReferenceRepository referenceRepository,
                            IntegrityHistoryRepository historyRepository) {
        this.hashService = hashService;
        this.referenceRepository = referenceRepository;
        this.historyRepository = historyRepository;
    }

    /**
     * Registers a file by calculating its cryptographic baseline hashes and persisting it as a reference.
     * If a reference already exists for the canonical file path, its hashes and timestamps are updated.
     *
     * @param file the file to register
     * @return the saved {@link IntegrityReference}
     * @throws IOException if the file is invalid, missing, or unreadable
     */
    public IntegrityReference registerFile(File file) throws IOException {
        if (file == null) {
            throw new IllegalArgumentException("Cannot register a null file.");
        }

        String[] hashes = hashService.computeAllHashes(file);
        String timestamp = SecurityUtils.currentTimestamp();
        String absolutePath = file.getAbsolutePath();

        Optional<IntegrityReference> existing = referenceRepository.findByFilePath(absolutePath);
        if (existing.isPresent()) {
            IntegrityReference ref = existing.get();
            ref.setFileName(file.getName());
            ref.setFileSize(file.length());
            ref.setMd5(hashes[0]);
            ref.setSha256(hashes[1]);
            ref.setUpdatedAt(timestamp);
            referenceRepository.update(ref);
            return ref;
        } else {
            IntegrityReference newRef = new IntegrityReference(
                    file.getName(),
                    absolutePath,
                    file.length(),
                    hashes[0],
                    hashes[1],
                    timestamp,
                    timestamp
            );
            int id = referenceRepository.insert(newRef);
            newRef.setId(id);
            return newRef;
        }
    }

    /**
     * Verifies the integrity of a file by looking up its stored baseline reference.
     *
     * @param file the file to verify
     * @return an {@link IntegrityCheckResult} detailing the verification status
     */
    public IntegrityCheckResult verifyFile(File file) {
        if (file == null) {
            return new IntegrityCheckResult(
                    null,
                    "Unknown",
                    null, null, null, null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY,
                    SecurityUtils.currentTimestamp(),
                    "Unable to verify: File parameter is null."
            );
        }

        Optional<IntegrityReference> refOpt = referenceRepository.findByFilePath(file.getAbsolutePath());
        if (refOpt.isEmpty()) {
            return new IntegrityCheckResult(
                    null,
                    file.getName(),
                    null, null, null, null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY,
                    SecurityUtils.currentTimestamp(),
                    "No baseline integrity reference found for this file path. Please register the file first."
            );
        }

        return verifyReference(refOpt.get(), file);
    }

    /**
     * Verifies a specific {@link IntegrityReference} against a given file.
     *
     * @param reference the stored reference containing expected hashes
     * @param file      the file to check
     * @return {@link IntegrityCheckResult} containing decision and audit information
     */
    public IntegrityCheckResult verifyReference(IntegrityReference reference, File file) {
        String checkedAt = SecurityUtils.currentTimestamp();

        if (reference == null) {
            return new IntegrityCheckResult(
                    null,
                    file != null ? file.getName() : "Unknown",
                    null, null, null, null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY,
                    checkedAt,
                    "Unable to verify: Stored reference is null."
            );
        }

        if (file == null || !file.exists() || !file.isFile() || !file.canRead()) {
            String errorMsg = (file == null) ? "File is null."
                    : (!file.exists()) ? "Target file does not exist on disk."
                    : (!file.canRead()) ? "File access denied (unreadable)."
                    : "Target path is a directory, not a regular file.";

            IntegrityCheck checkRecord = new IntegrityCheck(
                    reference.getId(),
                    reference.getFileName(),
                    checkedAt,
                    reference.getMd5(),
                    null,
                    reference.getSha256(),
                    null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY
            );
            historyRepository.insert(checkRecord);

            return new IntegrityCheckResult(
                    reference.getId(),
                    reference.getFileName(),
                    reference.getMd5(),
                    null,
                    reference.getSha256(),
                    null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY,
                    checkedAt,
                    "Unable to verify: " + errorMsg
            );
        }

        try {
            String[] actualHashes = hashService.computeAllHashes(file);
            String actualMd5 = actualHashes[0];
            String actualSha256 = actualHashes[1];

            String expectedMd5 = reference.getMd5();
            String expectedSha256 = reference.getSha256();

            boolean shaMatch = expectedSha256 != null && expectedSha256.equalsIgnoreCase(actualSha256);
            boolean md5Match = expectedMd5 != null && expectedMd5.equalsIgnoreCase(actualMd5);

            String resultStatus;
            String explanation;

            // SHA-256 is the primary decision factor
            if (shaMatch) {
                resultStatus = Constants.INTEGRITY_VERIFIED;
                explanation = "SHA-256 matches the stored reference. File integrity verified.";
            } else {
                resultStatus = Constants.INTEGRITY_MODIFIED;
                explanation = "SHA-256 differs from the stored reference. The file contents may have changed.";
                if (md5Match) {
                    explanation += " (Note: MD5 matched, but SHA-256 mismatch takes authoritative precedence).";
                }
            }

            IntegrityCheck checkRecord = new IntegrityCheck(
                    reference.getId(),
                    reference.getFileName(),
                    checkedAt,
                    expectedMd5,
                    actualMd5,
                    expectedSha256,
                    actualSha256,
                    resultStatus
            );
            historyRepository.insert(checkRecord);

            return new IntegrityCheckResult(
                    reference.getId(),
                    reference.getFileName(),
                    expectedMd5,
                    actualMd5,
                    expectedSha256,
                    actualSha256,
                    resultStatus,
                    checkedAt,
                    explanation
            );
        } catch (IOException e) {
            String explanation = "Unable to compute file hashes due to an I/O error: " + e.getMessage();
            IntegrityCheck checkRecord = new IntegrityCheck(
                    reference.getId(),
                    reference.getFileName(),
                    checkedAt,
                    reference.getMd5(),
                    null,
                    reference.getSha256(),
                    null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY
            );
            historyRepository.insert(checkRecord);

            return new IntegrityCheckResult(
                    reference.getId(),
                    reference.getFileName(),
                    reference.getMd5(),
                    null,
                    reference.getSha256(),
                    null,
                    Constants.INTEGRITY_UNABLE_TO_VERIFY,
                    checkedAt,
                    explanation
            );
        }
    }

    /**
     * Retrieves all registered file references.
     */
    public List<IntegrityReference> getAllReferences() {
        return referenceRepository.findAll();
    }

    /**
     * Retrieves a reference by its ID.
     */
    public Optional<IntegrityReference> getReferenceById(int id) {
        return referenceRepository.findById(id);
    }

    /**
     * Deletes an integrity reference by its ID.
     */
    public boolean deleteReference(int id) {
        return referenceRepository.deleteById(id);
    }

    /**
     * Retrieves the audit verification history for a given reference.
     */
    public List<IntegrityCheck> getHistoryForReference(int referenceId) {
        return historyRepository.findByReferenceId(referenceId);
    }

    /**
     * Retrieves all integrity check audit records.
     */
    public List<IntegrityCheck> getAllHistory() {
        return historyRepository.findAll();
    }

    /**
     * Retrieves the most recent integrity check audit records.
     */
    public List<IntegrityCheck> getRecentHistory(int limit) {
        return historyRepository.findRecent(limit);
    }

    /**
     * Returns the total count of registered file references.
     */
    public int getReferenceCount() {
        return referenceRepository.count();
    }

    /**
     * Returns the total count of integrity checks performed.
     */
    public int getCheckCount() {
        return historyRepository.count();
    }
}
