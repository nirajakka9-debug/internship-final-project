package com.nettech.securechecker.repository;

import com.nettech.securechecker.model.PasswordHistory;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Repository for {@link PasswordHistory} CRUD operations.
 * <p>
 * <b>SECURITY INVARIANT:</b> Only password metadata (timestamp, length, strength label, score)
 * is persisted. Plaintext passwords, hashes, and encryption keys are NEVER processed or stored here.
 */
public class PasswordHistoryRepository {

    private final DatabaseManager databaseManager;

    public PasswordHistoryRepository() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    public PasswordHistoryRepository(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    /**
     * Inserts a new password history metadata record using a PreparedStatement.
     *
     * @param record the metadata record to insert
     * @return the generated ID, or -1 on failure
     */
    public int insert(PasswordHistory record) {
        if (record == null) {
            return -1;
        }

        String sql = "INSERT INTO password_history (generated_at, length, strength, score) VALUES (?, ?, ?, ?)";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, record.getGeneratedAt());
            stmt.setInt(2, record.getLength());
            stmt.setString(3, record.getStrength());
            if (record.getScore() != null) {
                stmt.setInt(4, record.getScore());
            } else {
                stmt.setNull(4, Types.INTEGER);
            }

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        record.setId(generatedId);
                        return generatedId;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to insert password history: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Retrieves all password history metadata records, ordered by most recent first.
     *
     * @return list of password history metadata records
     */
    public List<PasswordHistory> findAll() {
        List<PasswordHistory> list = new ArrayList<>();
        String sql = "SELECT id, generated_at, length, strength, score FROM password_history ORDER BY id DESC";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                PasswordHistory record = new PasswordHistory();
                record.setId(rs.getInt("id"));
                record.setGeneratedAt(rs.getString("generated_at"));
                record.setLength(rs.getInt("length"));
                record.setStrength(rs.getString("strength"));
                int score = rs.getInt("score");
                record.setScore(rs.wasNull() ? null : score);
                list.add(record);
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch password history: " + e.getMessage());
        }
        return list;
    }

    /**
     * Retrieves a password history record by its ID.
     *
     * @param id the record ID
     * @return an Optional containing the record, or empty if not found
     */
    public Optional<PasswordHistory> findById(int id) {
        String sql = "SELECT id, generated_at, length, strength, score FROM password_history WHERE id = ?";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    PasswordHistory record = new PasswordHistory();
                    record.setId(rs.getInt("id"));
                    record.setGeneratedAt(rs.getString("generated_at"));
                    record.setLength(rs.getInt("length"));
                    record.setStrength(rs.getString("strength"));
                    int score = rs.getInt("score");
                    record.setScore(rs.wasNull() ? null : score);
                    return Optional.of(record);
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch password history by ID: " + e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Returns the total count of password history metadata records.
     *
     * @return the count of records
     */
    public int count() {
        String sql = "SELECT COUNT(*) FROM password_history";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to count password history: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Deletes a password history record by its ID.
     *
     * @param id the record ID
     * @return true if a record was deleted, false otherwise
     */
    public boolean deleteById(int id) {
        String sql = "DELETE FROM password_history WHERE id = ?";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to delete password history: " + e.getMessage());
        }
        return false;
    }

    /**
     * Clears all password history records.
     *
     * @return true if successful
     */
    public boolean deleteAll() {
        String sql = "DELETE FROM password_history";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to clear password history: " + e.getMessage());
        }
        return false;
    }
}
