package com.nettech.securechecker.service;

import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.model.PasswordStrengthResult;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.util.Constants;
import com.nettech.securechecker.util.SecurityUtils;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Service orchestrating cryptographically secure password generation,
 * strength assessment, and zero-knowledge history metadata recording.
 * <p>
 * <b>SECURITY INVARIANTS:</b>
 * <ul>
 *   <li>All random number generation utilizes {@link java.security.SecureRandom}.</li>
 *   <li>Generated or analyzed passwords are NEVER logged or persisted.</li>
 *   <li>Only non-reversible metadata (timestamp, length, strength, score) is stored.</li>
 * </ul>
 */
public class PasswordService {

    private final SecureRandom secureRandom;
    private final PasswordStrengthService strengthService;
    private final PasswordHistoryRepository repository;

    public PasswordService() {
        this(new PasswordStrengthService(), new PasswordHistoryRepository());
    }

    public PasswordService(PasswordStrengthService strengthService, PasswordHistoryRepository repository) {
        this.secureRandom = new SecureRandom();
        this.strengthService = strengthService;
        this.repository = repository;
    }

    /**
     * Generates a secure password using default configuration (16 characters, all character sets enabled).
     *
     * @return cryptographically random generated password
     */
    public String generatePassword() {
        return generatePassword(Constants.DEFAULT_PASSWORD_LENGTH, true, true, true, true);
    }

    /**
     * Generates a cryptographically secure random password with customized length and character sets.
     *
     * @param length      desired length (between {@value Constants#MIN_PASSWORD_LENGTH} and {@value Constants#MAX_PASSWORD_LENGTH})
     * @param useUpper    include uppercase letters (A-Z)
     * @param useLower    include lowercase letters (a-z)
     * @param useDigits   include numeric digits (0-9)
     * @param useSpecial  include special punctuation characters
     * @return the generated password
     * @throws IllegalArgumentException if length is out of bounds or no character categories are enabled
     */
    public String generatePassword(int length, boolean useUpper, boolean useLower,
                                   boolean useDigits, boolean useSpecial) {
        if (!SecurityUtils.isValidPasswordLength(length)) {
            throw new IllegalArgumentException("Password length must be between " +
                    Constants.MIN_PASSWORD_LENGTH + " and " + Constants.MAX_PASSWORD_LENGTH + " characters.");
        }

        StringBuilder allowedChars = new StringBuilder();
        List<String> requiredCategories = new ArrayList<>();

        if (useLower) {
            allowedChars.append(Constants.CHARSET_LOWERCASE);
            requiredCategories.add(Constants.CHARSET_LOWERCASE);
        }
        if (useUpper) {
            allowedChars.append(Constants.CHARSET_UPPERCASE);
            requiredCategories.add(Constants.CHARSET_UPPERCASE);
        }
        if (useDigits) {
            allowedChars.append(Constants.CHARSET_DIGITS);
            requiredCategories.add(Constants.CHARSET_DIGITS);
        }
        if (useSpecial) {
            allowedChars.append(Constants.CHARSET_SPECIAL);
            requiredCategories.add(Constants.CHARSET_SPECIAL);
        }

        if (requiredCategories.isEmpty()) {
            throw new IllegalArgumentException("At least one character category (uppercase, lowercase, digits, special) must be enabled.");
        }

        char[] password = new char[length];
        int charIndex = 0;

        // Step 1: Ensure at least one character from each enabled category
        for (String category : requiredCategories) {
            if (charIndex < length) {
                int randomIndex = secureRandom.nextInt(category.length());
                password[charIndex++] = category.charAt(randomIndex);
            }
        }

        // Step 2: Fill the remaining length from the combined character pool
        String allChars = allowedChars.toString();
        int poolLength = allChars.length();
        while (charIndex < length) {
            int randomIndex = secureRandom.nextInt(poolLength);
            password[charIndex++] = allChars.charAt(randomIndex);
        }

        // Step 3: Secure Fisher-Yates shuffle using SecureRandom
        for (int i = length - 1; i > 0; i--) {
            int j = secureRandom.nextInt(i + 1);
            char temp = password[i];
            password[i] = password[j];
            password[j] = temp;
        }

        return new String(password);
    }

    /**
     * Assesses the strength of a given password and returns the strength label.
     *
     * @param password the password to evaluate
     * @return qualitative strength label (e.g. "Very Weak", "Strong")
     */
    public String assessStrength(String password) {
        return strengthService.analyzeStrength(password).getStrengthLabel();
    }

    /**
     * Calculates a numeric complexity score (0 to 100) for the given password.
     *
     * @param password the password to score
     * @return integer score between 0 and 100
     */
    public int calculateScore(String password) {
        return strengthService.analyzeStrength(password).getScore();
    }

    /**
     * Performs a full strength analysis on a password.
     *
     * @param password the password to analyze
     * @return detailed {@link PasswordStrengthResult}
     */
    public PasswordStrengthResult analyzePassword(String password) {
        return strengthService.analyzeStrength(password);
    }

    /**
     * Records metadata ABOUT a generated/analyzed password into history.
     * <p>
     * <b>SECURITY:</b> The password itself is NEVER passed to this method or stored in the database.
     *
     * @param length   length of the password
     * @param strength qualitative strength label
     * @param score    numeric score (0-100)
     * @return the generated ID of the recorded history entry
     */
    public int recordToHistory(int length, String strength, int score) {
        PasswordHistory history = new PasswordHistory(
                SecurityUtils.currentTimestamp(),
                length,
                strength,
                score
        );
        return repository.insert(history);
    }

    /**
     * Retrieves all recorded password metadata history.
     *
     * @return list of metadata records
     */
    public List<PasswordHistory> getHistory() {
        return repository.findAll();
    }

    /**
     * Returns the total count of password history metadata records.
     *
     * @return count
     */
    public int getHistoryCount() {
        return repository.count();
    }
}
