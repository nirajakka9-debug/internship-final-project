package com.nettech.securechecker.app;

import com.nettech.securechecker.controller.*;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.util.Constants;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Main JavaFX application class for NETTECH Secure Checker.
 * <p>
 * Builds the application shell with a sidebar navigation and
 * a dynamic content area. Initialises the database on startup.
 */
public class NettechApplication extends Application {

    private BorderPane root;
    private StackPane contentArea;
    private VBox sidebarNav;
    private String activePage = "Dashboard";

    // Controllers & Services
    private DashboardController dashboardController;
    private PasswordController passwordController;
    private IntegrityController integrityController;
    private ReportsController reportsController;
    private TipsController tipsController;
    private SettingsController settingsController;
    private com.nettech.securechecker.service.SettingsService settingsService;

    // Navigation items: label → icon symbol
    private final Map<String, String> navItems = new LinkedHashMap<>();

    @Override
    public void init() {
        // Initialize the database before the UI is shown
        DatabaseManager.getInstance().initialize();

        // Initialize settings service
        settingsService = new com.nettech.securechecker.service.SettingsService();

        // Define navigation entries
        navItems.put("Dashboard",         "\u25A3");  // ▣
        navItems.put("Password Security", "\u26BF");  // ⚿
        navItems.put("File Integrity",    "\u2637");  // ☷
        navItems.put("Reports",           "\u2630");  // ☰
        navItems.put("Security Tips",     "\u2731");  // ✱
        navItems.put("Settings",          "\u2699");  // ⚙
    }

    @Override
    public void start(Stage primaryStage) {
        // Initialize controllers
        dashboardController = new DashboardController(this);
        passwordController  = new PasswordController();
        integrityController = new IntegrityController();
        reportsController   = new ReportsController(settingsService);
        tipsController      = new TipsController();
        settingsController  = new SettingsController(this, settingsService);

        root = new BorderPane();
        root.setLeft(buildSidebar());

        contentArea = new StackPane();
        contentArea.setId("content-area");

        ScrollPane scrollWrapper = new ScrollPane(contentArea);
        scrollWrapper.setFitToWidth(true);
        scrollWrapper.setFitToHeight(true);
        scrollWrapper.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        root.setCenter(scrollWrapper);

        // Apply saved theme preference
        applyTheme(settingsService.getTheme());

        navigateTo("Dashboard");

        Scene scene = new Scene(root, Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
        scene.getStylesheets().add(
                getClass().getResource("/css/theme.css").toExternalForm()
        );

        primaryStage.setTitle(Constants.APP_TITLE);
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(600);
        primaryStage.show();
    }

    /**
     * Dynamically applies the chosen theme ("DARK" or "LIGHT") to the application root.
     */
    public void applyTheme(String theme) {
        if (root != null) {
            root.getStyleClass().remove("theme-light");
            if (Constants.THEME_LIGHT.equalsIgnoreCase(theme)) {
                root.getStyleClass().add("theme-light");
            }
        }
    }

    /**
     * Builds the left sidebar with branding and navigation.
     */
    private VBox buildSidebar() {
        VBox sidebar = new VBox();
        sidebar.setId("sidebar");

        // ── Brand header ──
        VBox header = new VBox(2);
        header.setId("sidebar-header");

        Label brand = new Label(Constants.APP_SHORT_NAME);
        brand.setId("sidebar-brand");

        Label subtitle = new Label("Security Toolkit");
        subtitle.setId("sidebar-subtitle");

        header.getChildren().addAll(brand, subtitle);

        // ── Separator ──
        Region separator = new Region();
        separator.getStyleClass().add("sidebar-separator");
        separator.setMaxWidth(Double.MAX_VALUE);
        VBox.setMargin(separator, new Insets(0, 16, 0, 16));

        // ── Navigation ──
        sidebarNav = new VBox();
        sidebarNav.setId("sidebar-nav");

        for (Map.Entry<String, String> entry : navItems.entrySet()) {
            String label = entry.getKey();
            String icon  = entry.getValue();
            Button btn = createNavButton(icon + "   " + label, label);
            sidebarNav.getChildren().add(btn);
        }

        // ── Spacer ──
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // ── Version label ──
        Label version = new Label("v" + Constants.APP_VERSION + "  •  Local/Offline");
        version.setId("sidebar-version");

        sidebar.getChildren().addAll(header, separator, sidebarNav, spacer, version);
        return sidebar;
    }

    /**
     * Creates a styled navigation button.
     */
    private Button createNavButton(String text, String pageId) {
        Button btn = new Button(text);
        btn.getStyleClass().add("nav-button");
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setOnAction(e -> navigateTo(pageId));

        if (pageId.equals(activePage)) {
            btn.getStyleClass().add("nav-button-active");
        }
        return btn;
    }

    /**
     * Navigates to the specified page and updates sidebar state.
     */
    public void navigateTo(String pageId) {
        activePage = pageId;
        updateSidebarState();

        if ("Dashboard".equals(pageId) && dashboardController != null) {
            dashboardController.refresh();
        }

        contentArea.getChildren().clear();
        contentArea.getChildren().add(getPageContent(pageId));
    }

    public DashboardController getDashboardController() {
        return dashboardController;
    }

    /**
     * Returns the content node for the given page.
     */
    private Region getPageContent(String pageId) {
        return switch (pageId) {
            case "Dashboard"         -> dashboardController.getView();
            case "Password Security" -> passwordController.getView();
            case "File Integrity"    -> integrityController.getView();
            case "Reports"           -> reportsController.getView();
            case "Security Tips"     -> tipsController.getView();
            case "Settings"          -> settingsController.getView();
            default                  -> dashboardController.getView();
        };
    }

    /**
     * Updates the active styling on sidebar navigation buttons.
     */
    private void updateSidebarState() {
        int idx = 0;
        for (String label : navItems.keySet()) {
            Button btn = (Button) sidebarNav.getChildren().get(idx);
            btn.getStyleClass().remove("nav-button-active");
            if (label.equals(activePage)) {
                btn.getStyleClass().add("nav-button-active");
            }
            idx++;
        }
    }

    @Override
    public void stop() {
        DatabaseManager.getInstance().shutdown();
    }
}
