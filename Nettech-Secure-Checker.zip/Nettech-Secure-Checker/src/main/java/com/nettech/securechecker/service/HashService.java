package com.nettech.securechecker.service;

import com.nettech.securechecker.model.FileHashResult;
import com.nettech.securechecker.util.Constants;
import com.nettech.securechecker.util.FileUtils;
import com.nettech.securechecker.util.SecurityUtils;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Service for computing cryptographic file hashes (MD5 and SHA-256).
 * <p>
 * <b>PERFORMANCE & MEMORY SAFETY:</b> Files are processed using chunked buffered streams
 * (default 1MB chunks), preventing entire files from being loaded into memory.
 * Dual-digest hashing computes both MD5 and SHA-256 in a single file read pass.
 */
public class HashService {

    private final int chunkSize;

    public HashService() {
        this(Constants.HASH_CHUNK_SIZE);
    }

    public HashService(int chunkSize) {
        this.chunkSize = chunkSize > 0 ? chunkSize : Constants.HASH_CHUNK_SIZE;
    }

    /**
     * Computes the lowercase hex-encoded MD5 hash of a file using chunked streaming.
     *
     * @param file the file to hash
     * @return hex-encoded MD5 digest
     * @throws IOException if the file does not exist, cannot be read, or is a directory
     */
    public String computeMd5(File file) throws IOException {
        return computeSingleDigest(file, Constants.ALGORITHM_MD5);
    }

    /**
     * Computes the lowercase hex-encoded SHA-256 hash of a file using chunked streaming.
     *
     * @param file the file to hash
     * @return hex-encoded SHA-256 digest
     * @throws IOException if the file does not exist, cannot be read, or is a directory
     */
    public String computeSha256(File file) throws IOException {
        return computeSingleDigest(file, Constants.ALGORITHM_SHA256);
    }

    /**
     * Computes both MD5 and SHA-256 hashes in a single streaming pass through the file.
     *
     * @param file the file to hash
     * @return a String array of length 2: [0] = MD5, [1] = SHA-256
     * @throws IOException if file validation or read fails
     */
    public String[] computeAllHashes(File file) throws IOException {
        validateFile(file);

        MessageDigest md5Digest = getDigestInstance(Constants.ALGORITHM_MD5);
        MessageDigest sha256Digest = getDigestInstance(Constants.ALGORITHM_SHA256);

        byte[] buffer = new byte[chunkSize];
        try (InputStream is = new BufferedInputStream(new FileInputStream(file))) {
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                md5Digest.update(buffer, 0, bytesRead);
                sha256Digest.update(buffer, 0, bytesRead);
            }
        }

        String md5Hex = bytesToHex(md5Digest.digest());
        String sha256Hex = bytesToHex(sha256Digest.digest());

        return new String[]{md5Hex, sha256Hex};
    }

    /**
     * Computes hashes and constructs a complete {@link FileHashResult} model.
     *
     * @param file the file to hash
     * @return a FileHashResult containing metadata and computed digests
     * @throws IOException if file validation or read fails
     */
    public FileHashResult calculateFileHash(File file) throws IOException {
        validateFile(file);
        String[] hashes = computeAllHashes(file);
        return new FileHashResult(
                file.getName(),
                file.getAbsolutePath(),
                file.length(),
                hashes[0],
                hashes[1],
                SecurityUtils.currentTimestamp()
        );
    }

    /**
     * Verifies whether a file's computed hash matches an expected hash.
     *
     * @param file          the file to verify
     * @param expectedHash  the expected hash string
     * @param algorithm     Constants.ALGORITHM_SHA256 or Constants.ALGORITHM_MD5
     * @return true if the hashes match (case-insensitively)
     * @throws IOException if file validation or read fails
     */
    public boolean verifyHash(File file, String expectedHash, String algorithm) throws IOException {
        if (expectedHash == null || expectedHash.isBlank()) {
            return false;
        }
        String actualHash;
        if (Constants.ALGORITHM_MD5.equalsIgnoreCase(algorithm)) {
            actualHash = computeMd5(file);
        } else if (Constants.ALGORITHM_SHA256.equalsIgnoreCase(algorithm)) {
            actualHash = computeSha256(file);
        } else {
            throw new IllegalArgumentException("Unsupported hashing algorithm: " + algorithm);
        }
        return actualHash.equalsIgnoreCase(expectedHash.trim());
    }

    private String computeSingleDigest(File file, String algorithm) throws IOException {
        validateFile(file);
        MessageDigest digest = getDigestInstance(algorithm);

        byte[] buffer = new byte[chunkSize];
        try (InputStream is = new BufferedInputStream(new FileInputStream(file))) {
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                digest.update(buffer, 0, bytesRead);
            }
        }
        return bytesToHex(digest.digest());
    }

    private void validateFile(File file) throws IOException {
        if (file == null) {
            throw new IllegalArgumentException("File cannot be null.");
        }
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + file.getAbsolutePath());
        }
        if (file.isDirectory()) {
            throw new IllegalArgumentException("Target is a directory, not a regular file: " + file.getAbsolutePath());
        }
        if (!file.canRead()) {
            throw new IOException("File cannot be read (permission denied): " + file.getAbsolutePath());
        }
    }

    private MessageDigest getDigestInstance(String algorithm) {
        try {
            return MessageDigest.getInstance(algorithm);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Cryptographic algorithm not available in JVM: " + algorithm, e);
        }
    }

    /**
     * Converts a byte array into a lowercase hexadecimal string.
     */
    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
