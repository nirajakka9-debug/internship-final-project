package com.nettech.securechecker.controller;

import com.nettech.securechecker.model.FileHashResult;
import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityCheckResult;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.service.HashService;
import com.nettech.securechecker.service.IntegrityService;
import com.nettech.securechecker.util.Constants;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.util.StringConverter;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Optional;

/**
 * Controller for the File Integrity UI module.
 * <p>
 * Manages UI interactions for:
 * <ul>
 *   <li>File Selection & Chunked Cryptographic Hashing (SHA-256 and MD5)</li>
 *   <li>Baseline Reference Registration & Storage</li>
 *   <li>Authoritative SHA-256 Integrity Verification against Baselines</li>
 *   <li>Saved Baseline References Management (Inspection & Deletion)</li>
 *   <li>Integrity Verification Audit History Log</li>
 * </ul>
 * <p>
 * <b>SECURITY INVARIANT:</b> All cryptographic hashing and database operations
 * are strictly delegated to {@link HashService} and {@link IntegrityService}.
 * File contents are never loaded completely into memory, uploaded to any network,
 * or stored in the database.
 */
public class IntegrityController {

    private final HashService hashService;
    private final IntegrityService integrityService;
    private final IntegrityReferenceRepository referenceRepository;
    private final IntegrityHistoryRepository historyRepository;

    // ── TabPane ──
    private TabPane mainTabPane;
    private Tab tabHash;
    private Tab tabVerify;
    private Tab tabReferences;
    private Tab tabHistory;

    // ── UI Components: Hash a File Tab ──
    private TextField hashFilePathField;
    private Label hashFileMetaLabel;
    private Button btnBrowseHashFile;
    private Button btnCalculateHashes;
    private ProgressBar hashProgressBar;
    private TextField sha256OutputField;
    private TextField md5OutputField;
    private Button btnCopySha256;
    private Button btnCopyMd5;
    private Button btnSaveReference;
    private Label hashFeedbackLabel;
    private File currentSelectedHashFile;
    private FileHashResult lastCalculatedHashResult;

    // ── UI Components: Verify Tab ──
    private ComboBox<IntegrityReference> verifyReferenceCombo;
    private ObservableList<IntegrityReference> referenceComboData;
    private Label refExpectedShaLabel;
    private Label refExpectedMdLabel;
    private Label refOriginalPathLabel;
    private Label refRegisteredDateLabel;
    private TextField verifyFilePathField;
    private Button btnBrowseVerifyFile;
    private Button btnVerifyIntegrity;
    private ProgressBar verifyProgressBar;
    private VBox verifyResultsContainer;
    private Label verifyStatusBadge;
    private Label verifyExplanationLabel;
    private Label actualShaComparisonLabel;
    private Label actualMdComparisonLabel;
    private Label verifyFeedbackLabel;
    private File currentSelectedVerifyFile;

    // ── UI Components: Saved References Tab ──
    private TableView<IntegrityReference> referencesTable;
    private ObservableList<IntegrityReference> referencesTableData;
    private Label referencesCountLabel;

    // ── UI Components: Check History Tab ──
    private TableView<IntegrityCheck> historyTable;
    private ObservableList<IntegrityCheck> historyTableData;
    private Label historyCountLabel;

    public IntegrityController() {
        this.hashService = new HashService();
        DatabaseManager dbManager = DatabaseManager.getInstance();
        this.referenceRepository = new IntegrityReferenceRepository(dbManager);
        this.historyRepository = new IntegrityHistoryRepository(dbManager);
        this.integrityService = new IntegrityService(this.hashService, this.referenceRepository, this.historyRepository);

        this.referenceComboData = FXCollections.observableArrayList();
        this.referencesTableData = FXCollections.observableArrayList();
        this.historyTableData = FXCollections.observableArrayList();
    }

    public IntegrityController(HashService hashService, IntegrityService integrityService,
                               IntegrityReferenceRepository referenceRepository,
                               IntegrityHistoryRepository historyRepository) {
        this.hashService = hashService;
        this.integrityService = integrityService;
        this.referenceRepository = referenceRepository;
        this.historyRepository = historyRepository;

        this.referenceComboData = FXCollections.observableArrayList();
        this.referencesTableData = FXCollections.observableArrayList();
        this.historyTableData = FXCollections.observableArrayList();
    }

    /**
     * Builds and returns the complete File Integrity interface view.
     */
    public Region getView() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(0));

        // ── Header ──
        Label title = new Label("File Integrity");
        title.getStyleClass().add("page-title");

        Label subtitle = new Label("Generate cryptographic checksums, catalog baseline references, and verify files against tampering.");
        subtitle.getStyleClass().add("page-subtitle");

        // ── TabPane ──
        mainTabPane = new TabPane();
        mainTabPane.getStyleClass().add("tab-pane");

        tabHash = new Tab("⚡  Hash a File", buildHashTabContent());
        tabHash.setClosable(false);

        tabVerify = new Tab("🛡️  Verify Integrity", buildVerifyTabContent());
        tabVerify.setClosable(false);

        tabReferences = new Tab("📁  Saved References", buildReferencesTabContent());
        tabReferences.setClosable(false);

        tabHistory = new Tab("📋  Check History", buildHistoryTabContent());
        tabHistory.setClosable(false);

        mainTabPane.getTabs().addAll(tabHash, tabVerify, tabReferences, tabHistory);

        root.getChildren().addAll(title, subtitle, mainTabPane);

        // Load data on background thread
        refreshReferencesData();
        refreshHistoryData();

        return root;
    }

    // =========================================================================
    // 1. TAB: HASH A FILE
    // =========================================================================

    private VBox buildHashTabContent() {
        VBox content = new VBox(16);
        content.setPadding(new Insets(16, 0, 0, 0));

        VBox card = new VBox(16);
        card.getStyleClass().add("card");

        // Header
        Label cardTitle = new Label("⚡  Calculate File Checksums (SHA-256 & MD5)");
        cardTitle.getStyleClass().add("card-title");
        cardTitle.setStyle("-fx-font-size: 15px; -fx-text-fill: -nt-accent;");

        Label cardDesc = new Label("Select any local file to compute cryptographic digests using memory-safe chunked streaming.");
        cardDesc.getStyleClass().add("card-value");
        cardDesc.setWrapText(true);

        // ── File Selection Row ──
        VBox filePickerBox = new VBox(6);
        Label filePickerLabel = new Label("Select Target File:");
        filePickerLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12.5px;");

        HBox filePickerRow = new HBox(8);
        filePickerRow.setAlignment(Pos.CENTER_LEFT);

        hashFilePathField = new TextField();
        hashFilePathField.setPromptText("Choose a file or enter absolute path...");
        hashFilePathField.getStyleClass().add("text-field");
        HBox.setHgrow(hashFilePathField, Priority.ALWAYS);
        hashFilePathField.textProperty().addListener((obs, oldVal, newVal) -> onHashFilePathChanged(newVal));

        btnBrowseHashFile = new Button("📁  Browse...");
        btnBrowseHashFile.getStyleClass().add("action-button");
        btnBrowseHashFile.setOnAction(e -> handleBrowseHashFile());

        btnCalculateHashes = new Button("⚡  Calculate Hashes");
        btnCalculateHashes.getStyleClass().add("action-button-primary");
        btnCalculateHashes.setOnAction(e -> handleCalculateHashes());

        filePickerRow.getChildren().addAll(hashFilePathField, btnBrowseHashFile, btnCalculateHashes);

        hashFileMetaLabel = new Label("No file selected.");
        hashFileMetaLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-muted;");

        filePickerBox.getChildren().addAll(filePickerLabel, filePickerRow, hashFileMetaLabel);

        // ── Progress Bar ──
        hashProgressBar = new ProgressBar(0);
        hashProgressBar.setMaxWidth(Double.MAX_VALUE);
        hashProgressBar.setVisible(false);
        hashProgressBar.setManaged(false);

        // ── Hash Output Box ──
        VBox hashResultsBox = new VBox(12);
        hashResultsBox.setStyle("-fx-background-color: #111622; -fx-padding: 16; -fx-background-radius: 8; -fx-border-color: -nt-border; -fx-border-radius: 8;");

        // SHA-256 Output
        VBox shaBox = new VBox(6);
        Label shaLabel = new Label("SHA-256 (Authoritative Cryptographic Standard):");
        shaLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12px;");

        HBox shaRow = new HBox(8);
        shaRow.setAlignment(Pos.CENTER_LEFT);

        sha256OutputField = new TextField();
        sha256OutputField.setEditable(false);
        sha256OutputField.setPromptText("64-character SHA-256 digest will appear here...");
        sha256OutputField.getStyleClass().addAll("text-field", "text-field-readonly");
        HBox.setHgrow(sha256OutputField, Priority.ALWAYS);

        btnCopySha256 = new Button("📋  Copy SHA-256");
        btnCopySha256.getStyleClass().add("action-button");
        btnCopySha256.setDisable(true);
        btnCopySha256.setOnAction(e -> copyToClipboard(sha256OutputField.getText(), "SHA-256 hash"));

        shaRow.getChildren().addAll(sha256OutputField, btnCopySha256);
        shaBox.getChildren().addAll(shaLabel, shaRow);

        // MD5 Output
        VBox md5Box = new VBox(6);
        Label md5Label = new Label("MD5 (Legacy Compatibility Checksum):");
        md5Label.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12px;");

        HBox md5Row = new HBox(8);
        md5Row.setAlignment(Pos.CENTER_LEFT);

        md5OutputField = new TextField();
        md5OutputField.setEditable(false);
        md5OutputField.setPromptText("32-character MD5 digest will appear here...");
        md5OutputField.getStyleClass().addAll("text-field", "text-field-readonly");
        HBox.setHgrow(md5OutputField, Priority.ALWAYS);

        btnCopyMd5 = new Button("📋  Copy MD5");
        btnCopyMd5.getStyleClass().add("action-button");
        btnCopyMd5.setDisable(true);
        btnCopyMd5.setOnAction(e -> copyToClipboard(md5OutputField.getText(), "MD5 hash"));

        md5Row.getChildren().addAll(md5OutputField, btnCopyMd5);
        md5Box.getChildren().addAll(md5Label, md5Row);

        // ── Save Reference Button ──
        HBox saveRow = new HBox(12);
        saveRow.setAlignment(Pos.CENTER_LEFT);

        btnSaveReference = new Button("💾  Save as Baseline Reference");
        btnSaveReference.getStyleClass().add("action-button-primary");
        btnSaveReference.setDisable(true);
        btnSaveReference.setOnAction(e -> handleSaveAsReference());

        hashFeedbackLabel = new Label();
        hashFeedbackLabel.setWrapText(true);
        HBox.setHgrow(hashFeedbackLabel, Priority.ALWAYS);

        saveRow.getChildren().addAll(btnSaveReference, hashFeedbackLabel);

        hashResultsBox.getChildren().addAll(shaBox, md5Box, saveRow);

        card.getChildren().addAll(cardTitle, cardDesc, filePickerBox, hashProgressBar, hashResultsBox);
        content.getChildren().add(card);
        return content;
    }

    private void handleBrowseHashFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select File to Hash");
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            hashFilePathField.setText(file.getAbsolutePath());
        }
    }

    private void onHashFilePathChanged(String path) {
        if (path == null || path.isBlank()) {
            currentSelectedHashFile = null;
            hashFileMetaLabel.setText("No file selected.");
            return;
        }
        File file = new File(path.trim());
        if (file.exists() && file.isFile()) {
            currentSelectedHashFile = file;
            hashFileMetaLabel.setText(String.format("File: %s  •  Size: %s",
                    file.getName(), formatFileSize(file.length())));
        } else if (file.exists() && file.isDirectory()) {
            currentSelectedHashFile = null;
            hashFileMetaLabel.setText("⚠ Selected path is a directory. Please choose a regular file.");
        } else {
            currentSelectedHashFile = null;
            hashFileMetaLabel.setText("⚠ File does not exist on disk.");
        }
    }

    private void handleCalculateHashes() {
        String path = hashFilePathField.getText();
        if (path == null || path.isBlank()) {
            hashFeedbackLabel.setText("⚠ Please select a valid file first.");
            hashFeedbackLabel.getStyleClass().setAll("feedback-error");
            return;
        }

        File file = new File(path.trim());
        if (!file.exists() || !file.isFile()) {
            hashFeedbackLabel.setText("⚠ Target file does not exist or is a directory.");
            hashFeedbackLabel.getStyleClass().setAll("feedback-error");
            return;
        }

        if (!file.canRead()) {
            hashFeedbackLabel.setText("⚠ File access denied. The application lacks permission to read this file.");
            hashFeedbackLabel.getStyleClass().setAll("feedback-error");
            return;
        }

        // Set busy state
        setHashControlsBusy(true);
        hashFeedbackLabel.setText("Calculating SHA-256 and MD5 hashes using chunked streaming...");
        hashFeedbackLabel.getStyleClass().setAll("feedback-message");

        Task<FileHashResult> hashTask = new Task<>() {
            @Override
            protected FileHashResult call() throws Exception {
                return hashService.calculateFileHash(file);
            }
        };

        hashTask.setOnSucceeded(e -> {
            FileHashResult result = hashTask.getValue();
            lastCalculatedHashResult = result;

            sha256OutputField.setText(result.getSha256());
            md5OutputField.setText(result.getMd5());
            btnCopySha256.setDisable(false);
            btnCopyMd5.setDisable(false);
            btnSaveReference.setDisable(false);

            hashFeedbackLabel.setText("✓ Hashes calculated successfully!");
            hashFeedbackLabel.getStyleClass().setAll("feedback-success");
            setHashControlsBusy(false);
        });

        hashTask.setOnFailed(e -> {
            Throwable ex = hashTask.getException();
            hashFeedbackLabel.setText("Error hashing file: " + (ex != null ? ex.getMessage() : "Unknown I/O error"));
            hashFeedbackLabel.getStyleClass().setAll("feedback-error");
            setHashControlsBusy(false);
        });

        Thread hashThread = new Thread(hashTask);
        hashThread.setDaemon(true);
        hashThread.start();
    }

    private void handleSaveAsReference() {
        if (lastCalculatedHashResult == null || currentSelectedHashFile == null) {
            hashFeedbackLabel.setText("⚠ Please calculate hashes first before saving reference.");
            hashFeedbackLabel.getStyleClass().setAll("feedback-error");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Save Baseline Reference");
        confirm.setHeaderText("Store baseline reference for: " + currentSelectedHashFile.getName());
        confirm.setContentText(String.format("File: %s\nSize: %s\nSHA-256: %s\n\nSave this cryptographic baseline to database?",
                currentSelectedHashFile.getName(),
                formatFileSize(currentSelectedHashFile.length()),
                lastCalculatedHashResult.getSha256()));

        Optional<ButtonType> opt = confirm.showAndWait();
        if (opt.isPresent() && opt.get() == ButtonType.OK) {
            try {
                IntegrityReference ref = integrityService.registerFile(currentSelectedHashFile);
                hashFeedbackLabel.setText(String.format("✓ Reference #%d saved for '%s'!", ref.getId(), ref.getFileName()));
                hashFeedbackLabel.getStyleClass().setAll("feedback-success");

                // Refresh references list in background
                refreshReferencesData();
            } catch (Exception ex) {
                hashFeedbackLabel.setText("Failed to save reference: " + ex.getMessage());
                hashFeedbackLabel.getStyleClass().setAll("feedback-error");
            }
        }
    }

    private void setHashControlsBusy(boolean busy) {
        btnCalculateHashes.setDisable(busy);
        btnBrowseHashFile.setDisable(busy);
        hashProgressBar.setVisible(busy);
        hashProgressBar.setManaged(busy);
    }

    // =========================================================================
    // 2. TAB: VERIFY INTEGRITY
    // =========================================================================

    private VBox buildVerifyTabContent() {
        VBox content = new VBox(16);
        content.setPadding(new Insets(16, 0, 0, 0));

        VBox card = new VBox(16);
        card.getStyleClass().add("card");

        // Header
        Label cardTitle = new Label("🛡️  Verify File Against Baseline Reference");
        cardTitle.getStyleClass().add("card-title");
        cardTitle.setStyle("-fx-font-size: 15px; -fx-text-fill: -nt-accent;");

        Label cardDesc = new Label("Select a saved baseline reference and compare its expected hashes against a current file. SHA-256 is the authoritative test.");
        cardDesc.getStyleClass().add("card-value");
        cardDesc.setWrapText(true);

        // ── 1. Select Reference Row ──
        VBox refPickerBox = new VBox(6);
        Label refPickerLabel = new Label("1. Select Stored Reference:");
        refPickerLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12.5px;");

        HBox refRow = new HBox(8);
        refRow.setAlignment(Pos.CENTER_LEFT);

        verifyReferenceCombo = new ComboBox<>(referenceComboData);
        verifyReferenceCombo.setPromptText("Choose a stored baseline reference...");
        verifyReferenceCombo.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(verifyReferenceCombo, Priority.ALWAYS);

        verifyReferenceCombo.setConverter(new StringConverter<>() {
            @Override
            public String toString(IntegrityReference ref) {
                if (ref == null) return "";
                return String.format("#%d — %s (%s)", ref.getId(), ref.getFileName(), ref.getCreatedAt());
            }

            @Override
            public IntegrityReference fromString(String string) {
                return null;
            }
        });

        verifyReferenceCombo.valueProperty().addListener((obs, oldVal, newVal) -> onReferenceSelected(newVal));

        Button btnRefreshRefs = new Button("⟳  Refresh");
        btnRefreshRefs.getStyleClass().add("action-button");
        btnRefreshRefs.setOnAction(e -> refreshReferencesData());

        refRow.getChildren().addAll(verifyReferenceCombo, btnRefreshRefs);
        refPickerBox.getChildren().addAll(refPickerLabel, refRow);

        // Reference Details Card
        VBox refDetailsCard = new VBox(6);
        refDetailsCard.setStyle("-fx-background-color: #111622; -fx-padding: 12; -fx-background-radius: 6; -fx-border-color: -nt-border; -fx-border-radius: 6;");

        refExpectedShaLabel = new Label("Expected SHA-256: —");
        refExpectedShaLabel.setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 12px; -fx-text-fill: -nt-accent;");

        refExpectedMdLabel = new Label("Expected MD5: —");
        refExpectedMdLabel.setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 12px; -fx-text-fill: -nt-text-secondary;");

        refOriginalPathLabel = new Label("Original Path: —");
        refOriginalPathLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-muted;");

        refRegisteredDateLabel = new Label("Baseline Date: —");
        refRegisteredDateLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-muted;");

        refDetailsCard.getChildren().addAll(refExpectedShaLabel, refExpectedMdLabel, refOriginalPathLabel, refRegisteredDateLabel);

        // ── 2. Select Current File Row ──
        VBox currentFileBox = new VBox(6);
        Label currentFileLabel = new Label("2. Select Current File to Verify:");
        currentFileLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 12.5px;");

        HBox currentFileRow = new HBox(8);
        currentFileRow.setAlignment(Pos.CENTER_LEFT);

        verifyFilePathField = new TextField();
        verifyFilePathField.setPromptText("Path of current file to verify...");
        verifyFilePathField.getStyleClass().add("text-field");
        HBox.setHgrow(verifyFilePathField, Priority.ALWAYS);
        verifyFilePathField.textProperty().addListener((obs, oldVal, newVal) -> onVerifyFilePathChanged(newVal));

        btnBrowseVerifyFile = new Button("📁  Browse...");
        btnBrowseVerifyFile.getStyleClass().add("action-button");
        btnBrowseVerifyFile.setOnAction(e -> handleBrowseVerifyFile());

        btnVerifyIntegrity = new Button("🛡️  Verify Integrity");
        btnVerifyIntegrity.getStyleClass().add("action-button-primary");
        btnVerifyIntegrity.setOnAction(e -> handleVerifyIntegrity());

        currentFileRow.getChildren().addAll(verifyFilePathField, btnBrowseVerifyFile, btnVerifyIntegrity);
        currentFileBox.getChildren().addAll(currentFileLabel, currentFileRow);

        // Progress Bar
        verifyProgressBar = new ProgressBar(0);
        verifyProgressBar.setMaxWidth(Double.MAX_VALUE);
        verifyProgressBar.setVisible(false);
        verifyProgressBar.setManaged(false);

        // ── 3. Verification Results Card ──
        verifyResultsContainer = new VBox(12);
        verifyResultsContainer.setStyle("-fx-background-color: #111622; -fx-padding: 16; -fx-background-radius: 8; -fx-border-color: -nt-border; -fx-border-radius: 8;");

        HBox statusRow = new HBox(12);
        statusRow.setAlignment(Pos.CENTER_LEFT);

        Label statusHeader = new Label("Verification Status:");
        statusHeader.setStyle("-fx-font-weight: bold; -fx-text-fill: -nt-text-primary; -fx-font-size: 13px;");

        verifyStatusBadge = new Label("NOT CHECKED");
        verifyStatusBadge.getStyleClass().addAll("status-badge", "status-warning");

        statusRow.getChildren().addAll(statusHeader, verifyStatusBadge);

        verifyExplanationLabel = new Label("Select a reference and current file, then click 'Verify Integrity'.");
        verifyExplanationLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: -nt-text-secondary;");
        verifyExplanationLabel.setWrapText(true);

        actualShaComparisonLabel = new Label("Actual SHA-256: —");
        actualShaComparisonLabel.setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 12px; -fx-text-fill: -nt-text-primary;");

        actualMdComparisonLabel = new Label("Actual MD5: —");
        actualMdComparisonLabel.setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 12px; -fx-text-fill: -nt-text-secondary;");

        verifyFeedbackLabel = new Label();
        verifyFeedbackLabel.setStyle("-fx-font-size: 11.5px; -fx-text-fill: -nt-text-muted;");

        verifyResultsContainer.getChildren().addAll(
                statusRow, verifyExplanationLabel,
                actualShaComparisonLabel, actualMdComparisonLabel,
                verifyFeedbackLabel
        );

        card.getChildren().addAll(cardTitle, cardDesc, refPickerBox, refDetailsCard, currentFileBox, verifyProgressBar, verifyResultsContainer);
        content.getChildren().add(card);
        return content;
    }

    private void onReferenceSelected(IntegrityReference ref) {
        if (ref == null) {
            refExpectedShaLabel.setText("Expected SHA-256: —");
            refExpectedMdLabel.setText("Expected MD5: —");
            refOriginalPathLabel.setText("Original Path: —");
            refRegisteredDateLabel.setText("Baseline Date: —");
            return;
        }

        refExpectedShaLabel.setText("Expected SHA-256: " + ref.getSha256());
        refExpectedMdLabel.setText("Expected MD5: " + ref.getMd5());
        refOriginalPathLabel.setText("Original Path: " + ref.getFilePath());
        refRegisteredDateLabel.setText("Baseline Date: " + ref.getCreatedAt());

        // Pre-fill path if verify field is currently empty or matching original path
        if (verifyFilePathField.getText().isBlank() || verifyFilePathField.getText().equals(ref.getFilePath())) {
            verifyFilePathField.setText(ref.getFilePath());
        }
    }

    private void handleBrowseVerifyFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Current File to Verify");
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            verifyFilePathField.setText(file.getAbsolutePath());
        }
    }

    private void onVerifyFilePathChanged(String path) {
        if (path == null || path.isBlank()) {
            currentSelectedVerifyFile = null;
            return;
        }
        File file = new File(path.trim());
        if (file.exists() && file.isFile()) {
            currentSelectedVerifyFile = file;
        } else {
            currentSelectedVerifyFile = null;
        }
    }

    private void handleVerifyIntegrity() {
        IntegrityReference selectedRef = verifyReferenceCombo.getValue();
        if (selectedRef == null) {
            verifyExplanationLabel.setText("⚠ Please choose a saved baseline reference first.");
            verifyStatusBadge.setText("UNABLE TO VERIFY");
            verifyStatusBadge.getStyleClass().setAll("status-badge", "status-warning");
            return;
        }

        String path = verifyFilePathField.getText();
        if (path == null || path.isBlank()) {
            verifyExplanationLabel.setText("⚠ Please specify a target file path to verify.");
            verifyStatusBadge.setText("UNABLE TO VERIFY");
            verifyStatusBadge.getStyleClass().setAll("status-badge", "status-warning");
            return;
        }

        File targetFile = new File(path.trim());

        setVerifyControlsBusy(true);
        verifyExplanationLabel.setText("Verifying cryptographic hashes on background thread...");

        Task<IntegrityCheckResult> verifyTask = new Task<>() {
            @Override
            protected IntegrityCheckResult call() {
                return integrityService.verifyReference(selectedRef, targetFile);
            }
        };

        verifyTask.setOnSucceeded(e -> {
            IntegrityCheckResult result = verifyTask.getValue();
            updateVerifyResultsDisplay(result);
            setVerifyControlsBusy(false);

            // Refresh check history table in background
            refreshHistoryData();
        });

        verifyTask.setOnFailed(e -> {
            Throwable ex = verifyTask.getException();
            verifyStatusBadge.setText("ERROR");
            verifyStatusBadge.getStyleClass().setAll("status-badge", "status-danger");
            verifyExplanationLabel.setText("Verification failed: " + (ex != null ? ex.getMessage() : "Unknown error"));
            setVerifyControlsBusy(false);
        });

        Thread verifyThread = new Thread(verifyTask);
        verifyThread.setDaemon(true);
        verifyThread.start();
    }

    private void updateVerifyResultsDisplay(IntegrityCheckResult result) {
        String status = result.getResult();
        verifyStatusBadge.setText(status);
        verifyStatusBadge.getStyleClass().setAll("status-badge");

        if (result.isVerified()) {
            verifyStatusBadge.getStyleClass().add("status-secure");
        } else if (result.isModified()) {
            verifyStatusBadge.getStyleClass().add("status-danger");
        } else {
            verifyStatusBadge.getStyleClass().add("status-warning");
        }

        verifyExplanationLabel.setText(result.getExplanation());
        actualShaComparisonLabel.setText("Actual SHA-256: " + (result.getActualSha256() != null ? result.getActualSha256() : "—"));
        actualMdComparisonLabel.setText("Actual MD5: " + (result.getActualMd5() != null ? result.getActualMd5() : "—"));

        verifyFeedbackLabel.setText("✓ Verification logged to database audit trail at " + result.getCheckedAt());
    }

    private void setVerifyControlsBusy(boolean busy) {
        btnVerifyIntegrity.setDisable(busy);
        btnBrowseVerifyFile.setDisable(busy);
        verifyReferenceCombo.setDisable(busy);
        verifyProgressBar.setVisible(busy);
        verifyProgressBar.setManaged(busy);
    }

    // =========================================================================
    // 3. TAB: SAVED REFERENCES
    // =========================================================================

    @SuppressWarnings("unchecked")
    private VBox buildReferencesTabContent() {
        VBox content = new VBox(12);
        content.setPadding(new Insets(16, 0, 0, 0));

        // Header Row
        HBox headerRow = new HBox(12);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("Cataloged Baseline References");
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-padding: 0;");

        referencesCountLabel = new Label("Total References: 0");
        referencesCountLabel.setStyle("-fx-text-fill: -nt-text-muted; -fx-font-size: 13px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRefresh = new Button("⟳  Refresh");
        btnRefresh.getStyleClass().add("action-button");
        btnRefresh.setOnAction(e -> refreshReferencesData());

        Button btnVerifySelected = new Button("🛡️  Verify Selected Reference");
        btnVerifySelected.getStyleClass().add("action-button");
        btnVerifySelected.setOnAction(e -> handleVerifySelectedReference());

        Button btnDelete = new Button("🗑  Delete Reference");
        btnDelete.getStyleClass().add("action-button");
        btnDelete.setOnAction(e -> handleDeleteReference());

        headerRow.getChildren().addAll(title, referencesCountLabel, spacer, btnRefresh, btnVerifySelected, btnDelete);

        // Table
        referencesTable = new TableView<>(referencesTableData);
        referencesTable.setPrefHeight(450);
        referencesTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<IntegrityReference, Integer> colId = new TableColumn<>("#");
        colId.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getId()));
        colId.setMaxWidth(60);
        colId.setMinWidth(40);

        TableColumn<IntegrityReference, String> colName = new TableColumn<>("File Name");
        colName.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getFileName()));
        colName.setMinWidth(140);

        TableColumn<IntegrityReference, Long> colSize = new TableColumn<>("File Size");
        colSize.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getFileSize()));
        colSize.setMinWidth(90);
        colSize.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Long size, boolean empty) {
                super.updateItem(size, empty);
                setText(empty || size == null ? null : formatFileSize(size));
            }
        });

        TableColumn<IntegrityReference, String> colSha = new TableColumn<>("SHA-256 Digest (Baseline)");
        colSha.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getSha256()));
        colSha.setMinWidth(220);
        colSha.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String sha, boolean empty) {
                super.updateItem(sha, empty);
                if (empty || sha == null) {
                    setText(null);
                    setTooltip(null);
                } else {
                    setText(sha);
                    setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 11.5px; -fx-text-fill: -nt-accent;");
                    setTooltip(new Tooltip(sha));
                }
            }
        });

        TableColumn<IntegrityReference, String> colDate = new TableColumn<>("Registered / Updated Date");
        colDate.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getUpdatedAt()));
        colDate.setMinWidth(160);

        referencesTable.getColumns().addAll(colId, colName, colSize, colSha, colDate);
        referencesTable.setPlaceholder(new Label("No baseline references saved yet. Use 'Hash a File' to calculate and save references."));

        content.getChildren().addAll(headerRow, referencesTable);
        return content;
    }

    private void handleVerifySelectedReference() {
        IntegrityReference selected = referencesTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No Reference Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select a reference from the table first.");
            alert.showAndWait();
            return;
        }

        // Switch to Verify Tab and select this reference
        verifyReferenceCombo.setValue(selected);
        mainTabPane.getSelectionModel().select(tabVerify);
    }

    private void handleDeleteReference() {
        IntegrityReference selected = referencesTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No Reference Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select a reference from the table to delete.");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Baseline Reference");
        confirm.setHeaderText("Delete reference #" + selected.getId() + " (" + selected.getFileName() + ")?");
        confirm.setContentText("This will remove the baseline reference from the database. This action cannot be undone.");

        Optional<ButtonType> opt = confirm.showAndWait();
        if (opt.isPresent() && opt.get() == ButtonType.OK) {
            integrityService.deleteReference(selected.getId());
            refreshReferencesData();
        }
    }

    private void refreshReferencesData() {
        Thread thread = new Thread(() -> {
            try {
                List<IntegrityReference> list = integrityService.getAllReferences();
                int count = integrityService.getReferenceCount();
                Platform.runLater(() -> {
                    referencesTableData.setAll(list);
                    referenceComboData.setAll(list);
                    if (referencesCountLabel != null) {
                        referencesCountLabel.setText("Total References: " + count);
                    }
                });
            } catch (Exception ex) {
                System.err.println("[NETTECH] Failed to load integrity references: " + ex.getMessage());
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    // =========================================================================
    // 4. TAB: CHECK HISTORY
    // =========================================================================

    @SuppressWarnings("unchecked")
    private VBox buildHistoryTabContent() {
        VBox content = new VBox(12);
        content.setPadding(new Insets(16, 0, 0, 0));

        // Header Row
        HBox headerRow = new HBox(12);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("Integrity Verification Audit History");
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-padding: 0;");

        historyCountLabel = new Label("Total Checks: 0");
        historyCountLabel.setStyle("-fx-text-fill: -nt-text-muted; -fx-font-size: 13px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRefresh = new Button("⟳  Refresh");
        btnRefresh.getStyleClass().add("action-button");
        btnRefresh.setOnAction(e -> refreshHistoryData());

        headerRow.getChildren().addAll(title, historyCountLabel, spacer, btnRefresh);

        // Table
        historyTable = new TableView<>(historyTableData);
        historyTable.setPrefHeight(450);
        historyTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<IntegrityCheck, Integer> colId = new TableColumn<>("#");
        colId.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getId()));
        colId.setMaxWidth(60);
        colId.setMinWidth(40);

        TableColumn<IntegrityCheck, String> colName = new TableColumn<>("File Name");
        colName.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getFileName()));
        colName.setMinWidth(140);

        TableColumn<IntegrityCheck, String> colDate = new TableColumn<>("Checked Date / Time");
        colDate.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getCheckedAt()));
        colDate.setMinWidth(160);

        TableColumn<IntegrityCheck, String> colResult = new TableColumn<>("Result Status");
        colResult.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getResult()));
        colResult.setMinWidth(130);
        colResult.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String result, boolean empty) {
                super.updateItem(result, empty);
                if (empty || result == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    Label badge = new Label(result);
                    badge.getStyleClass().add("status-badge");
                    if (Constants.INTEGRITY_VERIFIED.equalsIgnoreCase(result)) {
                        badge.getStyleClass().add("status-secure");
                    } else if (Constants.INTEGRITY_MODIFIED.equalsIgnoreCase(result)) {
                        badge.getStyleClass().add("status-danger");
                    } else {
                        badge.getStyleClass().add("status-warning");
                    }
                    setGraphic(badge);
                    setText(null);
                }
            }
        });

        TableColumn<IntegrityCheck, String> colExpectedSha = new TableColumn<>("Expected SHA-256");
        colExpectedSha.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getExpectedSha256()));
        colExpectedSha.setMinWidth(160);
        colExpectedSha.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String sha, boolean empty) {
                super.updateItem(sha, empty);
                if (empty || sha == null) {
                    setText("—");
                    setTooltip(null);
                } else {
                    setText(sha);
                    setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 11px;");
                    setTooltip(new Tooltip(sha));
                }
            }
        });

        TableColumn<IntegrityCheck, String> colActualSha = new TableColumn<>("Actual SHA-256");
        colActualSha.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getActualSha256()));
        colActualSha.setMinWidth(160);
        colActualSha.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String sha, boolean empty) {
                super.updateItem(sha, empty);
                if (empty || sha == null) {
                    setText("—");
                    setTooltip(null);
                } else {
                    setText(sha);
                    setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 11px;");
                    setTooltip(new Tooltip(sha));
                }
            }
        });

        historyTable.getColumns().addAll(colId, colName, colDate, colResult, colExpectedSha, colActualSha);
        historyTable.setPlaceholder(new Label("No file integrity checks performed yet."));

        content.getChildren().addAll(headerRow, historyTable);
        return content;
    }

    private void refreshHistoryData() {
        Thread thread = new Thread(() -> {
            try {
                List<IntegrityCheck> list = integrityService.getAllHistory();
                int count = integrityService.getCheckCount();
                Platform.runLater(() -> {
                    historyTableData.setAll(list);
                    if (historyCountLabel != null) {
                        historyCountLabel.setText("Total Checks: " + count);
                    }
                });
            } catch (Exception ex) {
                System.err.println("[NETTECH] Failed to load integrity history: " + ex.getMessage());
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    // =========================================================================
    // 5. HELPER UTILITIES
    // =========================================================================

    private void copyToClipboard(String text, String descriptor) {
        if (text == null || text.isBlank()) {
            return;
        }
        ClipboardContent content = new ClipboardContent();
        content.putString(text.trim());
        Clipboard.getSystemClipboard().setContent(content);

        hashFeedbackLabel.setText("✓ " + descriptor + " copied to clipboard!");
        hashFeedbackLabel.getStyleClass().setAll("feedback-success");
    }

    private String formatFileSize(long bytes) {
        if (bytes <= 0) return "0 B";
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(bytes) / Math.log10(1024));
        digitGroups = Math.min(digitGroups, units.length - 1);
        return new DecimalFormat("#,##0.#").format(bytes / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }
}
