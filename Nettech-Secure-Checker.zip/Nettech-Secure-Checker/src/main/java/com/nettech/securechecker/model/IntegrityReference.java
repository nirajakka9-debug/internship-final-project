package com.nettech.securechecker.model;

/**
 * Represents a stored file-integrity reference — the known-good hashes
 * for a file that future integrity checks compare against.
 */
public class IntegrityReference {

    private int id;
    private String fileName;
    private String filePath;
    private long fileSize;
    private String md5;
    private String sha256;
    private String createdAt;
    private String updatedAt;

    /** Default constructor. */
    public IntegrityReference() {
    }

    /**
     * Full constructor (without id, for new records).
     */
    public IntegrityReference(String fileName, String filePath, long fileSize,
                              String md5, String sha256,
                              String createdAt, String updatedAt) {
        this.fileName  = fileName;
        this.filePath  = filePath;
        this.fileSize  = fileSize;
        this.md5       = md5;
        this.sha256    = sha256;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // ── Getters & Setters ──────────────────────────────────────

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getSha256() {
        return sha256;
    }

    public void setSha256(String sha256) {
        this.sha256 = sha256;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "IntegrityReference{" +
                "id=" + id +
                ", fileName='" + fileName + '\'' +
                ", filePath='" + filePath + '\'' +
                ", fileSize=" + fileSize +
                ", md5='" + md5 + '\'' +
                ", sha256='" + sha256 + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                '}';
    }
}
