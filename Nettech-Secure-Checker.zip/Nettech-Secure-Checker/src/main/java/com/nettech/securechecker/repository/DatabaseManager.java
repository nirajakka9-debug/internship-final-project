package com.nettech.securechecker.repository;

import com.nettech.securechecker.config.DatabaseConfig;
import com.nettech.securechecker.util.FileUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Collectors;

/**
 * Manages the SQLite database lifecycle — creation, schema initialisation,
 * and connection provisioning.
 * <p>
 * Uses the singleton pattern so that a single manager instance is shared
 * across the application.
 */
public class DatabaseManager {

    private static final DatabaseManager INSTANCE = new DatabaseManager();

    private String jdbcUrl;
    private boolean initialized = false;

    private DatabaseManager() {
        this.jdbcUrl = DatabaseConfig.getJdbcUrl();
    }

    /** Returns the singleton instance. */
    public static DatabaseManager getInstance() {
        return INSTANCE;
    }

    // ── Initialisation ─────────────────────────────────────────

    /**
     * Initialises the database: creates the data directory if needed,
     * then runs the schema SQL to ensure all tables exist.
     */
    public synchronized void initialize() {
        if (initialized) {
            return;
        }
        try {
            // Ensure the data directory exists
            FileUtils.ensureDirectoryExists(DatabaseConfig.getDatabaseDirectory());

            // Load and execute the schema
            String schema = loadSchema();
            try (Connection conn = getConnection();
                 Statement stmt = conn.createStatement()) {
                // Enable foreign keys for SQLite
                stmt.execute("PRAGMA foreign_keys = ON;");
                // Execute each statement in the schema
                for (String sql : schema.split(";")) {
                    String trimmed = sql.trim();
                    if (!trimmed.isEmpty()) {
                        stmt.execute(trimmed);
                    }
                }
            }
            initialized = true;
            System.out.println("[NETTECH] Database initialised successfully.");
        } catch (SQLException | IOException e) {
            System.err.println("[NETTECH] Database initialisation failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Initialises the database using a custom JDBC URL.
     * Primarily used for testing with in-memory databases.
     *
     * @param customJdbcUrl the JDBC URL to use
     */
    public synchronized void initialize(String customJdbcUrl) {
        this.jdbcUrl = customJdbcUrl;
        this.initialized = false;
        initialize();
    }

    // ── Connection ─────────────────────────────────────────────

    /**
     * Returns a new database connection. Callers are responsible for
     * closing the connection (use try-with-resources).
     *
     * @return a JDBC connection
     * @throws SQLException if a connection cannot be established
     */
    public Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(jdbcUrl);
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON;");
        }
        return conn;
    }

    // ── Lifecycle ──────────────────────────────────────────────

    /**
     * Shuts down the database manager. Called when the application exits.
     */
    public void shutdown() {
        System.out.println("[NETTECH] Database manager shut down.");
    }

    /**
     * Returns whether the database has been initialised.
     */
    public boolean isInitialized() {
        return initialized;
    }

    // ── Internal ───────────────────────────────────────────────

    /**
     * Loads the SQL schema from the classpath resource.
     */
    private String loadSchema() throws IOException {
        String schemaPath = DatabaseConfig.getSchemaPath();
        try (InputStream is = getClass().getResourceAsStream(schemaPath)) {
            if (is == null) {
                throw new IOException("Schema resource not found: " + schemaPath);
            }
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is, StandardCharsets.UTF_8))) {
                return reader.lines()
                        .filter(line -> !line.trim().startsWith("--"))
                        .collect(Collectors.joining("\n"));
            }
        }
    }
}
