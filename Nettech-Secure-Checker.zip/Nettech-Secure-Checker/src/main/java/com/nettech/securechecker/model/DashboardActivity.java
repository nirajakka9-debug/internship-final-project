package com.nettech.securechecker.model;

import java.util.Objects;

/**
 * Domain model representing a unified security activity event for the Dashboard.
 * <p>
 * Combines password generation metadata, file baseline registration,
 * file integrity verification checks, and security report exports
 * into a single unified stream for chronological display.
 * <p>
 * <b>SECURITY INVARIANT:</b> Sensitive plaintext passwords, raw file content,
 * or secret keys are NEVER held in this model.
 */
public class DashboardActivity implements Comparable<DashboardActivity> {

    public enum ActivityType {
        PASSWORD_GENERATION,
        FILE_INTEGRITY_CHECK,
        FILE_BASELINE_SAVED,
        REPORT_EXPORT
    }

    private final ActivityType type;
    private final String title;
    private final String description;
    private final String timestamp;
    private final String statusBadge;
    private final String statusClass;

    public DashboardActivity(ActivityType type, String title, String description,
                             String timestamp, String statusBadge, String statusClass) {
        this.type = type != null ? type : ActivityType.PASSWORD_GENERATION;
        this.title = title != null ? title : "";
        this.description = description != null ? description : "";
        this.timestamp = timestamp != null ? timestamp : "";
        this.statusBadge = statusBadge != null ? statusBadge : "";
        this.statusClass = statusClass != null ? statusClass : "";
    }

    public ActivityType getType() {
        return type;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getStatusBadge() {
        return statusBadge;
    }

    public String getStatusClass() {
        return statusClass;
    }

    @Override
    public int compareTo(DashboardActivity other) {
        if (other == null) {
            return -1;
        }
        // Primary sort: descending by timestamp (most recent first)
        int cmp = Objects.compare(other.timestamp, this.timestamp, String::compareTo);
        if (cmp != 0) {
            return cmp;
        }
        // Secondary sort: title
        return Objects.compare(this.title, other.title, String::compareTo);
    }

    @Override
    public String toString() {
        return "DashboardActivity{" +
                "type=" + type +
                ", title='" + title + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", statusBadge='" + statusBadge + '\'' +
                '}';
    }
}
