package com.nettech.securechecker.controller;

import com.nettech.securechecker.app.NettechApplication;
import com.nettech.securechecker.service.SettingsService;
import com.nettech.securechecker.util.Constants;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;

import java.awt.Desktop;
import java.io.File;
import java.util.Optional;

/**
 * Controller for the Settings & Configuration screen.
 * <p>
 * Manages:
 * <ul>
 *   <li>Appearance & Theme switching (Dark/Light mode)</li>
 *   <li>Configurable Default Reports Directory</li>
 *   <li>Safe Audit History Clearing (with confirmation safeguards)</li>
 *   <li>Local Storage Paths inspection (Database, Reports, Settings)</li>
 *   <li>Application About and Security Invariant specifications</li>
 * </ul>
 */
public class SettingsController {

    private final NettechApplication app;
    private final SettingsService settingsService;

    private RadioButton rbDarkTheme;
    private RadioButton rbLightTheme;
    private TextField reportsDirField;
    private Label settingsFeedbackLabel;

    public SettingsController() {
        this(null, new SettingsService());
    }

    public SettingsController(NettechApplication app, SettingsService settingsService) {
        this.app = app;
        this.settingsService = settingsService != null ? settingsService : new SettingsService();
    }

    /**
     * Builds and returns the complete Settings view.
     */
    public Region getView() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(0));

        // ── Header ──
        Label titleLabel = new Label("Application Settings");
        titleLabel.getStyleClass().add("page-title");

        Label descLabel = new Label(
                "Configure visual appearance, storage locations, audit retention, and inspect system telemetry.");
        descLabel.getStyleClass().add("page-subtitle");

        // ── Feedback Label ──
        settingsFeedbackLabel = new Label();
        settingsFeedbackLabel.setStyle("-fx-font-size: 12.5px;");
        settingsFeedbackLabel.setWrapText(true);

        // ── 1. Appearance / Theme Section ──
        VBox themeSection = buildThemeSection();

        // ── 2. Storage & File Locations Section ──
        VBox storageSection = buildStorageSection();

        // ── 3. Safe Data Maintenance Section ──
        VBox maintenanceSection = buildMaintenanceSection();

        // ── 4. About Section ──
        VBox aboutSection = buildAboutSection();

        root.getChildren().addAll(titleLabel, descLabel, settingsFeedbackLabel,
                themeSection, storageSection, maintenanceSection, aboutSection);
        return root;
    }

    // =========================================================================
    // 1. THEME SECTION
    // =========================================================================

    private VBox buildThemeSection() {
        VBox card = new VBox(12);
        card.getStyleClass().add("settings-group");

        Label title = new Label("🎨  Appearance & Theme");
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-font-size: 14px; -fx-padding: 0;");

        Label desc = new Label("Choose the visual theme for the desktop interface. Settings are saved locally and persist across launches.");
        desc.getStyleClass().add("settings-desc");
        desc.setWrapText(true);

        HBox optionsRow = new HBox(20);
        optionsRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup themeGroup = new ToggleGroup();

        rbDarkTheme = new RadioButton("Dark Theme (Cybersecurity Palette — Recommended)");
        rbDarkTheme.setToggleGroup(themeGroup);
        rbDarkTheme.setStyle("-fx-text-fill: -nt-text-primary; -fx-font-size: 13px;");

        rbLightTheme = new RadioButton("Light Theme (High Visibility)");
        rbLightTheme.setToggleGroup(themeGroup);
        rbLightTheme.setStyle("-fx-text-fill: -nt-text-primary; -fx-font-size: 13px;");

        if (settingsService.isDarkTheme()) {
            rbDarkTheme.setSelected(true);
        } else {
            rbLightTheme.setSelected(true);
        }

        rbDarkTheme.setOnAction(e -> applyThemeChange(Constants.THEME_DARK));
        rbLightTheme.setOnAction(e -> applyThemeChange(Constants.THEME_LIGHT));

        optionsRow.getChildren().addAll(rbDarkTheme, rbLightTheme);
        card.getChildren().addAll(title, desc, optionsRow);
        return card;
    }

    private void applyThemeChange(String theme) {
        settingsService.setTheme(theme);
        if (app != null) {
            app.applyTheme(theme);
        }
        showFeedback("✓ Theme set to " + (Constants.THEME_DARK.equals(theme) ? "Dark" : "Light") + " Mode.", true);
    }

    // =========================================================================
    // 2. STORAGE & REPORT LOCATIONS SECTION
    // =========================================================================

    private VBox buildStorageSection() {
        VBox card = new VBox(14);
        card.getStyleClass().add("settings-group");

        Label title = new Label("📁  Storage & Export Locations");
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-font-size: 14px; -fx-padding: 0;");

        // ── Default Reports Output Directory ──
        VBox dirBox = new VBox(6);
        Label dirLabel = new Label("Default Report Output Directory:");
        dirLabel.getStyleClass().add("settings-label");

        HBox dirRow = new HBox(8);
        dirRow.setAlignment(Pos.CENTER_LEFT);

        reportsDirField = new TextField(settingsService.getReportsDirectory());
        reportsDirField.getStyleClass().add("text-field");
        HBox.setHgrow(reportsDirField, Priority.ALWAYS);

        Button btnBrowse = new Button("📁  Browse...");
        btnBrowse.getStyleClass().add("action-button");
        btnBrowse.setOnAction(e -> handleBrowseReportsDir());

        Button btnSaveDir = new Button("💾  Save Directory");
        btnSaveDir.getStyleClass().add("action-button-primary");
        btnSaveDir.setOnAction(e -> handleSaveReportsDir());

        dirRow.getChildren().addAll(reportsDirField, btnBrowse, btnSaveDir);
        dirBox.getChildren().addAll(dirLabel, dirRow);

        // ── Local Storage Paths Info Grid ──
        VBox pathsGrid = new VBox(8);
        pathsGrid.setStyle("-fx-background-color: -nt-bg-input; -fx-padding: 12; -fx-background-radius: 6; -fx-border-color: -nt-border; -fx-border-radius: 6;");

        pathsGrid.getChildren().addAll(
                buildPathDisplayRow("SQLite Database:", settingsService.getDatabaseLocation(), true),
                buildPathDisplayRow("Reports Export Dir:", settingsService.getReportsLocation(), true),
                buildPathDisplayRow("Local Preferences:", settingsService.getSettingsLocation(), false)
        );

        card.getChildren().addAll(title, dirBox, pathsGrid);
        return card;
    }

    private HBox buildPathDisplayRow(String labelText, String pathText, boolean allowOpen) {
        HBox row = new HBox(8);
        row.setAlignment(Pos.CENTER_LEFT);

        Label lbl = new Label(labelText);
        lbl.setStyle("-fx-font-weight: bold; -fx-font-size: 12px; -fx-text-fill: -nt-text-primary; -fx-min-width: 140;");

        Label pathLbl = new Label(pathText);
        pathLbl.setStyle("-fx-font-family: Consolas, monospace; -fx-font-size: 11.5px; -fx-text-fill: -nt-text-secondary;");
        HBox.setHgrow(pathLbl, Priority.ALWAYS);

        Button btnCopy = new Button("📋 Copy");
        btnCopy.getStyleClass().add("action-button");
        btnCopy.setStyle("-fx-font-size: 11px; -fx-padding: 3 8;");
        btnCopy.setOnAction(e -> copyToClipboard(pathText, labelText));

        row.getChildren().addAll(lbl, pathLbl, btnCopy);

        if (allowOpen) {
            Button btnOpen = new Button("📂 Open");
            btnOpen.getStyleClass().add("action-button");
            btnOpen.setStyle("-fx-font-size: 11px; -fx-padding: 3 8;");
            btnOpen.setOnAction(e -> openFolder(pathText));
            row.getChildren().add(btnOpen);
        }

        return row;
    }

    private void handleBrowseReportsDir() {
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Select Default Reports Output Directory");
        File initial = new File(settingsService.getReportsDirectory());
        if (initial.exists() && initial.isDirectory()) {
            chooser.setInitialDirectory(initial);
        }
        File selected = chooser.showDialog(null);
        if (selected != null) {
            reportsDirField.setText(selected.getAbsolutePath());
        }
    }

    private void handleSaveReportsDir() {
        String input = reportsDirField.getText();
        boolean ok = settingsService.setReportsDirectory(input);
        if (ok) {
            showFeedback("✓ Default reports directory updated to: " + settingsService.getReportsDirectory(), true);
        } else {
            showFeedback("⚠ Failed to set directory. Path must be a valid, writable directory.", false);
        }
    }

    // =========================================================================
    // 3. SAFE DATA MAINTENANCE SECTION
    // =========================================================================

    private VBox buildMaintenanceSection() {
        VBox card = new VBox(12);
        card.getStyleClass().add("settings-group");

        Label title = new Label("🧹  Audit History & Data Retention");
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-font-size: 14px; -fx-padding: 0;");

        Label desc = new Label("Safely clear audit logs. Baseline references and exported PDF reports are protected and will NOT be deleted.");
        desc.getStyleClass().add("settings-desc");
        desc.setWrapText(true);

        HBox actionsRow = new HBox(16);
        actionsRow.setAlignment(Pos.CENTER_LEFT);

        Button btnClearPasswordHistory = new Button("🗑  Clear Password History Log");
        btnClearPasswordHistory.getStyleClass().add("action-button");
        btnClearPasswordHistory.setOnAction(e -> handleClearPasswordHistory());

        Button btnClearIntegrityHistory = new Button("🗑  Clear Integrity Check Log");
        btnClearIntegrityHistory.getStyleClass().add("action-button");
        btnClearIntegrityHistory.setOnAction(e -> handleClearIntegrityHistory());

        actionsRow.getChildren().addAll(btnClearPasswordHistory, btnClearIntegrityHistory);

        Label notice = new Label("Note: 'Clear Password History' purges metadata logs. 'Clear Integrity Check Log' purges past verification events while preserving your saved baseline hashes.");
        notice.setStyle("-fx-font-size: 11.5px; -fx-text-fill: -nt-text-muted; -fx-font-style: italic;");
        notice.setWrapText(true);

        card.getChildren().addAll(title, desc, actionsRow, notice);
        return card;
    }

    private void handleClearPasswordHistory() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Clear Password History");
        confirm.setHeaderText("Purge Password Generation Metadata?");
        confirm.setContentText("This will permanently clear all zero-knowledge password metadata history from the database.\n\nFile baselines, check history, and PDF reports will remain intact. Continue?");

        Optional<ButtonType> opt = confirm.showAndWait();
        if (opt.isPresent() && opt.get() == ButtonType.OK) {
            boolean success = settingsService.clearPasswordHistory();
            if (success) {
                showFeedback("✓ Password generation metadata history cleared successfully.", true);
            } else {
                showFeedback("⚠ Failed to clear password history.", false);
            }
        }
    }

    private void handleClearIntegrityHistory() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Clear Integrity Check History");
        confirm.setHeaderText("Purge Integrity Verification Audit Logs?");
        confirm.setContentText("This will delete past verification attempt logs.\n\nIMPORTANT: Saved baseline file references and exported PDF reports will NOT be deleted. Continue?");

        Optional<ButtonType> opt = confirm.showAndWait();
        if (opt.isPresent() && opt.get() == ButtonType.OK) {
            boolean success = settingsService.clearIntegrityHistory();
            if (success) {
                showFeedback("✓ Integrity verification audit history cleared successfully.", true);
            } else {
                showFeedback("⚠ Failed to clear integrity history.", false);
            }
        }
    }

    // =========================================================================
    // 4. ABOUT SECTION
    // =========================================================================

    private VBox buildAboutSection() {
        VBox card = new VBox(12);
        card.getStyleClass().add("settings-group");

        Label title = new Label("ℹ️  About " + Constants.APP_SHORT_NAME);
        title.getStyleClass().add("section-heading");
        title.setStyle("-fx-font-size: 14px; -fx-padding: 0;");

        VBox infoBox = new VBox(6);
        infoBox.setStyle("-fx-background-color: -nt-bg-input; -fx-padding: 14; -fx-background-radius: 6; -fx-border-color: -nt-border; -fx-border-radius: 6;");

        Label appName = new Label(Constants.APP_TITLE + "  (v" + Constants.APP_VERSION + ")");
        appName.setStyle("-fx-font-weight: bold; -fx-font-size: 13.5px; -fx-text-fill: -nt-accent;");

        Label techStack = new Label("Technology Stack: Java 21 (LTS)  •  OpenJFX 21  •  SQLite 3 (JDBC)  •  OpenPDF 1.3.40  •  Maven");
        techStack.setStyle("-fx-font-size: 12px; -fx-text-fill: -nt-text-primary;");

        Label privacyNotice = new Label(
                "🛡️ Privacy Guarantee: 100% offline workstation security utility. Zero network telemetry, zero cloud dependencies, and zero plaintext password retention.");
        privacyNotice.setStyle("-fx-font-size: 11.5px; -fx-text-fill: -nt-text-secondary;");
        privacyNotice.setWrapText(true);

        infoBox.getChildren().addAll(appName, techStack, privacyNotice);
        card.getChildren().addAll(title, infoBox);
        return card;
    }

    // =========================================================================
    // 5. HELPER ACTIONS
    // =========================================================================

    private void copyToClipboard(String text, String descriptor) {
        ClipboardContent content = new ClipboardContent();
        content.putString(text);
        Clipboard.getSystemClipboard().setContent(content);
        showFeedback("✓ " + descriptor + " copied to clipboard!", true);
    }

    private void openFolder(String pathStr) {
        try {
            File file = new File(pathStr);
            File dir = file.isDirectory() ? file : file.getParentFile();
            if (dir != null && dir.exists()) {
                if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                    Desktop.getDesktop().open(dir);
                    showFeedback("✓ Opened folder: " + dir.getAbsolutePath(), true);
                    return;
                }
            }
            showFeedback("Directory location: " + pathStr, true);
        } catch (Exception e) {
            showFeedback("Unable to open folder: " + e.getMessage(), false);
        }
    }

    private void showFeedback(String message, boolean success) {
        if (settingsFeedbackLabel != null) {
            settingsFeedbackLabel.setText(message);
            if (success) {
                settingsFeedbackLabel.getStyleClass().setAll("feedback-success");
            } else {
                settingsFeedbackLabel.getStyleClass().setAll("feedback-error");
            }
        }
    }
}
