package com.nettech.securechecker.model;

/**
 * Represents metadata about a generated password.
 * <p>
 * SECURITY: This class intentionally does NOT store the actual password.
 * Only metadata (length, strength, score, timestamp) is persisted.
 */
public class PasswordHistory {

    private int id;
    private String generatedAt;
    private int length;
    private String strength;
    private Integer score;

    /** Default constructor. */
    public PasswordHistory() {
    }

    /**
     * Full constructor (without id, for new records).
     */
    public PasswordHistory(String generatedAt, int length, String strength, Integer score) {
        this.generatedAt = generatedAt;
        this.length = length;
        this.strength = strength;
        this.score = score;
    }

    // ── Getters & Setters ──────────────────────────────────────

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGeneratedAt() {
        return generatedAt;
    }

    public void setGeneratedAt(String generatedAt) {
        this.generatedAt = generatedAt;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getStrength() {
        return strength;
    }

    public void setStrength(String strength) {
        this.strength = strength;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "PasswordHistory{" +
                "id=" + id +
                ", generatedAt='" + generatedAt + '\'' +
                ", length=" + length +
                ", strength='" + strength + '\'' +
                ", score=" + score +
                '}';
    }
}
