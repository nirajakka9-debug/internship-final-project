package com.nettech.securechecker.service;

import com.nettech.securechecker.model.DashboardActivity;
import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.model.SecurityReport;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.repository.ReportRepository;
import com.nettech.securechecker.util.Constants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Service providing aggregated activity metrics and unified chronological
 * event stream for the NETTECH Security Center Dashboard.
 * <p>
 * <b>SECURITY INVARIANT:</b> Strictly read-only operations. Never stores,
 * logs, or exposes plaintext passwords, secret keys, or raw file content.
 */
public class DashboardService {

    private final PasswordHistoryRepository passwordRepo;
    private final IntegrityReferenceRepository referenceRepo;
    private final IntegrityHistoryRepository historyRepo;
    private final ReportRepository reportRepo;

    public DashboardService() {
        DatabaseManager dbManager = DatabaseManager.getInstance();
        this.passwordRepo  = new PasswordHistoryRepository(dbManager);
        this.referenceRepo = new IntegrityReferenceRepository(dbManager);
        this.historyRepo   = new IntegrityHistoryRepository(dbManager);
        this.reportRepo    = new ReportRepository(dbManager);
    }

    public DashboardService(PasswordHistoryRepository passwordRepo,
                            IntegrityReferenceRepository referenceRepo,
                            IntegrityHistoryRepository historyRepo,
                            ReportRepository reportRepo) {
        this.passwordRepo  = passwordRepo != null ? passwordRepo : new PasswordHistoryRepository();
        this.referenceRepo = referenceRepo != null ? referenceRepo : new IntegrityReferenceRepository();
        this.historyRepo   = historyRepo != null ? historyRepo : new IntegrityHistoryRepository();
        this.reportRepo    = reportRepo != null ? reportRepo : new ReportRepository();
    }

    // =========================================================================
    // 1. STAT METRICS AGGREGATION
    // =========================================================================

    /**
     * Returns total count of password generation / strength analysis activities.
     */
    public int getPasswordActivityCount() {
        return passwordRepo.count();
    }

    /**
     * Returns total count of file activities (baseline references saved + integrity checks performed).
     */
    public int getFilesCheckedCount() {
        return referenceRepo.count() + historyRepo.count();
    }

    /**
     * Returns total count of saved security audit reports.
     */
    public int getReportsCount() {
        return reportRepo.count();
    }

    /**
     * Formats the Password Security stat card string.
     */
    public String getPasswordSecurityStatText() {
        int count = getPasswordActivityCount();
        if (count == 0) {
            return "No activity yet";
        }
        return count == 1 ? "1 password recorded" : count + " passwords recorded";
    }

    /**
     * Formats the Files Checked stat card string.
     */
    public String getFilesCheckedStatText() {
        int count = getFilesCheckedCount();
        if (count == 0) {
            return "No activity yet";
        }
        return count == 1 ? "1 file checked" : count + " files checked";
    }

    /**
     * Formats the Reports stat card string.
     */
    public String getReportsStatText() {
        int count = getReportsCount();
        if (count == 0) {
            return "No reports yet";
        }
        return count == 1 ? "1 report saved" : count + " reports saved";
    }

    // =========================================================================
    // 2. RECENT ACTIVITY STREAM (CHRONOLOGICAL MERGE)
    // =========================================================================

    /**
     * Merges recent activities across password generation, baseline references,
     * integrity verification checks, and security reports into a chronological stream.
     *
     * @param limit maximum number of activity records to return
     * @return chronological list of recent activities, newest first
     */
    public List<DashboardActivity> getRecentActivities(int limit) {
        int max = Math.max(1, limit);
        List<DashboardActivity> activities = new ArrayList<>();

        // 1. Password generation events
        List<PasswordHistory> passwordHistories = passwordRepo.findAll();
        for (PasswordHistory ph : passwordHistories) {
            String strength = ph.getStrength() != null ? ph.getStrength() : "Standard";
            String title = "Password Generated";
            String desc = String.format("%d characters (%s, Score: %s)",
                    ph.getLength(),
                    strength,
                    ph.getScore() != null ? ph.getScore() + "/100" : "—");

            String badgeClass;
            if (strength.contains("Strong")) {
                badgeClass = "status-secure";
            } else if (strength.contains("Moderate") || strength.contains("Weak")) {
                badgeClass = "status-warning";
            } else {
                badgeClass = "status-danger";
            }

            activities.add(new DashboardActivity(
                    DashboardActivity.ActivityType.PASSWORD_GENERATION,
                    title,
                    desc,
                    ph.getGeneratedAt(),
                    strength,
                    badgeClass
            ));
        }

        // 2. File integrity checks
        List<IntegrityCheck> checks = historyRepo.findAll();
        for (IntegrityCheck check : checks) {
            String title = "Integrity Check: " + check.getFileName();
            String desc = "Result: " + check.getResult();
            String badge = check.getResult() != null ? check.getResult() : "Check";

            String badgeClass;
            if (Constants.INTEGRITY_VERIFIED.equalsIgnoreCase(check.getResult())) {
                badgeClass = "status-secure";
            } else if (Constants.INTEGRITY_MODIFIED.equalsIgnoreCase(check.getResult())) {
                badgeClass = "status-danger";
            } else {
                badgeClass = "status-warning";
            }

            activities.add(new DashboardActivity(
                    DashboardActivity.ActivityType.FILE_INTEGRITY_CHECK,
                    title,
                    desc,
                    check.getCheckedAt(),
                    badge,
                    badgeClass
            ));
        }

        // 3. Saved baseline references
        List<IntegrityReference> references = referenceRepo.findAll();
        for (IntegrityReference ref : references) {
            String title = "Baseline Registered: " + ref.getFileName();
            String desc = "SHA-256: " + truncateHash(ref.getSha256());
            String time = ref.getUpdatedAt() != null && !ref.getUpdatedAt().isBlank()
                    ? ref.getUpdatedAt() : ref.getCreatedAt();

            activities.add(new DashboardActivity(
                    DashboardActivity.ActivityType.FILE_BASELINE_SAVED,
                    title,
                    desc,
                    time,
                    "Baseline",
                    "status-secure"
            ));
        }

        // 4. Exported security reports
        List<SecurityReport> reports = reportRepo.findAll();
        for (SecurityReport report : reports) {
            String title = "Report Exported: " + formatReportType(report.getReportType());
            String desc = report.getFileName() != null ? report.getFileName() : "Security Audit Report";

            activities.add(new DashboardActivity(
                    DashboardActivity.ActivityType.REPORT_EXPORT,
                    title,
                    desc,
                    report.getGeneratedAt(),
                    "Report",
                    "status-secure"
            ));
        }

        // Sort descending by timestamp (handled by DashboardActivity.compareTo)
        Collections.sort(activities);

        return activities.stream().limit(max).toList();
    }

    private String truncateHash(String hash) {
        if (hash == null || hash.length() <= 16) {
            return hash != null ? hash : "";
        }
        return hash.substring(0, 8) + "..." + hash.substring(hash.length() - 8);
    }

    private String formatReportType(String type) {
        if (type == null) return "Security Audit";
        if (type.contains("PASSWORD")) return "Password Security Audit";
        if (type.contains("INTEGRITY")) return "File Integrity Audit";
        if (type.contains("COMBINED")) return "Comprehensive Security Audit";
        return type;
    }
}
