package com.nettech.securechecker.repository;

import com.nettech.securechecker.model.IntegrityReference;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Repository for {@link IntegrityReference} CRUD operations.
 * <p>
 * Manages trusted file reference hashes using secure parameterized SQL queries.
 */
public class IntegrityReferenceRepository {

    private final DatabaseManager databaseManager;

    public IntegrityReferenceRepository() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    public IntegrityReferenceRepository(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    /**
     * Inserts a new integrity reference or updates if duplicate path exists.
     *
     * @param reference the reference to insert
     * @return the generated ID, or -1 on failure
     */
    public int insert(IntegrityReference reference) {
        if (reference == null) {
            return -1;
        }

        String sql = "INSERT INTO integrity_references (file_name, file_path, file_size, md5, sha256, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, reference.getFileName());
            stmt.setString(2, reference.getFilePath());
            stmt.setLong(3, reference.getFileSize());
            stmt.setString(4, reference.getMd5());
            stmt.setString(5, reference.getSha256());
            stmt.setString(6, reference.getCreatedAt());
            stmt.setString(7, reference.getUpdatedAt());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        reference.setId(generatedId);
                        return generatedId;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to insert integrity reference: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Retrieves all integrity references ordered by creation date descending.
     *
     * @return list of references
     */
    public List<IntegrityReference> findAll() {
        List<IntegrityReference> list = new ArrayList<>();
        String sql = "SELECT id, file_name, file_path, file_size, md5, sha256, created_at, updated_at " +
                     "FROM integrity_references ORDER BY id DESC";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch integrity references: " + e.getMessage());
        }
        return list;
    }

    /**
     * Finds a reference by its ID.
     *
     * @param id the reference ID
     * @return an Optional containing the reference, or empty if not found
     */
    public Optional<IntegrityReference> findById(int id) {
        String sql = "SELECT id, file_name, file_path, file_size, md5, sha256, created_at, updated_at " +
                     "FROM integrity_references WHERE id = ?";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch integrity reference by ID: " + e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Finds a reference by its canonical file path.
     *
     * @param filePath the file path to search for
     * @return an Optional containing the reference, or empty if not found
     */
    public Optional<IntegrityReference> findByFilePath(String filePath) {
        if (filePath == null || filePath.isBlank()) {
            return Optional.empty();
        }

        String sql = "SELECT id, file_name, file_path, file_size, md5, sha256, created_at, updated_at " +
                     "FROM integrity_references WHERE file_path = ? ORDER BY id DESC LIMIT 1";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, filePath);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to fetch integrity reference by path: " + e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Updates an existing integrity reference.
     *
     * @param reference the reference with updated values
     * @return true if the update succeeded
     */
    public boolean update(IntegrityReference reference) {
        if (reference == null || reference.getId() <= 0) {
            return false;
        }

        String sql = "UPDATE integrity_references SET file_name = ?, file_path = ?, file_size = ?, " +
                     "md5 = ?, sha256 = ?, updated_at = ? WHERE id = ?";

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, reference.getFileName());
            stmt.setString(2, reference.getFilePath());
            stmt.setLong(3, reference.getFileSize());
            stmt.setString(4, reference.getMd5());
            stmt.setString(5, reference.getSha256());
            stmt.setString(6, reference.getUpdatedAt());
            stmt.setInt(7, reference.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to update integrity reference: " + e.getMessage());
        }
        return false;
    }

    /**
     * Deletes an integrity reference by its ID.
     *
     * @param id the reference ID
     * @return true if a record was deleted
     */
    public boolean deleteById(int id) {
        String dissociateSql = "UPDATE integrity_history SET reference_id = NULL WHERE reference_id = ?";
        String deleteSql = "DELETE FROM integrity_references WHERE id = ?";
        try (Connection conn = databaseManager.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement disStmt = conn.prepareStatement(dissociateSql);
                 PreparedStatement delStmt = conn.prepareStatement(deleteSql)) {

                disStmt.setInt(1, id);
                disStmt.executeUpdate();

                delStmt.setInt(1, id);
                int affectedRows = delStmt.executeUpdate();

                conn.commit();
                return affectedRows > 0;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to delete integrity reference: " + e.getMessage());
        }
        return false;
    }

    /**
     * Returns the total count of stored integrity references.
     *
     * @return the count
     */
    public int count() {
        String sql = "SELECT COUNT(*) FROM integrity_references";
        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[NETTECH] Failed to count integrity references: " + e.getMessage());
        }
        return 0;
    }

    private IntegrityReference mapRow(ResultSet rs) throws SQLException {
        IntegrityReference ref = new IntegrityReference();
        ref.setId(rs.getInt("id"));
        ref.setFileName(rs.getString("file_name"));
        ref.setFilePath(rs.getString("file_path"));
        ref.setFileSize(rs.getLong("file_size"));
        ref.setMd5(rs.getString("md5"));
        ref.setSha256(rs.getString("sha256"));
        ref.setCreatedAt(rs.getString("created_at"));
        ref.setUpdatedAt(rs.getString("updated_at"));
        return ref;
    }
}
