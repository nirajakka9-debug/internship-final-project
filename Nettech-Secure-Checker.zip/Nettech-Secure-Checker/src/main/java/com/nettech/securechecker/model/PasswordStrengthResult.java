package com.nettech.securechecker.model;

import java.util.Collections;
import java.util.List;

/**
 * Encapsulates the results of a password strength analysis.
 * <p>
 * <b>SECURITY NOTE:</b> This model intentionally does NOT store the analyzed
 * plaintext password or its hash, adhering strictly to zero-knowledge password handling.
 */
public class PasswordStrengthResult {

    private final int score;
    private final String strengthLabel;
    private final int length;
    private final boolean hasLowercase;
    private final boolean hasUppercase;
    private final boolean hasDigits;
    private final boolean hasSpecialCharacters;
    private final boolean repeatedCharacterDetected;
    private final boolean sequentialPatternDetected;
    private final boolean commonPatternDetected;
    private final List<String> recommendations;

    public PasswordStrengthResult(int score, String strengthLabel, int length,
                                  boolean hasLowercase, boolean hasUppercase,
                                  boolean hasDigits, boolean hasSpecialCharacters,
                                  boolean repeatedCharacterDetected,
                                  boolean sequentialPatternDetected,
                                  boolean commonPatternDetected,
                                  List<String> recommendations) {
        this.score = score;
        this.strengthLabel = strengthLabel;
        this.length = length;
        this.hasLowercase = hasLowercase;
        this.hasUppercase = hasUppercase;
        this.hasDigits = hasDigits;
        this.hasSpecialCharacters = hasSpecialCharacters;
        this.repeatedCharacterDetected = repeatedCharacterDetected;
        this.sequentialPatternDetected = sequentialPatternDetected;
        this.commonPatternDetected = commonPatternDetected;
        this.recommendations = recommendations != null
                ? Collections.unmodifiableList(recommendations)
                : Collections.emptyList();
    }

    public int getScore() {
        return score;
    }

    public String getStrengthLabel() {
        return strengthLabel;
    }

    public int getLength() {
        return length;
    }

    public boolean hasLowercase() {
        return hasLowercase;
    }

    public boolean hasUppercase() {
        return hasUppercase;
    }

    public boolean hasDigits() {
        return hasDigits;
    }

    public boolean hasSpecialCharacters() {
        return hasSpecialCharacters;
    }

    public boolean isRepeatedCharacterDetected() {
        return repeatedCharacterDetected;
    }

    public boolean isSequentialPatternDetected() {
        return sequentialPatternDetected;
    }

    public boolean isCommonPatternDetected() {
        return commonPatternDetected;
    }

    public List<String> getRecommendations() {
        return recommendations;
    }

    @Override
    public String toString() {
        return "PasswordStrengthResult{" +
                "score=" + score +
                ", strengthLabel='" + strengthLabel + '\'' +
                ", length=" + length +
                ", hasLowercase=" + hasLowercase +
                ", hasUppercase=" + hasUppercase +
                ", hasDigits=" + hasDigits +
                ", hasSpecialCharacters=" + hasSpecialCharacters +
                ", repeatedCharacterDetected=" + repeatedCharacterDetected +
                ", sequentialPatternDetected=" + sequentialPatternDetected +
                ", commonPatternDetected=" + commonPatternDetected +
                ", recommendationsCount=" + recommendations.size() +
                '}';
    }
}
