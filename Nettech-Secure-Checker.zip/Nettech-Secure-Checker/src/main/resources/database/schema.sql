-- ============================================================
-- NETTECH Secure Password & File Integrity Checker
-- Database Schema - Version 1.0
-- ============================================================
-- This schema defines the core tables for storing password
-- generation metadata, file integrity references, integrity
-- check history, and security reports.
--
-- SECURITY NOTE: Plaintext passwords are NEVER stored.
-- Only metadata (length, strength, score, timestamp) is recorded.
-- ============================================================

-- Password generation metadata history
-- Stores information ABOUT generated passwords, never the passwords themselves.
CREATE TABLE IF NOT EXISTS password_history (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    generated_at TEXT    NOT NULL,
    length       INTEGER NOT NULL,
    strength     TEXT    NOT NULL,
    score        INTEGER
);

-- File integrity reference hashes
-- Stores known-good hash values for files to compare against later.
CREATE TABLE IF NOT EXISTS integrity_references (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    file_name  TEXT    NOT NULL,
    file_path  TEXT    NOT NULL,
    file_size  INTEGER NOT NULL,
    md5        TEXT    NOT NULL,
    sha256     TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    updated_at TEXT    NOT NULL
);

-- File integrity check history
-- Records the results of each integrity verification performed.
CREATE TABLE IF NOT EXISTS integrity_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    reference_id    INTEGER,
    file_name       TEXT NOT NULL,
    checked_at      TEXT NOT NULL,
    expected_md5    TEXT,
    actual_md5      TEXT,
    expected_sha256 TEXT,
    actual_sha256   TEXT,
    result          TEXT NOT NULL,
    FOREIGN KEY (reference_id) REFERENCES integrity_references(id)
);

-- Security reports metadata
-- Tracks generated reports and their output locations.
CREATE TABLE IF NOT EXISTS reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    report_type  TEXT NOT NULL,
    file_name    TEXT,
    generated_at TEXT NOT NULL,
    output_path  TEXT
);
