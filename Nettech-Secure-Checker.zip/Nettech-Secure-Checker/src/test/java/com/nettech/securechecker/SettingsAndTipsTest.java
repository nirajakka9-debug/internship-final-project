package com.nettech.securechecker;

import com.nettech.securechecker.controller.TipsController;
import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.service.SettingsService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Automated test suite for Phase 6: Security Tips and Settings.
 */
public class SettingsAndTipsTest {

    @TempDir
    static Path dbTempDir;

    private static DatabaseManager dbManager;
    private static PasswordHistoryRepository passwordRepo;
    private static IntegrityReferenceRepository referenceRepo;
    private static IntegrityHistoryRepository historyRepo;

    @BeforeAll
    static void initDatabase() {
        dbManager = DatabaseManager.getInstance();
        String testDb = dbTempDir.resolve("test_settings.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);

        passwordRepo  = new PasswordHistoryRepository(dbManager);
        referenceRepo = new IntegrityReferenceRepository(dbManager);
        historyRepo   = new IntegrityHistoryRepository(dbManager);
    }

    @BeforeEach
    public void setUp() {
        passwordRepo.deleteAll();
        historyRepo.deleteAll();
        referenceRepo.findAll().forEach(r -> referenceRepo.deleteById(r.getId()));
    }

    @AfterEach
    public void tearDown() {
        passwordRepo.deleteAll();
        historyRepo.deleteAll();
        referenceRepo.findAll().forEach(r -> referenceRepo.deleteById(r.getId()));
    }

    // =========================================================================
    // 1. SECURITY TIPS TESTS (OFFLINE & SEARCH FILTERING)
    // =========================================================================

    @Test
    public void testSecurityTipsLoadOfflineWithoutNetwork() {
        TipsController tipsController = new TipsController();
        List<TipsController.SecurityTip> tips = tipsController.getAllTips();

        assertNotNull(tips, "Tips list must not be null");
        assertFalse(tips.isEmpty(), "Bundled tips must be loaded locally");
        assertTrue(tips.size() >= 10, "Should contain comprehensive security guidelines across categories");

        // Verify key domain categories are represented
        boolean hasPasswordTip = tips.stream().anyMatch(t -> t.category().contains("Password"));
        boolean hasIntegrityTip = tips.stream().anyMatch(t -> t.category().contains("File Integrity"));
        boolean hasPhishingTip = tips.stream().anyMatch(t -> t.category().contains("Phishing"));
        boolean hasPrivacyTip = tips.stream().anyMatch(t -> t.category().contains("Privacy"));

        assertTrue(hasPasswordTip, "Must contain Password Security guidance");
        assertTrue(hasIntegrityTip, "Must contain File Integrity guidance");
        assertTrue(hasPhishingTip, "Must contain Phishing guidance");
        assertTrue(hasPrivacyTip, "Must contain Privacy guidance");

        // Verify mandatory security caveats exist
        boolean explainsSha256Scope = tips.stream().anyMatch(t ->
                t.guidance().toLowerCase().contains("malware-free") ||
                t.summary().toLowerCase().contains("malware"));
        boolean explainsMd5Insecurity = tips.stream().anyMatch(t ->
                t.guidance().toLowerCase().contains("collision") ||
                t.title().toLowerCase().contains("md5"));

        assertTrue(explainsSha256Scope, "Must explain that SHA-256 checks content identity, not malware absence");
        assertTrue(explainsMd5Insecurity, "Must explain why MD5 should not be relied upon for security");
    }

    // =========================================================================
    // 2. SETTINGS PERSISTENCE & THEME
    // =========================================================================

    @Test
    public void testSettingsPersistenceAcrossRestarts(@TempDir Path tempDir) {
        File configFile = tempDir.resolve("test_settings.properties").toFile();

        // 1. First session: change theme and directory
        SettingsService session1 = new SettingsService(configFile, passwordRepo, historyRepo);
        assertEquals(Constants.THEME_DARK, session1.getTheme(), "Default theme must be DARK");

        session1.setTheme(Constants.THEME_LIGHT);
        assertEquals(Constants.THEME_LIGHT, session1.getTheme());
        assertFalse(session1.isDarkTheme());

        Path customReportsDir = tempDir.resolve("custom_reports");
        assertTrue(session1.setReportsDirectory(customReportsDir.toString()));

        // 2. Second session: reload from disk and verify persistence
        SettingsService session2 = new SettingsService(configFile, passwordRepo, historyRepo);
        assertEquals(Constants.THEME_LIGHT, session2.getTheme(), "Persisted theme must survive restart");
        assertEquals(customReportsDir.toFile().getAbsolutePath(), session2.getReportsDirectory());
    }

    @Test
    public void testInvalidReportDirectoryHandling(@TempDir Path tempDir) throws IOException {
        File configFile = tempDir.resolve("test_invalid_dir.properties").toFile();
        SettingsService service = new SettingsService(configFile, passwordRepo, historyRepo);

        // A regular file cannot be a reports directory
        File regularFile = tempDir.resolve("dummy.txt").toFile();
        Files.writeString(regularFile.toPath(), "Not a directory");

        boolean rejected = service.setReportsDirectory(regularFile.getAbsolutePath());
        assertFalse(rejected, "Must reject regular file as a reports directory");
        assertEquals(Constants.REPORTS_DIRECTORY, service.getReportsDirectory(), "Must fall back to default");

        // Null or blank falls back to default
        service.setReportsDirectory(null);
        assertEquals(Constants.REPORTS_DIRECTORY, service.getReportsDirectory());

        service.setReportsDirectory("   ");
        assertEquals(Constants.REPORTS_DIRECTORY, service.getReportsDirectory());
    }

    // =========================================================================
    // 3. SAFE DATA MANAGEMENT (CLEARING AUDIT LOGS PRESERVES BASELINES)
    // =========================================================================

    @Test
    public void testClearPasswordHistoryDoesNotClearIntegrityReferences() {
        SettingsService service = new SettingsService(null, passwordRepo, historyRepo);

        // Populate password history
        passwordRepo.insert(new PasswordHistory("2026-10-01 10:00:00", 16, Constants.STRENGTH_STRONG, 80));
        assertEquals(1, passwordRepo.count());

        // Populate baseline reference
        IntegrityReference ref = new IntegrityReference("critical.sys", "C:/sys/critical.sys", 2048L,
                "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "2026-10-01 09:00:00", "2026-10-01 09:00:00");
        int refId = referenceRepo.insert(ref);
        assertEquals(1, referenceRepo.count());

        // Clear password history
        boolean cleared = service.clearPasswordHistory();
        assertTrue(cleared);

        // Password history must be 0, but baseline reference must still be 1!
        assertEquals(0, passwordRepo.count(), "Password history must be cleared");
        assertEquals(1, referenceRepo.count(), "Baseline references must NOT be cleared when clearing password history");
    }

    @Test
    public void testClearIntegrityHistoryPreservesReferencesAndPdfFiles(@TempDir Path tempDir) throws IOException {
        SettingsService service = new SettingsService(null, passwordRepo, historyRepo);

        // Populate baseline reference
        IntegrityReference ref = new IntegrityReference("important.dll", "C:/bin/important.dll", 4096L,
                "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "2026-10-01 09:00:00", "2026-10-01 09:00:00");
        int refId = referenceRepo.insert(ref);

        // Populate verification history
        historyRepo.insert(new IntegrityCheck(refId, "important.dll", "2026-10-01 10:00:00",
                "d41d8cd98f00b204e9800998ecf8427e", "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                Constants.INTEGRITY_VERIFIED));
        assertEquals(1, historyRepo.count());

        // Create mock PDF report on disk
        File dummyPdf = tempDir.resolve("Audit_Report.pdf").toFile();
        Files.writeString(dummyPdf.toPath(), "%PDF-1.4 Mock Content");
        assertTrue(dummyPdf.exists());

        // Clear integrity verification history
        boolean cleared = service.clearIntegrityHistory();
        assertTrue(cleared);

        // Verification history must be 0
        assertEquals(0, historyRepo.count(), "Integrity verification check log must be cleared");

        // Baseline references must be preserved
        assertEquals(1, referenceRepo.count(), "Baseline references must NEVER be deleted when clearing history log");

        // PDF file on disk must be preserved
        assertTrue(dummyPdf.exists(), "PDF report files on disk must NEVER be deleted when clearing history");
    }
}
