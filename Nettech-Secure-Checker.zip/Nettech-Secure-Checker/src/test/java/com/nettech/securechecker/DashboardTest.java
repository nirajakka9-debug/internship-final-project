package com.nettech.securechecker;

import com.nettech.securechecker.model.DashboardActivity;
import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.model.SecurityReport;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.repository.ReportRepository;
import com.nettech.securechecker.service.DashboardService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Automated test suite for Dashboard metrics, chronological activity stream,
 * refresh behavior, and zero-knowledge invariants.
 */
public class DashboardTest {

    @TempDir
    static Path tempDir;

    private static DatabaseManager dbManager;
    private static PasswordHistoryRepository passwordRepo;
    private static IntegrityReferenceRepository referenceRepo;
    private static IntegrityHistoryRepository historyRepo;
    private static ReportRepository reportRepo;

    private DashboardService dashboardService;

    @BeforeAll
    static void initDatabase() {
        dbManager = DatabaseManager.getInstance();
        String testDb = tempDir.resolve("dashboard_test.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);

        passwordRepo  = new PasswordHistoryRepository(dbManager);
        referenceRepo = new IntegrityReferenceRepository(dbManager);
        historyRepo   = new IntegrityHistoryRepository(dbManager);
        reportRepo    = new ReportRepository(dbManager);
    }

    @BeforeEach
    void setUp() {
        clearAllTables();
        dashboardService = new DashboardService(passwordRepo, referenceRepo, historyRepo, reportRepo);
    }

    @AfterEach
    void tearDown() {
        clearAllTables();
    }

    private void clearAllTables() {
        passwordRepo.deleteAll();
        historyRepo.deleteAll();
        referenceRepo.findAll().forEach(r -> referenceRepo.deleteById(r.getId()));
        reportRepo.deleteAll();
    }

    // =========================================================================
    // 1. EMPTY DATABASE STATE TESTS
    // =========================================================================

    @Test
    @DisplayName("Empty database must display exact empty-state messages for stat cards and activities")
    void testEmptyDashboardState() {
        assertEquals(0, dashboardService.getPasswordActivityCount());
        assertEquals(0, dashboardService.getFilesCheckedCount());
        assertEquals(0, dashboardService.getReportsCount());

        assertEquals("No activity yet", dashboardService.getPasswordSecurityStatText());
        assertEquals("No activity yet", dashboardService.getFilesCheckedStatText());
        assertEquals("No reports yet", dashboardService.getReportsStatText());

        List<DashboardActivity> activities = dashboardService.getRecentActivities(10);
        assertNotNull(activities);
        assertTrue(activities.isEmpty(), "Recent activities stream must be empty when no operations exist");
    }

    // =========================================================================
    // 2. POPULATED METRICS TESTS
    // =========================================================================

    @Test
    @DisplayName("Populated metrics accurately reflect counts and singular/plural formatting")
    void testPopulatedDashboardMetrics() {
        // 1. Single items
        passwordRepo.insert(new PasswordHistory("2026-10-02 10:00:00", 16, Constants.STRENGTH_STRONG, 80));
        assertEquals(1, dashboardService.getPasswordActivityCount());
        assertEquals("1 password recorded", dashboardService.getPasswordSecurityStatText());

        int refId = referenceRepo.insert(new IntegrityReference("app.exe", "C:/bin/app.exe", 1024L,
                "d41d8cd98f00b204e9800998ecf8427e", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "2026-10-02 10:01:00", "2026-10-02 10:01:00"));
        assertEquals(1, dashboardService.getFilesCheckedCount());
        assertEquals("1 file checked", dashboardService.getFilesCheckedStatText());

        reportRepo.insert(new SecurityReport("PASSWORD_SECURITY", "report1.pdf", "2026-10-02 10:02:00", "reports/report1.pdf"));
        assertEquals(1, dashboardService.getReportsCount());
        assertEquals("1 report saved", dashboardService.getReportsStatText());

        // 2. Multiple items
        passwordRepo.insert(new PasswordHistory("2026-10-02 10:05:00", 20, Constants.STRENGTH_VERY_STRONG, 95));
        assertEquals(2, dashboardService.getPasswordActivityCount());
        assertEquals("2 passwords recorded", dashboardService.getPasswordSecurityStatText());

        historyRepo.insert(new IntegrityCheck(refId, "app.exe", "2026-10-02 10:10:00",
                "d41d8cd98f00b204e9800998ecf8427e", "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                Constants.INTEGRITY_VERIFIED));
        // Total files checked = 1 baseline reference + 1 verification check = 2
        assertEquals(2, dashboardService.getFilesCheckedCount());
        assertEquals("2 files checked", dashboardService.getFilesCheckedStatText());

        reportRepo.insert(new SecurityReport("FILE_INTEGRITY", "report2.pdf", "2026-10-02 10:15:00", "reports/report2.pdf"));
        assertEquals(2, dashboardService.getReportsCount());
        assertEquals("2 reports saved", dashboardService.getReportsStatText());
    }

    // =========================================================================
    // 3. CHRONOLOGICAL ACTIVITY ORDERING TESTS
    // =========================================================================

    @Test
    @DisplayName("Recent activity stream strictly sorts events descending by timestamp across all 4 categories")
    void testRecentActivitiesChronologicalOrdering() {
        // Insert events at known chronological timestamps
        passwordRepo.insert(new PasswordHistory("2026-10-02 08:00:00", 12, Constants.STRENGTH_MODERATE, 60));
        int refId = referenceRepo.insert(new IntegrityReference("data.bin", "C:/data.bin", 2048L,
                "d41d8cd98f00b204e9800998ecf8427e", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "2026-10-02 09:00:00", "2026-10-02 09:00:00"));
        historyRepo.insert(new IntegrityCheck(refId, "data.bin", "2026-10-02 10:00:00",
                "d41d8cd98f00b204e9800998ecf8427e", "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                Constants.INTEGRITY_VERIFIED));
        reportRepo.insert(new SecurityReport("COMBINED_SECURITY", "audit_full.pdf", "2026-10-02 11:00:00", "reports/audit_full.pdf"));

        List<DashboardActivity> activities = dashboardService.getRecentActivities(10);
        assertEquals(4, activities.size());

        // Verify descending order: 11:00:00 > 10:00:00 > 09:00:00 > 08:00:00
        assertEquals("2026-10-02 11:00:00", activities.get(0).getTimestamp());
        assertEquals(DashboardActivity.ActivityType.REPORT_EXPORT, activities.get(0).getType());
        assertTrue(activities.get(0).getTitle().contains("Report Exported"));

        assertEquals("2026-10-02 10:00:00", activities.get(1).getTimestamp());
        assertEquals(DashboardActivity.ActivityType.FILE_INTEGRITY_CHECK, activities.get(1).getType());
        assertTrue(activities.get(1).getTitle().contains("Integrity Check"));

        assertEquals("2026-10-02 09:00:00", activities.get(2).getTimestamp());
        assertEquals(DashboardActivity.ActivityType.FILE_BASELINE_SAVED, activities.get(2).getType());
        assertTrue(activities.get(2).getTitle().contains("Baseline Registered"));

        assertEquals("2026-10-02 08:00:00", activities.get(3).getTimestamp());
        assertEquals(DashboardActivity.ActivityType.PASSWORD_GENERATION, activities.get(3).getType());
        assertTrue(activities.get(3).getTitle().contains("Password Generated"));
    }

    // =========================================================================
    // 4. REFRESH BEHAVIOR TESTS
    // =========================================================================

    @Test
    @DisplayName("Dashboard immediately reflects new operations on refresh without duplicating records")
    void testRefreshBehaviorAfterNewOperations() {
        // Initial state
        assertEquals("No activity yet", dashboardService.getPasswordSecurityStatText());
        assertEquals("No activity yet", dashboardService.getFilesCheckedStatText());
        assertEquals("No reports yet", dashboardService.getReportsStatText());

        // 1. Perform password generation
        passwordRepo.insert(new PasswordHistory("2026-10-02 12:00:00", 18, Constants.STRENGTH_STRONG, 85));
        assertEquals("1 password recorded", dashboardService.getPasswordSecurityStatText());
        assertEquals(1, dashboardService.getRecentActivities(5).size());

        // 2. Perform baseline registration
        int refId = referenceRepo.insert(new IntegrityReference("kernel.bin", "C:/kernel.bin", 4096L,
                "d41d8cd98f00b204e9800998ecf8427e", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "2026-10-02 12:05:00", "2026-10-02 12:05:00"));
        assertEquals("1 file checked", dashboardService.getFilesCheckedStatText());
        assertEquals(2, dashboardService.getRecentActivities(5).size());

        // 3. Perform file integrity verification
        historyRepo.insert(new IntegrityCheck(refId, "kernel.bin", "2026-10-02 12:10:00",
                "d41d8cd98f00b204e9800998ecf8427e", "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                Constants.INTEGRITY_VERIFIED));
        assertEquals("2 files checked", dashboardService.getFilesCheckedStatText());
        assertEquals(3, dashboardService.getRecentActivities(5).size());

        // 4. Export a security report
        reportRepo.insert(new SecurityReport("COMBINED_SECURITY", "report_exec.pdf", "2026-10-02 12:15:00", "reports/report_exec.pdf"));
        assertEquals("1 report saved", dashboardService.getReportsStatText());
        assertEquals(4, dashboardService.getRecentActivities(5).size());

        // 5. Verify multiple subsequent queries do NOT create duplicate records
        for (int i = 0; i < 5; i++) {
            assertEquals(1, dashboardService.getPasswordActivityCount());
            assertEquals(2, dashboardService.getFilesCheckedCount());
            assertEquals(1, dashboardService.getReportsCount());
            assertEquals(4, dashboardService.getRecentActivities(10).size());
        }

        // Verify underlying database row counts are completely unchanged
        assertEquals(1, passwordRepo.count());
        assertEquals(1, referenceRepo.count());
        assertEquals(1, historyRepo.count());
        assertEquals(1, reportRepo.count());
    }

    // =========================================================================
    // 5. ZERO-KNOWLEDGE & SENSITIVE DATA INVARIANT TESTS
    // =========================================================================

    @Test
    @DisplayName("Dashboard activity models never expose plaintext passwords")
    void testZeroKnowledgeInvariant() {
        String sensitivePlainText = "ExtremelySecretP@ssw0rd!2026";

        // Store password generation metadata
        passwordRepo.insert(new PasswordHistory("2026-10-02 13:00:00", sensitivePlainText.length(), Constants.STRENGTH_VERY_STRONG, 95));

        List<DashboardActivity> activities = dashboardService.getRecentActivities(10);
        assertFalse(activities.isEmpty());

        for (DashboardActivity act : activities) {
            assertFalse(act.getTitle().contains(sensitivePlainText), "Activity title must never contain plaintext password");
            assertFalse(act.getDescription().contains(sensitivePlainText), "Activity description must never contain plaintext password");
            assertFalse(act.getStatusBadge().contains(sensitivePlainText), "Activity badge must never contain plaintext password");
            assertFalse(act.toString().contains(sensitivePlainText), "Activity toString must never contain plaintext password");
        }
    }

    @Test
    @DisplayName("DashboardController exposes metrics and delegates correctly to DashboardService")
    void testDashboardControllerIntegration() {
        com.nettech.securechecker.controller.DashboardController controller =
                new com.nettech.securechecker.controller.DashboardController(null, dashboardService);
        assertNotNull(controller.getDashboardService());

        // Empty state via controller
        assertEquals("No activity yet", controller.getPasswordStatText());
        assertEquals("No activity yet", controller.getFilesCheckedStatText());
        assertEquals("No reports yet", controller.getReportsStatText());
        assertTrue(controller.getRecentActivities().isEmpty());

        // Add records and refresh
        passwordRepo.insert(new PasswordHistory("2026-10-02 14:00:00", 16, Constants.STRENGTH_STRONG, 80));
        controller.refresh();

        assertEquals("1 password recorded", controller.getPasswordStatText());
        assertEquals(1, controller.getRecentActivities().size());
    }
}
