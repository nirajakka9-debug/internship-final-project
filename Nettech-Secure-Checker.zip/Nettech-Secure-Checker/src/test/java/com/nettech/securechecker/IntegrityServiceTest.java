package com.nettech.securechecker;

import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityCheckResult;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.IntegrityHistoryRepository;
import com.nettech.securechecker.repository.IntegrityReferenceRepository;
import com.nettech.securechecker.service.HashService;
import com.nettech.securechecker.service.IntegrityService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link IntegrityService} file verification and baseline management.
 */
class IntegrityServiceTest {

    @TempDir
    static Path dbTempDir;

    @TempDir
    Path fileTempDir;

    private static IntegrityService integrityService;
    private static IntegrityReferenceRepository referenceRepo;
    private static IntegrityHistoryRepository historyRepo;

    @BeforeAll
    static void initDatabase() {
        DatabaseManager dbManager = DatabaseManager.getInstance();
        String testDb = dbTempDir.resolve("test_integrity.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);
        referenceRepo = new IntegrityReferenceRepository(dbManager);
        historyRepo = new IntegrityHistoryRepository(dbManager);
        integrityService = new IntegrityService(new HashService(), referenceRepo, historyRepo);
    }

    @Test
    @DisplayName("1. Matching SHA-256 hash should yield VERIFIED status")
    void testMatchingFileIntegrityVerified() throws IOException {
        Path testFile = fileTempDir.resolve("trusted.txt");
        Files.writeString(testFile, "Original Secure Content 2026");

        // Register file baseline
        IntegrityReference ref = integrityService.registerFile(testFile.toFile());
        assertNotNull(ref);
        assertTrue(ref.getId() > 0);

        // Verify untampered file
        IntegrityCheckResult result = integrityService.verifyFile(testFile.toFile());
        assertNotNull(result);
        assertEquals(Constants.INTEGRITY_VERIFIED, result.getResult());
        assertTrue(result.isVerified());
        assertFalse(result.isModified());
        assertTrue(result.getExplanation().contains("integrity verified"));
        assertEquals(ref.getSha256(), result.getActualSha256());
        assertEquals(ref.getMd5(), result.getActualMd5());
    }

    @Test
    @DisplayName("2. Modified file content should yield MODIFIED status")
    void testModifiedFileIntegrityDetected() throws IOException {
        Path testFile = fileTempDir.resolve("document.txt");
        Files.writeString(testFile, "Initial Document Baseline");

        // Register baseline
        IntegrityReference ref = integrityService.registerFile(testFile.toFile());

        // Modify file contents
        Files.writeString(testFile, "Tampered / Modified Content!");

        IntegrityCheckResult result = integrityService.verifyFile(testFile.toFile());
        assertNotNull(result);
        assertEquals(Constants.INTEGRITY_MODIFIED, result.getResult());
        assertTrue(result.isModified());
        assertFalse(result.isVerified());
        assertTrue(result.getExplanation().contains("differs from the stored reference"));
        assertNotEquals(ref.getSha256(), result.getActualSha256());
    }

    @Test
    @DisplayName("3. SHA-256 mismatch must NEVER be overridden by a matching MD5")
    void testSha256MismatchNeverOverriddenByMd5() throws IOException {
        Path testFile = fileTempDir.resolve("sha_priority.txt");
        Files.writeString(testFile, "Content A");

        IntegrityReference ref = integrityService.registerFile(testFile.toFile());

        // Construct synthetic reference with matching MD5 but differing SHA-256
        IntegrityReference syntheticRef = new IntegrityReference(
                ref.getFileName(),
                ref.getFilePath(),
                ref.getFileSize(),
                ref.getMd5(), // matching MD5
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b800", // different SHA-256
                ref.getCreatedAt(),
                ref.getUpdatedAt()
        );
        syntheticRef.setId(ref.getId());

        IntegrityCheckResult result = integrityService.verifyReference(syntheticRef, testFile.toFile());
        assertEquals(Constants.INTEGRITY_MODIFIED, result.getResult(),
                "SHA-256 mismatch must strictly result in MODIFIED even if MD5 matches");
    }

    @Test
    @DisplayName("4. Missing reference data should yield UNABLE_TO_VERIFY safely")
    void testUnregisteredFileReturnsUnableToVerify() throws IOException {
        Path unregisteredFile = fileTempDir.resolve("unregistered.bin");
        Files.writeString(unregisteredFile, "Not registered in DB");

        IntegrityCheckResult result = integrityService.verifyFile(unregisteredFile.toFile());
        assertNotNull(result);
        assertEquals(Constants.INTEGRITY_UNABLE_TO_VERIFY, result.getResult());
        assertTrue(result.getExplanation().contains("No baseline integrity reference found"));
    }

    @Test
    @DisplayName("5. Non-existent or invalid file should yield UNABLE_TO_VERIFY safely")
    void testNonExistentFileReturnsUnableToVerify() throws IOException {
        Path tempPath = fileTempDir.resolve("will_delete.txt");
        Files.writeString(tempPath, "Temp data");
        IntegrityReference ref = integrityService.registerFile(tempPath.toFile());

        // Delete file on disk
        Files.delete(tempPath);

        IntegrityCheckResult result = integrityService.verifyReference(ref, tempPath.toFile());
        assertEquals(Constants.INTEGRITY_UNABLE_TO_VERIFY, result.getResult());
        assertTrue(result.getExplanation().contains("does not exist"));
    }

    @Test
    @DisplayName("6. Integrity check history records should be persisted in database")
    void testIntegrityHistoryPersisted() throws IOException {
        int initialCheckCount = integrityService.getCheckCount();

        Path testFile = fileTempDir.resolve("audit_trail.txt");
        Files.writeString(testFile, "Audit Content");

        IntegrityReference ref = integrityService.registerFile(testFile.toFile());
        integrityService.verifyFile(testFile.toFile());

        assertEquals(initialCheckCount + 1, integrityService.getCheckCount());

        List<IntegrityCheck> history = integrityService.getHistoryForReference(ref.getId());
        assertFalse(history.isEmpty());
        IntegrityCheck latest = history.get(0);
        assertEquals(ref.getId(), latest.getReferenceId());
        assertEquals(Constants.INTEGRITY_VERIFIED, latest.getResult());
        assertEquals(ref.getSha256(), latest.getExpectedSha256());
        assertEquals(ref.getSha256(), latest.getActualSha256());
    }

    @Test
    @DisplayName("7. Re-registering existing file path should update the stored reference")
    void testReRegisteringFileUpdatesReference() throws IOException {
        Path file = fileTempDir.resolve("update_test.txt");
        Files.writeString(file, "Version 1.0");

        IntegrityReference ref1 = integrityService.registerFile(file.toFile());
        String sha1 = ref1.getSha256();

        // Update file content
        Files.writeString(file, "Version 2.0 (Updated)");
        IntegrityReference ref2 = integrityService.registerFile(file.toFile());

        assertEquals(ref1.getId(), ref2.getId(), "Must update same reference ID");
        assertNotEquals(sha1, ref2.getSha256(), "SHA-256 must reflect updated content");

        Optional<IntegrityReference> fetched = integrityService.getReferenceById(ref1.getId());
        assertTrue(fetched.isPresent());
        assertEquals(ref2.getSha256(), fetched.get().getSha256());
    }

    @Test
    @DisplayName("8. Deleting an integrity reference should remove it from repository")
    void testDeleteReference() throws IOException {
        Path file = fileTempDir.resolve("to_delete.txt");
        Files.writeString(file, "Delete Me");

        IntegrityReference ref = integrityService.registerFile(file.toFile());
        int countBefore = integrityService.getReferenceCount();

        boolean deleted = integrityService.deleteReference(ref.getId());
        assertTrue(deleted);
        assertEquals(countBefore - 1, integrityService.getReferenceCount());
        assertTrue(integrityService.getReferenceById(ref.getId()).isEmpty());
    }
}
