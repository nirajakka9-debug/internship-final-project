package com.nettech.securechecker;

import com.nettech.securechecker.model.IntegrityCheck;
import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.model.SecurityReport;
import com.nettech.securechecker.repository.*;
import com.nettech.securechecker.service.ReportService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Automated test suite for Phase 5: Reports and PDF Export.
 */
public class ReportServiceTest {

    @TempDir
    static Path dbTempDir;

    private static DatabaseManager dbManager;
    private static PasswordHistoryRepository passwordRepo;
    private static IntegrityReferenceRepository referenceRepo;
    private static IntegrityHistoryRepository historyRepo;
    private static ReportRepository reportRepo;
    private static ReportService reportService;

    @BeforeAll
    static void initDatabase() {
        dbManager = DatabaseManager.getInstance();
        String testDb = dbTempDir.resolve("test_reports.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);

        passwordRepo  = new PasswordHistoryRepository(dbManager);
        referenceRepo = new IntegrityReferenceRepository(dbManager);
        historyRepo   = new IntegrityHistoryRepository(dbManager);
        reportRepo    = new ReportRepository(dbManager);

        reportService = new ReportService(passwordRepo, referenceRepo, historyRepo, reportRepo);
    }

    @BeforeEach
    public void setUp() {
        reportRepo.deleteAll();
        historyRepo.deleteAll();
        passwordRepo.deleteAll();
        referenceRepo.findAll().forEach(r -> referenceRepo.deleteById(r.getId()));
    }

    @AfterEach
    public void tearDown() {
        reportRepo.deleteAll();
        historyRepo.deleteAll();
        passwordRepo.deleteAll();
        referenceRepo.findAll().forEach(r -> referenceRepo.deleteById(r.getId()));
    }

    @Test
    public void testReportGenerationWithEmptyDatabase(@TempDir Path tempDir) throws Exception {
        File pwdPdf = tempDir.resolve("empty_pwd_report.pdf").toFile();
        File intPdf = tempDir.resolve("empty_int_report.pdf").toFile();
        File comPdf = tempDir.resolve("empty_com_report.pdf").toFile();

        SecurityReport r1 = reportService.exportPasswordReport(pwdPdf);
        SecurityReport r2 = reportService.exportIntegrityReport(intPdf);
        SecurityReport r3 = reportService.exportCombinedReport(comPdf);

        assertNotNull(r1);
        assertNotNull(r2);
        assertNotNull(r3);

        assertTrue(pwdPdf.exists() && pwdPdf.length() > 0, "Password PDF must be created and non-empty");
        assertTrue(intPdf.exists() && intPdf.length() > 0, "Integrity PDF must be created and non-empty");
        assertTrue(comPdf.exists() && comPdf.length() > 0, "Combined PDF must be created and non-empty");

        // Verify PDF Magic Bytes (%PDF)
        byte[] pwdBytes = Files.readAllBytes(pwdPdf.toPath());
        String header = new String(pwdBytes, 0, Math.min(pwdBytes.length, 5));
        assertEquals("%PDF-", header);

        // Verify 3 report records in database
        assertEquals(3, reportRepo.count());
    }

    @Test
    public void testReportSummariesReflectActualData() {
        // Insert mock password history
        passwordRepo.insert(new PasswordHistory("2026-10-01 10:00:00", 16, Constants.STRENGTH_STRONG, 78));
        passwordRepo.insert(new PasswordHistory("2026-10-01 10:05:00", 20, Constants.STRENGTH_VERY_STRONG, 92));
        passwordRepo.insert(new PasswordHistory("2026-10-01 10:10:00", 8, Constants.STRENGTH_WEAK, 35));

        // Insert mock baseline references
        IntegrityReference ref1 = new IntegrityReference("app.exe", "C:/bin/app.exe", 1048576L,
                "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "2026-10-01 09:00:00", "2026-10-01 09:00:00");
        int refId = referenceRepo.insert(ref1);

        // Insert mock integrity checks
        IntegrityCheck c1 = new IntegrityCheck(refId, "app.exe", "2026-10-01 11:00:00",
                "d41d8cd98f00b204e9800998ecf8427e", "d41d8cd98f00b204e9800998ecf8427e",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                Constants.INTEGRITY_VERIFIED);
        IntegrityCheck c2 = new IntegrityCheck(refId, "app.exe", "2026-10-01 12:00:00",
                "d41d8cd98f00b204e9800998ecf8427e", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
                Constants.INTEGRITY_MODIFIED);
        historyRepo.insert(c1);
        historyRepo.insert(c2);

        // Test password summary aggregation
        ReportService.PasswordReportSummary pwdSum = reportService.getPasswordSummary();
        assertEquals(3, pwdSum.total);
        assertEquals(1, pwdSum.weak);
        assertEquals(1, pwdSum.strong);
        assertEquals(1, pwdSum.veryStrong);
        assertEquals(0, pwdSum.veryWeak);
        assertEquals(0, pwdSum.moderate);
        assertEquals(68.3, Math.round(pwdSum.avgScore * 10.0) / 10.0);
        assertEquals(14.7, Math.round(pwdSum.avgLength * 10.0) / 10.0);

        // Test integrity summary aggregation
        ReportService.IntegrityReportSummary intSum = reportService.getIntegritySummary();
        assertEquals(1, intSum.totalReferences);
        assertEquals(2, intSum.totalChecks);
        assertEquals(1, intSum.verified);
        assertEquals(1, intSum.modified);
        assertEquals(0, intSum.unableToVerify);
    }

    @Test
    public void testPdfExportWithPopulatedDataAndLongValues(@TempDir Path tempDir) throws Exception {
        // Insert record with long path and long file name
        String longPath = "C:/Users/Administrator/Documents/SuperLongDirectoryNameWithLotsOfSubdirectories/NestedFurther/EvenMoreNesting/ExtremelyLongTargetFilenameForSecurityTestingAndVerification.config.backup.json";
        String sha256 = "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08";
        String md5 = "5eb63bbbe01eeed093cb22bb8f5acdc3";

        IntegrityReference ref = new IntegrityReference("ExtremelyLongTargetFilenameForSecurityTestingAndVerification.config.backup.json",
                longPath, 524288000L, md5, sha256, "2026-10-01 08:30:00", "2026-10-01 08:30:00");
        int refId = referenceRepo.insert(ref);

        historyRepo.insert(new IntegrityCheck(refId, ref.getFileName(), "2026-10-01 09:45:00",
                md5, md5, sha256, sha256, Constants.INTEGRITY_VERIFIED));

        passwordRepo.insert(new PasswordHistory("2026-10-01 10:00:00", 64, Constants.STRENGTH_VERY_STRONG, 98));

        File comPdf = tempDir.resolve("long_values_combined_report.pdf").toFile();
        SecurityReport report = reportService.exportCombinedReport(comPdf);

        assertNotNull(report);
        assertTrue(comPdf.exists());
        assertTrue(comPdf.length() > 1000, "Combined PDF with content should be substantial in size");

        // Verify metadata was saved
        List<SecurityReport> saved = reportService.getAllReports();
        assertEquals(1, saved.size());
        assertEquals(ReportService.TYPE_COMBINED_REPORT, saved.get(0).getReportType());
        assertEquals("long_values_combined_report.pdf", saved.get(0).getFileName());
    }

    @Test
    public void testReportContainsNoPlaintextPasswords(@TempDir Path tempDir) throws Exception {
        String secretWord = "SuperSecretPassword123!@#NeverLeakMe";

        // Persist password metadata
        passwordRepo.insert(new PasswordHistory("2026-10-01 12:00:00", secretWord.length(), Constants.STRENGTH_VERY_STRONG, 95));

        File pwdPdf = tempDir.resolve("leak_test_report.pdf").toFile();
        reportService.exportPasswordReport(pwdPdf);

        byte[] pdfBytes = Files.readAllBytes(pwdPdf.toPath());
        String pdfContent = new String(pdfBytes);

        // Security check: secret must never exist anywhere in the exported bytes
        assertFalse(pdfContent.contains(secretWord), "Plaintext password must NEVER exist in exported report!");
    }

    @Test
    public void testReportDeletion(@TempDir Path tempDir) throws Exception {
        File pdf1 = tempDir.resolve("test_report_del.pdf").toFile();
        SecurityReport r = reportService.exportPasswordReport(pdf1);

        assertEquals(1, reportService.getReportCount());

        boolean deleted = reportService.deleteReport(r.getId());
        assertTrue(deleted);
        assertEquals(0, reportService.getReportCount());
    }
}
