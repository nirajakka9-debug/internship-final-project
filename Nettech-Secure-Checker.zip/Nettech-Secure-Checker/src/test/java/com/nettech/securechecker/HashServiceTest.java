package com.nettech.securechecker;

import com.nettech.securechecker.model.FileHashResult;
import com.nettech.securechecker.service.HashService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link HashService} cryptographic hashing.
 */
class HashServiceTest {

    @TempDir
    Path tempDir;

    private HashService hashService;

    @BeforeEach
    void setUp() {
        hashService = new HashService();
    }

    @Test
    @DisplayName("1. Known MD5 output for deterministic text content")
    void testKnownMd5Output() throws IOException {
        // String "The quick brown fox jumps over the lazy dog"
        // MD5 = 9e107d9d372bb6826bd81d3542a419d6
        Path file = tempDir.resolve("fox.txt");
        Files.writeString(file, "The quick brown fox jumps over the lazy dog", StandardCharsets.UTF_8);

        String md5 = hashService.computeMd5(file.toFile());
        assertEquals("9e107d9d372bb6826bd81d3542a419d6", md5);
    }

    @Test
    @DisplayName("2. Known SHA-256 output for deterministic text content")
    void testKnownSha256Output() throws IOException {
        // String "The quick brown fox jumps over the lazy dog"
        // SHA-256 = d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592
        Path file = tempDir.resolve("fox.txt");
        Files.writeString(file, "The quick brown fox jumps over the lazy dog", StandardCharsets.UTF_8);

        String sha256 = hashService.computeSha256(file.toFile());
        assertEquals("d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592", sha256);
    }

    @Test
    @DisplayName("3. Empty file should produce standard empty hash digests")
    void testEmptyFileHashing() throws IOException {
        Path emptyFile = tempDir.resolve("empty.dat");
        Files.createFile(emptyFile);

        String md5 = hashService.computeMd5(emptyFile.toFile());
        String sha256 = hashService.computeSha256(emptyFile.toFile());

        // Standard known hashes for 0-byte input
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", md5);
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", sha256);
    }

    @Test
    @DisplayName("4. Small text file hashing")
    void testSmallTextFileHashing() throws IOException {
        Path textFile = tempDir.resolve("sample.txt");
        Files.writeString(textFile, "NETTECH Cybersecurity Test", StandardCharsets.UTF_8);

        String[] hashes = hashService.computeAllHashes(textFile.toFile());
        assertNotNull(hashes);
        assertEquals(2, hashes.length);
        assertEquals(32, hashes[0].length(), "MD5 must be 32 hex chars");
        assertEquals(64, hashes[1].length(), "SHA-256 must be 64 hex chars");
    }

    @Test
    @DisplayName("5. Binary file hashing with arbitrary bytes")
    void testBinaryFileHashing() throws IOException {
        Path binFile = tempDir.resolve("binary.bin");
        byte[] data = new byte[256];
        for (int i = 0; i < 256; i++) {
            data[i] = (byte) i;
        }
        Files.write(binFile, data);

        String md5 = hashService.computeMd5(binFile.toFile());
        String sha256 = hashService.computeSha256(binFile.toFile());

        assertNotNull(md5);
        assertNotNull(sha256);
        assertEquals(32, md5.length());
        assertEquals(64, sha256.length());
    }

    @Test
    @DisplayName("6. Multi-chunk file hashing (1.5 MB file with 512 KB chunk size)")
    void testMultiChunkFileHashing() throws IOException {
        // Use a smaller chunk size (512 KB) to explicitly test multiple streaming chunk loops
        HashService customChunkService = new HashService(512 * 1024);
        Path largeFile = tempDir.resolve("large_payload.dat");

        byte[] chunk = new byte[256 * 1024];
        Arrays.fill(chunk, (byte) 0x5A);

        try (FileOutputStream fos = new FileOutputStream(largeFile.toFile())) {
            // Write 6 chunks = 1.5 MB
            for (int i = 0; i < 6; i++) {
                fos.write(chunk);
            }
        }

        assertEquals(1572864, largeFile.toFile().length());

        String[] hashes = customChunkService.computeAllHashes(largeFile.toFile());
        assertNotNull(hashes[0]);
        assertNotNull(hashes[1]);
        assertEquals(32, hashes[0].length());
        assertEquals(64, hashes[1].length());

        // Verify that dual-digest single-pass equals individual passes
        assertEquals(customChunkService.computeMd5(largeFile.toFile()), hashes[0]);
        assertEquals(customChunkService.computeSha256(largeFile.toFile()), hashes[1]);
    }

    @Test
    @DisplayName("7. Non-existent file should throw FileNotFoundException")
    void testNonExistentFileThrows() {
        File missingFile = tempDir.resolve("does_not_exist.txt").toFile();
        assertThrows(FileNotFoundException.class, () -> hashService.computeMd5(missingFile));
        assertThrows(FileNotFoundException.class, () -> hashService.computeSha256(missingFile));
        assertThrows(FileNotFoundException.class, () -> hashService.computeAllHashes(missingFile));
    }

    @Test
    @DisplayName("8. Directory passed instead of file should throw IllegalArgumentException")
    void testDirectoryThrows() {
        File dir = tempDir.toFile();
        assertThrows(IllegalArgumentException.class, () -> hashService.computeMd5(dir));
        assertThrows(IllegalArgumentException.class, () -> hashService.computeSha256(dir));
        assertThrows(IllegalArgumentException.class, () -> hashService.calculateFileHash(dir));
    }

    @Test
    @DisplayName("9. Null file should throw IllegalArgumentException")
    void testNullFileThrows() {
        assertThrows(IllegalArgumentException.class, () -> hashService.computeMd5(null));
        assertThrows(IllegalArgumentException.class, () -> hashService.computeSha256(null));
    }

    @Test
    @DisplayName("10. calculateFileHash should return accurate metadata model")
    void testCalculateFileHashModel() throws IOException {
        Path file = tempDir.resolve("model_test.txt");
        Files.writeString(file, "Testing model output");

        FileHashResult result = hashService.calculateFileHash(file.toFile());
        assertNotNull(result);
        assertEquals("model_test.txt", result.getFileName());
        assertEquals(file.toAbsolutePath().toString(), result.getFilePath());
        assertEquals(file.toFile().length(), result.getFileSize());
        assertEquals(32, result.getMd5().length());
        assertEquals(64, result.getSha256().length());
        assertNotNull(result.getCalculatedAt());
    }

    @Test
    @DisplayName("11. verifyHash should accurately compare expected vs actual hashes")
    void testVerifyHash() throws IOException {
        Path file = tempDir.resolve("verify_test.txt");
        Files.writeString(file, "Data for verification");

        String expectedSha256 = hashService.computeSha256(file.toFile());
        String expectedMd5 = hashService.computeMd5(file.toFile());

        assertTrue(hashService.verifyHash(file.toFile(), expectedSha256, Constants.ALGORITHM_SHA256));
        assertTrue(hashService.verifyHash(file.toFile(), expectedSha256.toUpperCase(), Constants.ALGORITHM_SHA256));
        assertTrue(hashService.verifyHash(file.toFile(), expectedMd5, Constants.ALGORITHM_MD5));

        assertFalse(hashService.verifyHash(file.toFile(), "tampered_hash_value", Constants.ALGORITHM_SHA256));
        assertFalse(hashService.verifyHash(file.toFile(), null, Constants.ALGORITHM_SHA256));
    }
}
