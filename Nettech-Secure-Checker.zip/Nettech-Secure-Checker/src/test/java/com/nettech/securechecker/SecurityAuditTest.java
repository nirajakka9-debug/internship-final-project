package com.nettech.securechecker;

import com.nettech.securechecker.model.IntegrityReference;
import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.model.PasswordStrengthResult;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.service.HashService;
import com.nettech.securechecker.service.PasswordService;
import com.nettech.securechecker.service.PasswordStrengthService;
import com.nettech.securechecker.util.SecurityUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Security invariant audit tests.
 * <p>
 * Formally verifies zero-knowledge password persistence, local cryptographic guarantees,
 * lowercase hexadecimal formatting, and absence of file content storage.
 */
class SecurityAuditTest {

    @TempDir
    static Path tempDir;

    private static DatabaseManager dbManager;
    private static PasswordService passwordService;
    private static HashService hashService;

    @BeforeAll
    static void setUp() {
        dbManager = DatabaseManager.getInstance();
        String testDb = tempDir.resolve("security_audit.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);
        passwordService = new PasswordService(new PasswordStrengthService(), new PasswordHistoryRepository(dbManager));
        hashService = new HashService();
    }

    @Test
    @DisplayName("Security Rule 1: Plaintext password must NEVER exist anywhere in the SQLite database")
    void testPlaintextPasswordNeverInDatabase() throws SQLException {
        String testSecretPassword = "SuperSecretPlainTextPassword#2026";

        // Perform password generation and metadata history recording
        int recordId = passwordService.recordToHistory(testSecretPassword.length(), "Strong", 80);
        assertTrue(recordId > 0);

        // Query the database directly via raw SQL
        try (Connection conn = dbManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM password_history")) {

            while (rs.next()) {
                String rowString = rs.getInt("id") + " | " +
                        rs.getString("generated_at") + " | " +
                        rs.getInt("length") + " | " +
                        rs.getString("strength") + " | " +
                        rs.getInt("score");

                assertFalse(rowString.contains(testSecretPassword),
                        "Database row must NEVER contain the plaintext password");
            }
        }
    }

    @Test
    @DisplayName("Security Rule 2: Password strength analysis result object must NEVER retain the plaintext password")
    void testStrengthResultDoesNotStorePlaintext() {
        String sensitivePassword = "MyConfidentialPassword!99";
        PasswordStrengthService analyzer = new PasswordStrengthService();
        PasswordStrengthResult result = analyzer.analyzeStrength(sensitivePassword);

        assertNotNull(result);
        assertFalse(result.toString().contains(sensitivePassword),
                "PasswordStrengthResult.toString() must NOT contain the sensitive password");

        // Verify with reflection that no String or char[] field holds the password
        for (java.lang.reflect.Field field : PasswordStrengthResult.class.getDeclaredFields()) {
            field.setAccessible(true);
            try {
                Object val = field.get(result);
                if (val != null) {
                    assertFalse(val.toString().contains(sensitivePassword),
                            "Field " + field.getName() + " must not store the plaintext password");
                }
            } catch (IllegalAccessException e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }
    }

    @Test
    @DisplayName("Security Rule 3: File hashes must always be lowercase hexadecimal format")
    void testHashesAreLowercaseHexadecimal() throws IOException {
        Path sample = tempDir.resolve("sample.txt");
        Files.writeString(sample, "Check Hex Format");

        String md5 = hashService.computeMd5(sample.toFile());
        String sha256 = hashService.computeSha256(sample.toFile());

        assertEquals(32, md5.length());
        assertTrue(md5.matches("^[a-f0-9]{32}$"), "MD5 must be exactly 32 lowercase hex characters");
        assertTrue(SecurityUtils.isValidHexHash(md5, 32));

        assertEquals(64, sha256.length());
        assertTrue(sha256.matches("^[a-f0-9]{64}$"), "SHA-256 must be exactly 64 lowercase hex characters");
        assertTrue(SecurityUtils.isValidHexHash(sha256, 64));
    }

    @Test
    @DisplayName("Security Rule 4: File content is NEVER stored in database tables")
    void testFileContentNeverStoredInDatabase() throws SQLException {
        try (Connection conn = dbManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("PRAGMA table_info(integrity_references)")) {

            while (rs.next()) {
                String colName = rs.getString("name").toLowerCase();
                String colType = rs.getString("type").toUpperCase();

                assertFalse(colName.contains("content") || colName.contains("data") || colName.contains("blob"),
                        "Column " + colName + " should not be a raw data container");
                assertFalse(colType.contains("BLOB"), "Integrity references table must not have BLOB columns");
            }
        }
    }
}
