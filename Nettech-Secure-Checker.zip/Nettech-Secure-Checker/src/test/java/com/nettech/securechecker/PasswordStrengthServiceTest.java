package com.nettech.securechecker;

import com.nettech.securechecker.model.PasswordStrengthResult;
import com.nettech.securechecker.service.PasswordStrengthService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link PasswordStrengthService} password analysis and scoring.
 */
class PasswordStrengthServiceTest {

    private PasswordStrengthService strengthService;

    @BeforeEach
    void setUp() {
        strengthService = new PasswordStrengthService();
    }

    @Test
    @DisplayName("1. Empty or null password should return 0 score and Very Weak label")
    void testEmptyAndNullPassword() {
        PasswordStrengthResult nullRes = strengthService.analyzeStrength(null);
        assertEquals(0, nullRes.getScore());
        assertEquals(Constants.STRENGTH_VERY_WEAK, nullRes.getStrengthLabel());
        assertEquals(0, nullRes.getLength());
        assertFalse(nullRes.getRecommendations().isEmpty());

        PasswordStrengthResult emptyRes = strengthService.analyzeStrength("");
        assertEquals(0, emptyRes.getScore());
        assertEquals(Constants.STRENGTH_VERY_WEAK, emptyRes.getStrengthLabel());
        assertEquals(0, emptyRes.getLength());
    }

    @Test
    @DisplayName("2. Very short password should yield a low score")
    void testVeryShortPassword() {
        PasswordStrengthResult res = strengthService.analyzeStrength("aB1!");
        assertEquals(4, res.getLength());
        assertTrue(res.getScore() <= Constants.SCORE_WEAK_MAX, "Short password score must be low");
    }

    @Test
    @DisplayName("3. Lowercase-only password should be penalized for lack of diversity")
    void testLowercaseOnlyPassword() {
        PasswordStrengthResult res = strengthService.analyzeStrength("simplelowercasepassword");
        assertTrue(res.hasLowercase());
        assertFalse(res.hasUppercase());
        assertFalse(res.hasDigits());
        assertFalse(res.hasSpecialCharacters());
        assertTrue(res.getRecommendations().stream().anyMatch(r -> r.contains("uppercase")));
    }

    @Test
    @DisplayName("4. Uppercase and lowercase combination should score higher than single category")
    void testMixedCasePassword() {
        PasswordStrengthResult lowerOnly = strengthService.analyzeStrength("simplepassword");
        PasswordStrengthResult mixedCase = strengthService.analyzeStrength("SimplePassword");
        assertTrue(mixedCase.getScore() > lowerOnly.getScore(),
                "Mixed case password must score higher than single category");
    }

    @Test
    @DisplayName("5. Adding numbers should improve score and detect digit presence")
    void testPasswordWithNumbers() {
        PasswordStrengthResult res = strengthService.analyzeStrength("SecurePass892");
        assertTrue(res.hasDigits());
        assertTrue(res.hasUppercase());
        assertTrue(res.hasLowercase());
        assertFalse(res.hasSpecialCharacters());
    }

    @Test
    @DisplayName("6. Adding special characters should increase score and detect special presence")
    void testPasswordWithSpecialCharacters() {
        PasswordStrengthResult withoutSpecial = strengthService.analyzeStrength("SecurePass89");
        PasswordStrengthResult withSpecial = strengthService.analyzeStrength("SecurePass89!#");
        assertTrue(withSpecial.hasSpecialCharacters());
        assertTrue(withSpecial.getScore() >= withoutSpecial.getScore());
    }

    @Test
    @DisplayName("7. Long, diverse password should achieve high score (Strong or Very Strong)")
    void testLongDiversePassword() {
        PasswordStrengthResult res = strengthService.analyzeStrength("K9#vX!mP$8qZ@2wL%4rT");
        assertTrue(res.getScore() >= Constants.SCORE_STRONG_MAX);
        assertTrue(res.getStrengthLabel().equals(Constants.STRENGTH_STRONG) ||
                   res.getStrengthLabel().equals(Constants.STRENGTH_VERY_STRONG));
        assertTrue(res.hasLowercase());
        assertTrue(res.hasUppercase());
        assertTrue(res.hasDigits());
        assertTrue(res.hasSpecialCharacters());
        assertFalse(res.isRepeatedCharacterDetected());
        assertFalse(res.isSequentialPatternDetected());
        assertFalse(res.isCommonPatternDetected());
    }

    @Test
    @DisplayName("8. Repeated characters (e.g. 'aaaa', '1111') should be detected and penalized")
    void testRepeatedCharactersDetection() {
        assertTrue(strengthService.hasRepeatedCharacters("passwoooord"));
        assertTrue(strengthService.hasRepeatedCharacters("11112222"));
        assertTrue(strengthService.hasRepeatedCharacters("Test!!!!"));
        assertFalse(strengthService.hasRepeatedCharacters("NoRepeats12!"));

        PasswordStrengthResult clean = strengthService.analyzeStrength("AbcdEfgh1234!@#$");
        PasswordStrengthResult withRepeats = strengthService.analyzeStrength("AaaaEfgh1111!@#$");
        assertTrue(withRepeats.isRepeatedCharacterDetected());
        assertTrue(withRepeats.getRecommendations().stream().anyMatch(r -> r.contains("repeating")));
    }

    @Test
    @DisplayName("9. Sequential patterns (e.g. '1234', 'abcd', 'qwerty') should be detected")
    void testSequentialPatternsDetection() {
        assertTrue(strengthService.hasSequentialPatterns("abcdPass99"));
        assertTrue(strengthService.hasSequentialPatterns("Sec12345Pass"));
        assertTrue(strengthService.hasSequentialPatterns("MyqwertyKey1"));
        assertTrue(strengthService.hasSequentialPatterns("Reverse4321Pass"));
        assertFalse(strengthService.hasSequentialPatterns("K9#vXmP8qZ"));

        PasswordStrengthResult seqRes = strengthService.analyzeStrength("My1234Pass!");
        assertTrue(seqRes.isSequentialPatternDetected());
    }

    @Test
    @DisplayName("10. Common weak patterns ('password', 'admin', 'letmein') should be detected and penalized")
    void testCommonWeakPatternsDetection() {
        assertTrue(strengthService.hasCommonPatterns("MyPassword123"));
        assertTrue(strengthService.hasCommonPatterns("admin2024!"));
        assertTrue(strengthService.hasCommonPatterns("letmeinnow"));
        assertTrue(strengthService.hasCommonPatterns("qwertyuiop"));
        assertFalse(strengthService.hasCommonPatterns("X9#kL$2pQ!"));

        PasswordStrengthResult res = strengthService.analyzeStrength("password123");
        assertTrue(res.isCommonPatternDetected());
        assertTrue(res.getScore() <= Constants.SCORE_WEAK_MAX);
    }

    @Test
    @DisplayName("11. Score must always remain bounded within 0 to 100")
    void testScoreBounds() {
        String[] testCases = {
                "", "a", "123", "password", "P@ssw0rd", "VeryLongSecureComplexPassword123!@#$",
                "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "12345678901234567890",
                "!@#$%^&*()-_=+[]{};:,.?/~!@#$%^&*()"
        };
        for (String testCase : testCases) {
            PasswordStrengthResult res = strengthService.analyzeStrength(testCase);
            assertTrue(res.getScore() >= 0, "Score should not be below 0");
            assertTrue(res.getScore() <= 100, "Score should not exceed 100");
        }
    }

    @Test
    @DisplayName("12. Determinism: Same input must always produce identical analysis results")
    void testAnalysisDeterminism() {
        String testPassword = "SampleTestPassword#2026!";
        PasswordStrengthResult first = strengthService.analyzeStrength(testPassword);
        PasswordStrengthResult second = strengthService.analyzeStrength(testPassword);

        assertEquals(first.getScore(), second.getScore());
        assertEquals(first.getStrengthLabel(), second.getStrengthLabel());
        assertEquals(first.getLength(), second.getLength());
        assertEquals(first.hasLowercase(), second.hasLowercase());
        assertEquals(first.hasUppercase(), second.hasUppercase());
        assertEquals(first.hasDigits(), second.hasDigits());
        assertEquals(first.hasSpecialCharacters(), second.hasSpecialCharacters());
        assertEquals(first.isRepeatedCharacterDetected(), second.isRepeatedCharacterDetected());
        assertEquals(first.isSequentialPatternDetected(), second.isSequentialPatternDetected());
        assertEquals(first.isCommonPatternDetected(), second.isCommonPatternDetected());
        assertEquals(first.getRecommendations(), second.getRecommendations());
    }
}
