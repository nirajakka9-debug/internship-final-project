package com.nettech.securechecker;

import com.nettech.securechecker.repository.DatabaseManager;
import org.junit.jupiter.api.*;

import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for database initialisation and schema integrity.
 * <p>
 * Uses an isolated temporary SQLite database so tests run quickly
 * and verify full persistence across multiple connections.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class DatabaseManagerTest {

    @TempDir
    static Path tempDir;

    private static DatabaseManager dbManager;

    @BeforeAll
    static void setUp() {
        dbManager = DatabaseManager.getInstance();
        String testDb = tempDir.resolve("test_nettech.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);
    }

    @Test
    @Order(1)
    @DisplayName("Database should initialise successfully")
    void testDatabaseInitialisation() {
        assertTrue(dbManager.isInitialized(), "Database should be flagged as initialised");
    }

    @Test
    @Order(2)
    @DisplayName("Should be able to obtain a database connection")
    void testDatabaseConnection() throws SQLException {
        try (Connection conn = dbManager.getConnection()) {
            assertNotNull(conn, "Connection should not be null");
            assertFalse(conn.isClosed(), "Connection should be open");
        }
    }

    @Test
    @Order(3)
    @DisplayName("password_history table should exist")
    void testPasswordHistoryTableExists() throws SQLException {
        assertTrue(tableExists("password_history"),
                "Table 'password_history' should exist");
    }

    @Test
    @Order(4)
    @DisplayName("integrity_references table should exist")
    void testIntegrityReferencesTableExists() throws SQLException {
        assertTrue(tableExists("integrity_references"),
                "Table 'integrity_references' should exist");
    }

    @Test
    @Order(5)
    @DisplayName("integrity_history table should exist")
    void testIntegrityHistoryTableExists() throws SQLException {
        assertTrue(tableExists("integrity_history"),
                "Table 'integrity_history' should exist");
    }

    @Test
    @Order(6)
    @DisplayName("reports table should exist")
    void testReportsTableExists() throws SQLException {
        assertTrue(tableExists("reports"),
                "Table 'reports' should exist");
    }

    @Test
    @Order(7)
    @DisplayName("password_history table should have correct columns")
    void testPasswordHistoryColumns() throws SQLException {
        assertColumnsExist("password_history",
                "id", "generated_at", "length", "strength", "score");
    }

    @Test
    @Order(8)
    @DisplayName("integrity_references table should have correct columns")
    void testIntegrityReferencesColumns() throws SQLException {
        assertColumnsExist("integrity_references",
                "id", "file_name", "file_path", "file_size", "md5", "sha256",
                "created_at", "updated_at");
    }

    @Test
    @Order(9)
    @DisplayName("integrity_history table should have correct columns")
    void testIntegrityHistoryColumns() throws SQLException {
        assertColumnsExist("integrity_history",
                "id", "reference_id", "file_name", "checked_at",
                "expected_md5", "actual_md5", "expected_sha256", "actual_sha256", "result");
    }

    @Test
    @Order(10)
    @DisplayName("reports table should have correct columns")
    void testReportsColumns() throws SQLException {
        assertColumnsExist("reports",
                "id", "report_type", "file_name", "generated_at", "output_path");
    }

    @Test
    @Order(11)
    @DisplayName("Database initialization should create and verify all 4 required tables in isolated environment")
    void testDatabaseInitializationAndSchemaVerification() throws SQLException {
        String isolatedDbPath = tempDir.resolve("isolated_schema_verify.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + isolatedDbPath);
        assertTrue(new java.io.File(isolatedDbPath).exists(),
                "Isolated database file should be created");

        try (Connection conn = dbManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT COUNT(*) FROM sqlite_master WHERE type='table' " +
                     "AND name IN ('password_history', 'integrity_references', 'integrity_history', 'reports')")) {
            assertTrue(rs.next());
            assertEquals(4, rs.getInt(1), "All four required tables must exist in initialized database");
        } finally {
            // Restore dbManager to the main isolated test database
            String testDb = tempDir.resolve("test_nettech.db").toAbsolutePath().toString();
            dbManager.initialize("jdbc:sqlite:" + testDb);
        }
    }

    // ── Helpers ────────────────────────────────────────────────

    /**
     * Checks whether a table exists in the database.
     */
    private boolean tableExists(String tableName) throws SQLException {
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT name FROM sqlite_master WHERE type='table' AND name = ?")) {
            stmt.setString(1, tableName);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Asserts that all expected columns exist in the given table.
     */
    private void assertColumnsExist(String tableName, String... expectedColumns) throws SQLException {
        try (Connection conn = dbManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("PRAGMA table_info(" + tableName + ")")) {

            java.util.Set<String> actualColumns = new java.util.HashSet<>();
            while (rs.next()) {
                actualColumns.add(rs.getString("name"));
            }

            for (String expected : expectedColumns) {
                assertTrue(actualColumns.contains(expected),
                        "Table '" + tableName + "' should contain column '" + expected + "'");
            }
        }
    }
}
