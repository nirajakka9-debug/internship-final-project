package com.nettech.securechecker;

import com.nettech.securechecker.model.PasswordHistory;
import com.nettech.securechecker.repository.DatabaseManager;
import com.nettech.securechecker.repository.PasswordHistoryRepository;
import com.nettech.securechecker.service.PasswordService;
import com.nettech.securechecker.util.Constants;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for {@link PasswordService} password generation.
 */
class PasswordGeneratorTest {

    @TempDir
    static Path tempDir;

    private static PasswordService passwordService;
    private static PasswordHistoryRepository historyRepository;

    @BeforeAll
    static void setUp() {
        DatabaseManager dbManager = DatabaseManager.getInstance();
        String testDb = tempDir.resolve("test_pwd_gen.db").toAbsolutePath().toString();
        dbManager.initialize("jdbc:sqlite:" + testDb);
        historyRepository = new PasswordHistoryRepository(dbManager);
        passwordService = new PasswordService(new com.nettech.securechecker.service.PasswordStrengthService(), historyRepository);
    }

    @Test
    @DisplayName("1. Default generation should produce a 16-character password with mixed characters")
    void testDefaultPasswordGeneration() {
        String pwd = passwordService.generatePassword();
        assertNotNull(pwd);
        assertEquals(16, pwd.length());
        assertTrue(pwd.matches(".*[a-z].*"), "Must contain lowercase");
        assertTrue(pwd.matches(".*[A-Z].*"), "Must contain uppercase");
        assertTrue(pwd.matches(".*[0-9].*"), "Must contain digit");
        assertTrue(pwd.chars().anyMatch(c -> Constants.CHARSET_SPECIAL.indexOf(c) != -1), "Must contain special");
    }

    @Test
    @DisplayName("2. Requested length should be strictly respected")
    void testRequestedLengthRespected() {
        for (int len : new int[]{8, 12, 24, 32, 64, 128}) {
            String pwd = passwordService.generatePassword(len, true, true, true, true);
            assertEquals(len, pwd.length(), "Generated password length must match requested length");
        }
    }

    @Test
    @DisplayName("3. Minimum length (< 8) should be rejected")
    void testMinimumLengthEnforced() {
        assertThrows(IllegalArgumentException.class, () ->
                passwordService.generatePassword(7, true, true, true, true));
        assertThrows(IllegalArgumentException.class, () ->
                passwordService.generatePassword(0, true, true, true, true));
        assertThrows(IllegalArgumentException.class, () ->
                passwordService.generatePassword(-5, true, true, true, true));
    }

    @Test
    @DisplayName("4. Maximum length (> 128) should be rejected")
    void testMaximumLengthEnforced() {
        assertThrows(IllegalArgumentException.class, () ->
                passwordService.generatePassword(129, true, true, true, true));
        assertThrows(IllegalArgumentException.class, () ->
                passwordService.generatePassword(256, true, true, true, true));
    }

    @Test
    @DisplayName("5. Lowercase-only option should generate only lowercase letters")
    void testLowercaseOnlyOption() {
        String pwd = passwordService.generatePassword(16, false, true, false, false);
        assertEquals(16, pwd.length());
        assertTrue(pwd.matches("^[a-z]+$"), "Password must contain ONLY lowercase characters");
    }

    @Test
    @DisplayName("6. Uppercase-only option should generate only uppercase letters")
    void testUppercaseOnlyOption() {
        String pwd = passwordService.generatePassword(16, true, false, false, false);
        assertEquals(16, pwd.length());
        assertTrue(pwd.matches("^[A-Z]+$"), "Password must contain ONLY uppercase characters");
    }

    @Test
    @DisplayName("7. Digit-only option should generate only digits")
    void testDigitOnlyOption() {
        String pwd = passwordService.generatePassword(16, false, false, true, false);
        assertEquals(16, pwd.length());
        assertTrue(pwd.matches("^[0-9]+$"), "Password must contain ONLY digits");
    }

    @Test
    @DisplayName("8. Special-character-only option should generate only special characters")
    void testSpecialOnlyOption() {
        String pwd = passwordService.generatePassword(16, false, false, false, true);
        assertEquals(16, pwd.length());
        for (char c : pwd.toCharArray()) {
            assertTrue(Constants.CHARSET_SPECIAL.indexOf(c) != -1,
                    "Character '" + c + "' must belong to special charset");
        }
    }

    @Test
    @DisplayName("9. Enabled categories must always appear in the generated password")
    void testRequiredCategoriesActuallyAppear() {
        for (int i = 0; i < 50; i++) {
            String pwd = passwordService.generatePassword(16, true, true, true, true);
            assertTrue(pwd.matches(".*[a-z].*"), "Must contain lowercase");
            assertTrue(pwd.matches(".*[A-Z].*"), "Must contain uppercase");
            assertTrue(pwd.matches(".*[0-9].*"), "Must contain digit");
            assertTrue(pwd.chars().anyMatch(c -> Constants.CHARSET_SPECIAL.indexOf(c) != -1), "Must contain special");
        }
    }

    @Test
    @DisplayName("10. Disabled categories must NOT appear in the generated password")
    void testDisabledCategoriesDoNotAppear() {
        // No digits and no special characters
        String pwd = passwordService.generatePassword(20, true, true, false, false);
        assertFalse(pwd.matches(".*[0-9].*"), "Must NOT contain any digits");
        assertFalse(pwd.chars().anyMatch(c -> Constants.CHARSET_SPECIAL.indexOf(c) != -1),
                "Must NOT contain any special characters");
    }

    @Test
    @DisplayName("11. Disabling all character categories should throw IllegalArgumentException")
    void testNoCategorySelectionFails() {
        assertThrows(IllegalArgumentException.class, () ->
                passwordService.generatePassword(16, false, false, false, false));
    }

    @Test
    @DisplayName("12. Consecutive generations should produce distinct, non-identical passwords")
    void testDifferentGenerationsAreNonIdentical() {
        Set<String> generatedSet = new HashSet<>();
        int sampleSize = 100;
        for (int i = 0; i < sampleSize; i++) {
            generatedSet.add(passwordService.generatePassword(16, true, true, true, true));
        }
        assertEquals(sampleSize, generatedSet.size(), "100 generated passwords must all be distinct");
    }

    @Test
    @DisplayName("13. Password generation must NEVER write plaintext passwords to history or DB")
    void testPasswordNeverPersistedInHistory() {
        int initialCount = historyRepository.count();
        String generatedPwd = passwordService.generatePassword(16, true, true, true, true);

        // Record metadata to history
        int recordId = passwordService.recordToHistory(generatedPwd.length(), "Strong", 85);
        assertTrue(recordId > 0);
        assertEquals(initialCount + 1, historyRepository.count());

        List<PasswordHistory> historyList = passwordService.getHistory();
        for (PasswordHistory record : historyList) {
            assertNotNull(record.getGeneratedAt());
            assertTrue(record.getLength() >= 8);
            assertNotNull(record.getStrength());
            // Verify that the record object has no password fields and string representations never contain the password
            assertFalse(record.toString().contains(generatedPwd),
                    "History record toString() must NEVER leak the plaintext password");
        }
    }
}
