package com.nettech.securechecker;

import com.nettech.securechecker.util.Constants;
import com.nettech.securechecker.util.FileUtils;
import com.nettech.securechecker.util.SecurityUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for utility classes: Constants, FileUtils, SecurityUtils.
 */
class UtilityTest {

    // ── Constants Tests ────────────────────────────────────────

    @Test
    @DisplayName("Application title should be defined")
    void testAppTitleIsDefined() {
        assertNotNull(Constants.APP_TITLE);
        assertFalse(Constants.APP_TITLE.isBlank());
    }

    @Test
    @DisplayName("Database URL should start with jdbc:sqlite:")
    void testDatabaseUrl() {
        assertTrue(Constants.DB_URL.startsWith("jdbc:sqlite:"),
                "DB_URL should be a SQLite JDBC URL");
    }

    @Test
    @DisplayName("Password length bounds should be valid")
    void testPasswordLengthBounds() {
        assertTrue(Constants.MIN_PASSWORD_LENGTH > 0,
                "Minimum password length should be positive");
        assertTrue(Constants.MAX_PASSWORD_LENGTH > Constants.MIN_PASSWORD_LENGTH,
                "Maximum should exceed minimum");
    }

    // ── FileUtils Tests ────────────────────────────────────────

    @Test
    @DisplayName("ensureDirectoryExists should create directory")
    void testEnsureDirectoryExists(@TempDir Path tempDir) {
        String newDir = tempDir.resolve("test-subdir").toString();
        assertTrue(FileUtils.ensureDirectoryExists(newDir));
        assertTrue(new File(newDir).isDirectory());
    }

    @Test
    @DisplayName("getFileName should extract file name from path")
    void testGetFileName() {
        assertEquals("report.pdf", FileUtils.getFileName("/path/to/report.pdf"));
        assertEquals("data.db", FileUtils.getFileName("C:\\Users\\data.db"));
        assertEquals("", FileUtils.getFileName(null));
        assertEquals("", FileUtils.getFileName("   "));
        assertEquals(-1, FileUtils.getFileSize(null));
        assertEquals(-1, FileUtils.getFileSize("   "));
        assertFalse(FileUtils.isReadableFile(null));
        assertFalse(FileUtils.isReadableFile("   "));
        assertFalse(FileUtils.ensureDirectoryExists(null));
        assertFalse(FileUtils.ensureDirectoryExists("   "));
    }

    @Test
    @DisplayName("getFileSize should return -1 for non-existent file")
    void testGetFileSizeNonExistent() {
        assertEquals(-1, FileUtils.getFileSize("/non/existent/file.txt"));
    }

    @Test
    @DisplayName("getFileSize should return correct size for existing file")
    void testGetFileSizeExisting(@TempDir Path tempDir) throws IOException {
        Path testFile = tempDir.resolve("test.txt");
        Files.writeString(testFile, "hello");
        assertEquals(5, FileUtils.getFileSize(testFile.toString()));
    }

    @Test
    @DisplayName("isReadableFile should return false for non-existent file")
    void testIsReadableFileNonExistent() {
        assertFalse(FileUtils.isReadableFile("/does/not/exist.txt"));
    }

    @Test
    @DisplayName("isReadableFile should return true for readable file")
    void testIsReadableFileExisting(@TempDir Path tempDir) throws IOException {
        Path testFile = tempDir.resolve("readable.txt");
        Files.writeString(testFile, "data");
        assertTrue(FileUtils.isReadableFile(testFile.toString()));
    }

    // ── SecurityUtils Tests ────────────────────────────────────

    @Test
    @DisplayName("currentTimestamp should return non-empty string")
    void testCurrentTimestamp() {
        String ts = SecurityUtils.currentTimestamp();
        assertNotNull(ts);
        assertFalse(ts.isBlank());
        // Format: yyyy-MM-dd HH:mm:ss
        assertTrue(ts.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}"),
                "Timestamp should match yyyy-MM-dd HH:mm:ss format");
    }

    @Test
    @DisplayName("isValidPasswordLength should accept valid lengths")
    void testValidPasswordLength() {
        assertTrue(SecurityUtils.isValidPasswordLength(8));
        assertTrue(SecurityUtils.isValidPasswordLength(16));
        assertTrue(SecurityUtils.isValidPasswordLength(128));
    }

    @Test
    @DisplayName("isValidPasswordLength should reject invalid lengths")
    void testInvalidPasswordLength() {
        assertFalse(SecurityUtils.isValidPasswordLength(0));
        assertFalse(SecurityUtils.isValidPasswordLength(7));
        assertFalse(SecurityUtils.isValidPasswordLength(129));
        assertFalse(SecurityUtils.isValidPasswordLength(-1));
    }

    @Test
    @DisplayName("mask should replace characters with asterisks")
    void testMask() {
        assertEquals("********", SecurityUtils.mask("password"));
        assertEquals("", SecurityUtils.mask(""));
        assertEquals("", SecurityUtils.mask(null));
    }

    @Test
    @DisplayName("isValidHexHash should validate MD5 hashes (32 chars)")
    void testValidMd5Hash() {
        assertTrue(SecurityUtils.isValidHexHash("d41d8cd98f00b204e9800998ecf8427e", 32));
        assertFalse(SecurityUtils.isValidHexHash("short", 32));
        assertFalse(SecurityUtils.isValidHexHash(null, 32));
        assertFalse(SecurityUtils.isValidHexHash("g41d8cd98f00b204e9800998ecf8427e", 32)); // 'g' invalid
    }

    @Test
    @DisplayName("isValidHexHash should validate SHA-256 hashes (64 chars)")
    void testValidSha256Hash() {
        String validSha = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        assertTrue(SecurityUtils.isValidHexHash(validSha, 64));
        assertFalse(SecurityUtils.isValidHexHash("tooshort", 64));
    }
}
